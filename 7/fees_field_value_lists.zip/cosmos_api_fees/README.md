# fees_field_value_lists — v4, merge instructions

## Merging the two FieldValueRepository classes

`repositories_field_value_MERGED.py` is the full, ready-to-paste
replacement for your existing `repositories/field_value.py`. It's your
current file (get_by_types, add_field_value_dependency,
update_field_values_dependencies - unchanged, reconstructed from what
you showed) plus `get_labels_map` appended at the end.

Steps, in order:

1. Replace the full content of `repositories/field_value.py` with
   `repositories_field_value_MERGED.py`.

2. Find every remaining import of the other module and repoint it at
   `repositories.field_value` instead:

   ```
   grep -rn "field_value_repository" --include="*.py" .
   ```

   Any `from repositories.field_value_repository import FieldValueRepository`
   found this way becomes
   `from repositories.field_value import FieldValueRepository`.
   The class name doesn't change, so nothing else in those files needs
   touching - only the import line.

3. Delete `repositories/field_value_repository.py`.

4. Run the full test suite once after the delete, not just the fees
   tests - if anything else was quietly relying on the now-removed
   file, this is where it'll show up.

I can't run that grep myself (no access to your repo), so step 2 is the
one part of this you'll need to do by hand - everything else here is
ready to drop in.

## Where the other files go (paths relative to `src/`)

- `resources/retrieve_fees_data/fees_field_value_lists.py` -> same path
  (unchanged from before - already imported from `repositories.field_value`,
  so nothing to fix there)
- `routes/fees_field_value_lists.py` -> same path
- `swagger/fees_field_value_lists/GET.yml` -> same path
- `test/resources/retrieve_fees_data/test_fees_field_value_lists.py` -> same path
- `test/repositories/test_field_value_get_labels_map.py` -> same path

## Still open

- Where `REFETCH_FEES_DATA_BLUEPRINT` gets registered (app.py or a
  central routes file) - register `FEES_FIELD_VALUE_LISTS_BLUEPRINT` the
  same way, same spot.
