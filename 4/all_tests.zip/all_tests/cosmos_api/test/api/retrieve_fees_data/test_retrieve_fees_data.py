import json
import unittest
from unittest.mock import patch

from helpers import init_database

from constants.product import LAUNCHED
from db import db
from models import (
    FieldValue,
    Product,
    ProductCodification,
    ProductFee,
    Share,
    ShareLaunchingSchedule,
    Single,
    Subfund,
    Umbrella,
    Versioning,
)
from server import server


class TestRetrieveFeesDataResource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = server.test_client()
        cls.patcher = patch(
            "utils.required_authentication.required_authentication", return_value=lambda f: f
        )
        cls.patcher.start()
        init_database()

        Versioning(version_num="40", version_stat_cd="3").save()

        Product(
            prod_cd="prod_cd_1",
            prod_name="Parvest",
            prod_origin="SIN",
            domiciliation_ctry="LUX",
            umb_cd="umb001",
            prod_stat_cd=LAUNCHED,
            prod_stat_lbl="Launched",
            version_num="40",
        ).save()

        Single(sin_cd="prod_cd_1", sin_name="sin_name_1", version_num="40").save()
        Umbrella(umb_cd_cd="umb001", umb_name_lbl="umb_name_lbl_1").save()

        Share(
            prod_cd="prod_cd_1",
            sha_cd="sha_cd_1",
            sha_name="sha_name_1",
            isin_cd="isin_cd_1",
            sha_stat_lbl="sha_stat_lbl_1",
            version_num="40",
        ).save()

        ProductCodification(
            prod_cd="prod_cd_1",
            prod_cd_valu="prod_cd_valu_1",
            codification_typ_cd="PTF_BNPPAM",
            version_num="40",
        ).save()

        ShareLaunchingSchedule(
            sha_cd="sha_cd_1", nav_valuation_date="2026-01-01", version_num="40"
        ).save()

        # Fee: Management, MAX
        ProductFee(
            sha_cd="sha_cd_1",
            fee_id="fee_mgmt_max_1",
            fee_value_id="feeval_mgmt_max_1",
            fees_typ_cd="2",
            fees_subtype_cd="1",
            fees_lvl_cd="MAX",
            fees_pctg="0.40",
            basis_calc_cd="1",
            calc_frq_cd="D",
            version_num="40",
        ).save()

        # Fee: Conversion (fees_subtype_cd = "9", pas de niveau)
        ProductFee(
            sha_cd="sha_cd_1",
            fee_id="fee_conv_1",
            fee_value_id="feeval_conv_1",
            fees_typ_cd="2",
            fees_subtype_cd="9",
            fees_pctg="1.5",
            version_num="40",
        ).save()

        # Labels pour la traduction (basis_calc_cd / calc_frq_cd)
        FieldValue(
            code="1", type="BASIS_OF_CALCULATION", label_en="Net assets", is_active=True
        ).save()
        FieldValue(
            code="D", type="FEE_CALCULATION_FREQUENCY", label_en="Daily", is_active=True
        ).save()

    @classmethod
    def tearDownClass(cls):
        cls.patcher.stop()
        db.session.remove()

    def test_retrieve_fees_data_returns_expected_structure(self):
        """Doit renvoyer SIN/SUB/unknown avec les fees traduites"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({"prod_cd_list": ["prod_cd_1"]}),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.get_data().decode())

        self.assertIn("SIN", response_json)
        self.assertIn("SUB", response_json)
        self.assertIn("unknown", response_json)
        self.assertEqual(len(response_json["SIN"]), 1)
        self.assertEqual(len(response_json["unknown"]), 0)

    def test_retrieve_fees_data_translates_labels(self):
        """Les codes basis_calc_cd/calc_frq_cd doivent être traduits en labels"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({"prod_cd_list": ["prod_cd_1"]}),
            content_type="application/json",
        )
        response_json = json.loads(response.get_data().decode())
        row = response_json["SIN"][0]

        self.assertEqual(row["Max Management fees Rate"], "0.40")
        self.assertEqual(row["Max Management fees Basis of Calculation"], "Net assets")
        self.assertEqual(row["Max Management fees Calculation Frequency"], "Daily")
        self.assertEqual(row["Conversion Rate"], "1.5")

    def test_retrieve_fees_data_empty_list(self):
        """Doit retourner une erreur 400 si prod_cd_list est vide"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({"prod_cd_list": []}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)
        response_json = json.loads(response.get_data().decode())
        self.assertEqual(
            response_json["error"], "prod_cd_list is required and must be a non-empty list"
        )

    def test_retrieve_fees_data_invalid_input(self):
        """Doit retourner une erreur 400 si prod_cd_list n'est pas une liste"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({"prod_cd_list": "not_a_list"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)

    def test_retrieve_fees_data_missing_field(self):
        """Doit retourner une erreur 400 si prod_cd_list est absent du body"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)

    def test_retrieve_fees_data_unknown_product(self):
        """Un produit inconnu doit apparaître dans 'unknown', pas planter"""
        response = self.client.post(
            "smartgps/retrieve_fees_data",
            data=json.dumps({"prod_cd_list": ["prod_cd_1", "does_not_exist"]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.get_data().decode())
        self.assertIn("does_not_exist", response_json["unknown"])


if __name__ == "__main__":
    unittest.main()
