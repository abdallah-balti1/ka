import json
import unittest
from unittest.mock import patch

from helpers import init_database

from db import db
from models import FieldValue, ProductFee, Versioning
from server import server


class TestRefetchFeesDataResource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = server.test_client()
        cls.patcher = patch(
            "utils.required_authentication.required_authentication", return_value=lambda f: f
        )
        cls.patcher.start()
        init_database()

        Versioning(version_num="41", version_stat_cd="3").save()

        ProductFee(
            sha_cd="sha_cd_refetch_1",
            fee_id="fee_id_1",
            fee_value_id="fee_value_id_1",
            fees_typ_cd="2",
            fees_subtype_cd="1",
            fees_lvl_cd="MAX",
            fees_pctg="0.40",
            basis_calc_cd="1",
            version_num="41",
        ).save()

        FieldValue(
            code="1", type="BASIS_OF_CALCULATION", label_en="Net assets", is_active=True
        ).save()

    @classmethod
    def tearDownClass(cls):
        cls.patcher.stop()
        db.session.remove()

    def test_refetch_fees_data_returns_value_and_ids(self):
        """Chaque colonne doit contenir value/fee_id/fee_value_id"""
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": ["sha_cd_refetch_1"]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.get_data().decode())

        entry = response_json["sha_cd_refetch_1"]["Max Management fees Rate"]
        self.assertEqual(entry["value"], "0.40")
        self.assertEqual(entry["fee_id"], "fee_id_1")
        self.assertEqual(entry["fee_value_id"], "fee_value_id_1")

    def test_refetch_fees_data_translates_labels(self):
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": ["sha_cd_refetch_1"]}),
            content_type="application/json",
        )
        response_json = json.loads(response.get_data().decode())
        entry = response_json["sha_cd_refetch_1"]["Max Management fees Basis of Calculation"]
        self.assertEqual(entry["value"], "Net assets")

    def test_refetch_fees_data_sha_cd_without_any_fee_returns_empty_dict(self):
        """Un sha_cd demandé mais sans fee en base doit quand même apparaître"""
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": ["sha_cd_unknown_999"]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.get_data().decode())
        self.assertIn("sha_cd_unknown_999", response_json)
        self.assertEqual(response_json["sha_cd_unknown_999"], {})

    def test_refetch_fees_data_empty_list(self):
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": []}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)
        response_json = json.loads(response.get_data().decode())
        self.assertEqual(
            response_json["error"], "sha_cd_list is required and must be a non-empty list"
        )

    def test_refetch_fees_data_invalid_input(self):
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": "not_a_list"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)

    def test_refetch_fees_data_multiple_sha_cds(self):
        response = self.client.post(
            "smartgps/refetch_fees_data",
            data=json.dumps({"sha_cd_list": ["sha_cd_refetch_1", "sha_cd_unknown_999"]}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response_json = json.loads(response.get_data().decode())
        self.assertEqual(len(response_json), 2)


if __name__ == "__main__":
    unittest.main()
