import unittest

from helpers import init_database

from db import db
from models import FieldValue, ProductFee, Versioning
from repositories.export_query_repository import ExportQueryRepository


class TestGetRawFees(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_database()

        Versioning(version_num="42", version_stat_cd="3").save()

        ProductFee(
            sha_cd="sha_raw_1",
            fee_id="fee_id_raw_1",
            fee_value_id="fee_value_id_raw_1",
            fees_typ_cd="2",
            fees_subtype_cd="1",
            fees_lvl_cd="MAX",
            fees_pctg="0.4",
            basis_calc_cd="1",
            calc_frq_cd="D",
            pmt_frq_cd="D",
            fees_paid_cd=None,
            version_num="42",
        ).save()

        FieldValue(
            code="1", type="BASIS_OF_CALCULATION", label_en="Net assets", is_active=True
        ).save()
        FieldValue(
            code="D", type="FEE_CALCULATION_FREQUENCY", label_en="Daily", is_active=True
        ).save()

    @classmethod
    def tearDownClass(cls):
        db.session.remove()

    def test_get_raw_fees_returns_fee_id_and_fee_value_id(self):
        rows = ExportQueryRepository.get_raw_fees(["sha_raw_1"])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["fee_id"], "fee_id_raw_1")
        self.assertEqual(rows[0]["fee_value_id"], "fee_value_id_raw_1")

    def test_get_raw_fees_translates_basis_calc_and_calc_frq(self):
        rows = ExportQueryRepository.get_raw_fees(["sha_raw_1"])
        self.assertEqual(rows[0]["basis_calc_cd"], "Net assets")
        self.assertEqual(rows[0]["calc_frq_cd"], "Daily")

    def test_get_raw_fees_translates_pmt_frq_using_same_type_as_calc_frq(self):
        """pmt_frq_cd doit utiliser FEE_CALCULATION_FREQUENCY, pas PAYMENT_FREQUENECY
        (référentiel à codes numériques incompatible, cf. investigation du 23/07)"""
        rows = ExportQueryRepository.get_raw_fees(["sha_raw_1"])
        self.assertEqual(rows[0]["pmt_frq_cd"], "Daily")

    def test_get_raw_fees_empty_sha_cd_list_returns_empty_list(self):
        self.assertEqual(ExportQueryRepository.get_raw_fees([]), [])

    def test_get_raw_fees_unknown_sha_cd_returns_empty_list(self):
        self.assertEqual(ExportQueryRepository.get_raw_fees(["does_not_exist"]), [])


if __name__ == "__main__":
    unittest.main()
