import unittest

from services.fee_export_service import FeeExportService


class TestFeeExportService(unittest.TestCase):
    def _raw_row(self, sha_cd, fee_id="F1", fee_value_id="V1", **overrides):
        row = {
            "sha_cd": sha_cd,
            "fee_id": fee_id,
            "fee_value_id": fee_value_id,
            "fees_typ_cd": "2",
            "fees_subtype_cd": "1",
            "fees_lvl_cd": "MAX",
            "acq_or_not_acq_fees_cd": None,
            "specific_fees_cgy_cd": None,
            "fees_pctg": "0.4",
            "basis_calc_cd": "Net assets",
            "calc_frq_cd": "Daily",
            "pmt_frq_cd": None,
            "fees_paid_cd": None,
        }
        row.update(overrides)
        return row

    def test_build_fee_columns_matches_management_max(self):
        raw_fees = [self._raw_row("sha_1")]
        result = FeeExportService.build_fee_columns(raw_fees)

        self.assertEqual(result["sha_1"]["Max Management fees Rate"], "0.4")
        self.assertEqual(
            result["sha_1"]["Max Management fees Basis of Calculation"], "Net assets"
        )

    def test_build_fee_columns_no_match_returns_none(self):
        raw_fees = [self._raw_row("sha_1", fees_subtype_cd="3")]  # Distribution, pas Management
        result = FeeExportService.build_fee_columns(raw_fees)
        self.assertIsNone(result["sha_1"]["Max Management fees Rate"])

    def test_build_fee_columns_empty_input_returns_empty_dict(self):
        self.assertEqual(FeeExportService.build_fee_columns([]), {})

    def test_build_fee_ids_matches_same_row_as_values(self):
        raw_fees = [self._raw_row("sha_1", fee_id="FEE_X", fee_value_id="VAL_X")]
        values = FeeExportService.build_fee_columns(raw_fees)
        ids = FeeExportService.build_fee_ids(raw_fees)

        self.assertEqual(set(values["sha_1"].keys()), set(ids["sha_1"].keys()))
        self.assertEqual(
            ids["sha_1"]["Max Management fees Rate"],
            {"fee_id": "FEE_X", "fee_value_id": "VAL_X"},
        )

    def test_build_fee_ids_no_match_returns_none_ids(self):
        raw_fees = [self._raw_row("sha_1", fees_subtype_cd="3")]
        ids = FeeExportService.build_fee_ids(raw_fees)
        self.assertEqual(
            ids["sha_1"]["Max Management fees Rate"], {"fee_id": None, "fee_value_id": None}
        )

    def test_build_fee_columns_multiple_shares_independent(self):
        raw_fees = [
            self._raw_row("sha_1", fees_pctg="0.4"),
            self._raw_row("sha_2", fees_pctg="0.9"),
        ]
        result = FeeExportService.build_fee_columns(raw_fees)
        self.assertEqual(result["sha_1"]["Max Management fees Rate"], "0.4")
        self.assertEqual(result["sha_2"]["Max Management fees Rate"], "0.9")


if __name__ == "__main__":
    unittest.main()
