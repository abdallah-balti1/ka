import unittest
from unittest.mock import patch

from services import field_value_cache


class TestFieldValueCache(unittest.TestCase):
    def setUp(self):
        field_value_cache.clear_cache()

    def test_single_db_call_for_multiple_lookups(self):
        with patch(
            "services.field_value_cache.FieldValueRepository.get_labels_map",
            return_value={"FEE_CALCULATION_FREQUENCY": {"D": "Daily"}},
        ) as mock_get_labels:
            field_value_cache.get_cached_labels_map(["FEE_CALCULATION_FREQUENCY"])
            field_value_cache.get_cached_labels_map(["FEE_CALCULATION_FREQUENCY"])
            field_value_cache.get_cached_labels_map(["FEE_CALCULATION_FREQUENCY"])

        self.assertEqual(mock_get_labels.call_count, 1)

    def test_translation_mapping_correct(self):
        with patch(
            "services.field_value_cache.FieldValueRepository.get_labels_map",
            return_value={"FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly"}},
        ):
            labels_map = field_value_cache.get_cached_labels_map(["FEE_CALCULATION_FREQUENCY"])
        self.assertEqual(labels_map["FEE_CALCULATION_FREQUENCY"]["D"], "Daily")
        self.assertEqual(labels_map["FEE_CALCULATION_FREQUENCY"]["M"], "Monthly")

    def test_missing_type_triggers_reload(self):
        """Si un type demandé n'est pas encore en cache, il faut recharger."""
        with patch(
            "services.field_value_cache.FieldValueRepository.get_labels_map",
            return_value={"BASIS_OF_CALCULATION": {"1": "Net assets"}},
        ) as mock_get_labels:
            field_value_cache.get_cached_labels_map(["BASIS_OF_CALCULATION"])

        with patch(
            "services.field_value_cache.FieldValueRepository.get_labels_map",
            return_value={
                "BASIS_OF_CALCULATION": {"1": "Net assets"},
                "FEE_CALCULATION_FREQUENCY": {"D": "Daily"},
            },
        ) as mock_get_labels_2:
            field_value_cache.get_cached_labels_map(
                ["BASIS_OF_CALCULATION", "FEE_CALCULATION_FREQUENCY"]
            )
        self.assertEqual(mock_get_labels_2.call_count, 1)


if __name__ == "__main__":
    unittest.main()
