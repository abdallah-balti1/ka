import unittest

from constants.fees_cre_mapping import get_identification_fields, get_pivot_field_name
from constants.fees_template import EDITABLE_COLUMNS, KEYS


class TestFeesCreMapping(unittest.TestCase):
    def test_every_editable_column_resolves_identification_fields(self):
        """CRITIQUE : si une colonne échoue ici, le mass update plante
        en prod dès qu'un utilisateur la modifie."""
        failures = []
        for idx in EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            try:
                result = get_identification_fields(column_label)
                self.assertIn("FeesTypCd", result)
                self.assertIn("FeesSubtypeCd", result)
            except ValueError as e:
                failures.append((column_label, str(e)))

        self.assertEqual(
            failures, [], f"{len(failures)} colonne(s) sans identification_fields résolu"
        )

    def test_every_editable_column_resolves_pivot_field_name(self):
        failures = []
        for idx in EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            try:
                get_pivot_field_name(column_label)
            except ValueError as e:
                failures.append((column_label, str(e)))

        self.assertEqual(
            failures, [], f"{len(failures)} colonne(s) sans pivot_field_name résolu"
        )

    def test_spot_check_management_rate(self):
        self.assertEqual(
            get_identification_fields("Max Management fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "1"},
        )
        self.assertEqual(get_pivot_field_name("Max Management fees Rate"), "FeesPctg")

    def test_spot_check_taxe_abonnement_paid_to(self):
        self.assertEqual(
            get_identification_fields("Real Taxe Abonnement Paid To"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "5"},
        )
        self.assertEqual(get_pivot_field_name("Real Taxe Abonnement Paid To"), "FeesPaidCd")

    def test_spot_check_redemption(self):
        self.assertEqual(
            get_identification_fields("Redemption Acquired MAX Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "8"},
        )

    def test_spot_check_basis_of_calculation_suffix(self):
        self.assertEqual(
            get_pivot_field_name("Real Charity fees Basis of Calculation"), "BasisCalcCd"
        )

    def test_unknown_column_raises_value_error(self):
        with self.assertRaises(ValueError):
            get_identification_fields("Some Totally Unknown Column")
        with self.assertRaises(ValueError):
            get_pivot_field_name("Some Totally Unknown Column")


if __name__ == "__main__":
    unittest.main()
