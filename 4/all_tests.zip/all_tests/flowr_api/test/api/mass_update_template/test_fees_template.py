import unittest

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

from constants.fees_template import (
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    EDITABLE_COLUMNS,
    HEADERS,
    KEYS,
    NUMERIC_EDITABLE_COLUMNS,
    N_BASE_COLUMNS,
    PROD_CD_COLUMN_INDEX,
    SECTION_GROUPS,
    SHEET_NAME,
    TOTAL_COLUMNS,
)
from util.mass_update.fees_template import create_fees_template_workbook


class TestFeesTemplate(unittest.TestCase):
    def setUp(self):
        self.fees_data = [
            {
                "sha_cd": "sha_cd_1",
                "prod_cd": "prod_cd_1",
                "umb_name_lbl": "Umbrella 1",
                "sbf_name": "Product 1",
                "prod_cd_valu": "P1",
                "prod_cd_mffa": None,
                "sbf_stat_lbl": "Active",
                "sha_name": "Share 1",
                "isin_cd": "ISIN1",
                "sha_stat_lbl": "Active",
                "Max Management fees Rate": "0.40",
                "Max Management fees Basis of Calculation": "Net assets",
                "Max Management fees Calculation Frequency": "Daily",
                "Max Management fees Payment Frequency": "Monthly",
                "Subscription Acquired MAX Rate": "0",
                "Conversion Rate": "1.5",
            }
        ]

    def _build(self, data):
        wb = create_fees_template_workbook(data)
        ws: Worksheet = wb[SHEET_NAME]
        return wb, ws

    def _col(self, header_name: str) -> int:
        """1-based column index for a header, basé sur HEADERS (peut y avoir
        des doublons ex: 'Rate' apparaît plusieurs fois — retourne le premier)."""
        return HEADERS.index(header_name) + 1

    def test_create_fees_template_workbook_full(self):
        """Couvre : structure + headers + groupes + freeze panes + data
        validation + protection + colonnes techniques cachées."""
        wb, ws = self._build(self.fees_data)

        self.assertEqual(ws.title, SHEET_NAME)

        # Forme de base
        self.assertGreaterEqual(ws.max_row, DATA_START_ROW)
        self.assertEqual(ws.max_column, TOTAL_COLUMNS)

        # Ligne 3 : libellés de colonnes de fees (non fusionnés)
        for col_idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
            self.assertEqual(ws.cell(row=3, column=col_idx).value, HEADERS[col_idx - 1])

        # Ligne 1 : titres de section (colonne ancre de chaque groupe)
        for start_col, end_col, title, _color in SECTION_GROUPS:
            self.assertEqual(ws.cell(row=1, column=start_col).value, title)

        # Colonnes techniques cachées
        self.assertTrue(ws.column_dimensions["A"].hidden)  # Cosmos ID
        self.assertTrue(ws.column_dimensions["B"].hidden)  # Product Cd

        # Données
        r = DATA_START_ROW
        row = self.fees_data[0]
        self.assertEqual(
            ws.cell(row=r, column=COSMOS_ID_COLUMN_INDEX).value, row["sha_cd"]
        )
        self.assertEqual(
            ws.cell(row=r, column=PROD_CD_COLUMN_INDEX).value, row["prod_cd"]
        )
        self.assertEqual(
            ws.cell(row=r, column=self._col("Umbrella name")).value, row["umb_name_lbl"]
        )

        # Colonnes numériques formatées "0.00"
        rate_col = None
        for idx in NUMERIC_EDITABLE_COLUMNS:
            if KEYS[idx - 1] == "Max Management fees Rate":
                rate_col = idx
                break
        self.assertIsNotNone(rate_col)
        self.assertEqual(ws.cell(row=r, column=rate_col).number_format, "0.00")

        # Freeze panes
        self.assertEqual(ws.freeze_panes, f"A{DATA_START_ROW}")

        # Data validation existe et cible bien des colonnes numériques
        self.assertGreaterEqual(len(ws.data_validations.dataValidation), 1)
        dv = ws.data_validations.dataValidation[0]
        self.assertEqual(dv.type, "custom")
        self.assertTrue(dv.allow_blank)
        self.assertTrue(dv.showErrorMessage)
        self.assertIsNotNone(dv.formula1)

        # Protection de la feuille active
        self.assertTrue(ws.protection.sheet)

        wb.close()

    def test_base_columns_are_locked_editable_columns_are_not(self):
        wb, ws = self._build(self.fees_data)
        r = DATA_START_ROW

        # Colonne de base (Umbrella name) : verrouillée
        base_cell = ws.cell(row=r, column=self._col("Umbrella name"))
        self.assertTrue(base_cell.protection.locked)

        # Colonne éditable (Rate de Management) : déverrouillée
        editable_col = next(
            idx for idx in EDITABLE_COLUMNS if KEYS[idx - 1] == "Max Management fees Rate"
        )
        editable_cell = ws.cell(row=r, column=editable_col)
        self.assertFalse(editable_cell.protection.locked)

        wb.close()

    def test_create_fees_template_workbook_empty_data(self):
        wb, ws = self._build([])

        # Les headers doivent toujours être présents même sans données
        for col_idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
            self.assertEqual(ws.cell(row=3, column=col_idx).value, HEADERS[col_idx - 1])

        # Pas de ligne de données
        self.assertLess(ws.max_row, DATA_START_ROW)

        wb.close()

    def test_no_nav_valuation_date_column(self):
        """Non-régression du bug du 10/08 : cette colonne ne doit jamais
        réapparaître dans le template."""
        self.assertNotIn("Nav valuation date", HEADERS)

    def test_section_order_matches_reference_template(self):
        """Non-régression : ordre exact confirmé le 10/08."""
        titles = [title for _, _, title, _ in SECTION_GROUPS]
        self.assertEqual(
            titles,
            [
                "Subscription/Redemption/Conversion fees",
                "Management fees",
                "Specific & External fees",
                "Distribution fees",
                "Charity fees",
                "Advisory fees",
            ],
        )


if __name__ == "__main__":
    unittest.main()
