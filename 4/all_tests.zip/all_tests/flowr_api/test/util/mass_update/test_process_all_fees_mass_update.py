import unittest
from unittest.mock import patch

from constants.fees_template import DATA_START_ROW, KEYS
from util.mass_update.fees_template import create_fees_template_workbook
from util.mass_update.process_all_fees_mass_update import process_all_fees_mass_update


class TestProcessAllFeesMassUpdate(unittest.TestCase):
    def _build_fake_row(self, sha_cd, prod_cd):
        row = {k: None for k in KEYS}
        row["sha_cd"] = sha_cd
        row["prod_cd"] = prod_cd
        row["Max Management fees Rate"] = "0.4"
        return row

    def test_detects_change_via_mocked_refetch(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])

        ws = wb["Fees Review"]
        target_col = None
        for c in range(1, ws.max_column + 1):
            if ws.cell(row=3, column=c).value == "Rate":
                target_col = c
                break
        self.assertIsNotNone(target_col)
        ws.cell(row=DATA_START_ROW, column=target_col, value="0.5")

        fresh_state = {
            "sha_1": {
                "Max Management fees Rate": {
                    "value": "0.4", "fee_id": "F1", "fee_value_id": "V1"
                }
            }
        }

        with patch(
            "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data",
            return_value=fresh_state,
        ) as mock_refetch:
            diffs = process_all_fees_mass_update(wb)

        mock_refetch.assert_called_once_with(["sha_1"])
        self.assertEqual(len(diffs), 1)
        self.assertEqual(diffs[0]["field"], "Max Management fees Rate")
        self.assertEqual(diffs[0]["old_value"], "0.4")
        self.assertEqual(diffs[0]["new_value"], "0.5")
        wb.close()

    def test_no_rows_skips_refetch_call(self):
        wb = create_fees_template_workbook([])

        with patch(
            "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data"
        ) as mock_refetch:
            diffs = process_all_fees_mass_update(wb)

        mock_refetch.assert_not_called()
        self.assertEqual(diffs, [])
        wb.close()

    def test_no_diff_when_nothing_changed(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])
        fresh_state = {
            "sha_1": {
                "Max Management fees Rate": {
                    "value": "0.4", "fee_id": "F1", "fee_value_id": "V1"
                }
            }
        }

        with patch(
            "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data",
            return_value=fresh_state,
        ):
            diffs = process_all_fees_mass_update(wb)

        self.assertEqual(diffs, [])
        wb.close()


if __name__ == "__main__":
    unittest.main()
