import unittest

import openpyxl

from constants.fees_template import COLUMN_LABEL_ROW, HEADERS, SECTION_TITLE_ROW
from util.mass_update.fees_detection import is_all_fees_mass_update


class TestFeesDetection(unittest.TestCase):
    def _build_all_fees_like_workbook(self):
        """Simule un classeur avec la structure réelle du template (headers
        de base row1, section titles row1, colonnes de fees row3)."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"

        from constants.fees_template import SECTION_GROUPS, N_BASE_COLUMNS

        base_labels = HEADERS[:N_BASE_COLUMNS]
        for col_idx, label in enumerate(base_labels, start=1):
            ws.cell(row=1, column=col_idx, value=label)

        for start, end, title, _color in SECTION_GROUPS:
            ws.cell(row=1, column=start, value=title)
            for c in range(start, end + 1):
                ws.cell(row=3, column=c, value=HEADERS[c - 1])

        return wb

    def test_detects_true_positive_all_fees_workbook(self):
        wb = self._build_all_fees_like_workbook()
        self.assertTrue(is_all_fees_mass_update(wb))

    def test_does_not_detect_adl_like_workbook(self):
        """Un classeur ADL (une seule ligne d'en-tête, headers différents)
        ne doit jamais être détecté comme All Fees."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"
        adl_headers = [
            "Prod Cd", "Share Cd", "Umbrella name", "Sub-fund name",
            "Max ADL In Fee", "ADL In Fee", "Max ADL Out Fee", "ADL Out Fee",
        ]
        for col_idx, h in enumerate(adl_headers, start=1):
            ws.cell(row=1, column=col_idx, value=h)

        self.assertFalse(is_all_fees_mass_update(wb))

    def test_does_not_detect_empty_workbook(self):
        wb = openpyxl.Workbook()
        self.assertFalse(is_all_fees_mass_update(wb))

    def test_does_not_falsely_detect_partial_headers(self):
        """Un fichier avec juste une colonne 'Rate' par coïncidence ne doit
        pas être détecté comme All Fees."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"
        ws.cell(row=1, column=1, value="Rate")
        ws.cell(row=1, column=2, value="Some other column")

        self.assertFalse(is_all_fees_mass_update(wb))

    def test_detects_when_any_worksheet_matches(self):
        wb = self._build_all_fees_like_workbook()
        wb.create_sheet("Unrelated sheet")
        self.assertTrue(is_all_fees_mass_update(wb))

    def test_does_not_expect_nav_valuation_date(self):
        """Non-régression du bug du 10/08 : la détection ne doit plus
        chercher 'Nav valuation date', absent du vrai fichier."""
        self.assertNotIn("Nav valuation date", HEADERS)


if __name__ == "__main__":
    unittest.main()
