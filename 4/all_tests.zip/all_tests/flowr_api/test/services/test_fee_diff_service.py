import unittest

from services.fee_diff_service import FeeDiffService, _values_differ


class TestFeeDiffService(unittest.TestCase):
    def test_detects_single_numeric_change(self):
        file_rows = [
            {
                "sha_cd": "sha_1",
                "prod_cd": "prod_1",
                "Max Management fees Rate": "0.5",
                "Max Management fees Basis of Calculation": "Net assets",
            }
        ]
        fresh_data = {
            "sha_1": {
                "Max Management fees Rate": {
                    "value": "0.4",
                    "fee_id": "F1",
                    "fee_value_id": "V1",
                },
                "Max Management fees Basis of Calculation": {
                    "value": "Net assets",
                    "fee_id": "F1",
                    "fee_value_id": "V2",
                },
            }
        }

        diffs = FeeDiffService.build_diff(file_rows, fresh_data)

        self.assertEqual(len(diffs), 1)
        d = diffs[0]
        self.assertEqual(d["sha_cd"], "sha_1")
        self.assertEqual(d["prod_cd"], "prod_1")
        self.assertEqual(d["field"], "Max Management fees Rate")
        self.assertEqual(d["old_value"], "0.4")
        self.assertEqual(d["new_value"], "0.5")
        self.assertEqual(d["fee_id"], "F1")
        self.assertEqual(d["fee_value_id"], "V1")

    def test_no_diff_when_nothing_changed(self):
        file_rows = [
            {"sha_cd": "sha_1", "prod_cd": "prod_1", "Max Management fees Rate": "0.4"}
        ]
        fresh_data = {
            "sha_1": {
                "Max Management fees Rate": {
                    "value": "0.4", "fee_id": "F1", "fee_value_id": "V1"
                }
            }
        }
        diffs = FeeDiffService.build_diff(file_rows, fresh_data)
        self.assertEqual(diffs, [])

    def test_comma_vs_dot_not_flagged_as_diff(self):
        self.assertFalse(_values_differ("Max Management fees Rate", "0,4", "0.4"))
        self.assertFalse(_values_differ("Max Management fees Rate", "0.40", "0.4"))
        self.assertTrue(_values_differ("Max Management fees Rate", "0.5", "0.4"))

    def test_empty_and_none_treated_as_equivalent(self):
        self.assertFalse(
            _values_differ("Max Management fees Basis of Calculation", "", None)
        )
        self.assertFalse(
            _values_differ("Max Management fees Basis of Calculation", "  ", None)
        )
        self.assertTrue(
            _values_differ(
                "Max Management fees Basis of Calculation", "Net assets", None
            )
        )

    def test_text_field_change_detected(self):
        self.assertTrue(
            _values_differ(
                "Max Management fees Basis of Calculation", "Net income", "Net assets"
            )
        )
        self.assertFalse(
            _values_differ(
                "Max Management fees Basis of Calculation", " Net assets ", "Net assets"
            )
        )

    def test_diff_without_fresh_entry_has_none_ids(self):
        """Un champ sans aucune fee en base (nouveau) doit quand même être
        détecté, avec fee_id/fee_value_id à None."""
        file_rows = [
            {"sha_cd": "sha_1", "prod_cd": "prod_1", "Max Management fees Rate": "0.3"}
        ]
        fresh_data = {"sha_1": {}}

        diffs = FeeDiffService.build_diff(file_rows, fresh_data)

        self.assertEqual(len(diffs), 1)
        self.assertIsNone(diffs[0]["old_value"])
        self.assertIsNone(diffs[0]["fee_id"])
        self.assertIsNone(diffs[0]["fee_value_id"])

    def test_diff_prod_cd_propagated(self):
        file_rows = [
            {"sha_cd": "sha_1", "prod_cd": "prod_XYZ", "Conversion Rate": "1.5"}
        ]
        fresh_data = {"sha_1": {}}
        diffs = FeeDiffService.build_diff(file_rows, fresh_data)
        self.assertEqual(diffs[0]["prod_cd"], "prod_XYZ")


if __name__ == "__main__":
    unittest.main()
