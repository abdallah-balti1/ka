import unittest

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

from constants.fees_template import (
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    EDITABLE_COLUMNS,
    HEADERS,
    KEYS,
    NUMERIC_EDITABLE_COLUMNS,
    N_BASE_COLUMNS,
    PROD_CD_COLUMN_INDEX,
    SECTION_GROUPS,
    SHEET_NAME,
    SUBSECTION_GROUPS,
    TOTAL_COLUMNS,
)
from util.mass_update.fees_template import create_fees_template_workbook


class TestFeesTemplate(unittest.TestCase):
    def setUp(self):
        # One row of data matching the keys expected by the template builder
        self.fees_data = [
            {
                "sha_cd": "sha_cd_1",  # Cosmos ID (hidden)
                "prod_cd": "prod_cd_1",  # Product Cd (hidden)
                "umb_name_lbl": "Umbrella 1",
                "sbf_name": "Product 1",
                "prod_cd_valu": "P1",  # Product ALADDIN code
                "prod_cd_mffa": None,  # MFFA Code (optional)
                "sbf_stat_lbl": "Active",  # Product status
                "sha_name": "Share 1",
                "isin_cd": "ISIN1",
                "sha_stat_lbl": "Active",  # Share status
                "Subscription Acquired MAX Rate": "0",
                "Subscription Non Acquired MAX Rate": "0",
                "Redemption Acquired MAX Rate": "0",
                "Redemption Non Acquired MAX Rate": "0",
                "Conversion Rate": "1.5",
                "Max Management fees Rate": "0.40",
                "Max Management fees Basis of Calculation": "Net assets",
                "Max Management fees Calculation Frequency": "Daily",
                "Max Management fees Payment Frequency": "Monthly",
                "Real Management fees Rate": "0.34",
                "Real Management fees Basis of Calculation": "Net assets",
                "Real Management fees Calculation Frequency": "Daily",
                "Real Management fees Payment Frequency": "Monthly",
                "Max Other Costs Rate": "0.25",
                "Max Other Costs Basis of Calculation": "Net assets",
                "Max Other Costs Calculation Frequency": "Monthly",
                "Max Other Costs Payment Frequency": "Monthly",
                "Max Other Costs Paid To": "Depositary",
            }
        ]

    def _build(self, data) -> "tuple[openpyxl.Workbook, Worksheet]":
        wb = create_fees_template_workbook(data)
        ws: Worksheet = wb[SHEET_NAME]
        return wb, ws

    def _col(self, header_name: str) -> int:
        """1-based column index for a header, based on HEADERS constant.
        (HEADERS a des doublons ex: 'Rate' apparaît plusieurs fois — retourne
        la première occurrence, suffisant pour vérifier les colonnes de base)."""
        return HEADERS.index(header_name) + 1

    def test_create_fees_template_workbook_full(self):
        """Covers: structure + groups + freeze panes + data validation + protection."""
        wb, ws = self._build(self.fees_data)

        # Sheet name
        self.assertEqual(ws.title, SHEET_NAME)

        # Basic shape: 3 header rows + 1 data row
        self.assertGreaterEqual(ws.max_row, DATA_START_ROW)
        self.assertEqual(ws.max_column, TOTAL_COLUMNS)
        self.assertEqual(len(HEADERS), 77)  # guard: template has 77 columns

        # Headers are row=3 (colonnes de fees ; colonnes de base fusionnées row1-3)
        for col_idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
            self.assertEqual(ws.cell(row=3, column=col_idx).value, HEADERS[col_idx - 1])

        # Section groups are row=1 (labels, colonne ancre)
        for start_col, end_col, label, _color in SECTION_GROUPS:
            self.assertEqual(ws.cell(row=1, column=start_col).value, label)

        # Subsection groups are row=2 (labels, colonne ancre)
        for start_col, end_col, label, _color in SUBSECTION_GROUPS:
            self.assertEqual(ws.cell(row=2, column=start_col).value, label)

        # Data row starts at DATA_START_ROW
        r = DATA_START_ROW
        row = self.fees_data[0]

        # Column-by-column checks aligned with HEADERS order
        # 1 Cosmos ID
        self.assertEqual(ws.cell(row=r, column=COSMOS_ID_COLUMN_INDEX).value, row["sha_cd"])
        # 2 Product Cd
        self.assertEqual(ws.cell(row=r, column=PROD_CD_COLUMN_INDEX).value, row["prod_cd"])
        # 3 Umbrella name
        self.assertEqual(
            ws.cell(row=r, column=self._col("Umbrella name")).value, row["umb_name_lbl"]
        )
        # 4 Sub-fund name
        self.assertEqual(
            ws.cell(row=r, column=self._col("Sub-fund name")).value, row["sbf_name"]
        )
        # 5 Sub-fund ALADDIN code
        self.assertEqual(
            ws.cell(row=r, column=self._col("Sub-fund ALADDIN code")).value,
            row["prod_cd_valu"],
        )
        # 6 Sub-fund MFFA code
        self.assertEqual(
            ws.cell(row=r, column=self._col("Sub-fund MFFA code")).value,
            row["prod_cd_mffa"],
        )
        # 7 Sub-fund status
        self.assertEqual(
            ws.cell(row=r, column=self._col("Sub-fund status")).value, row["sbf_stat_lbl"]
        )
        # 8 Share name
        self.assertEqual(
            ws.cell(row=r, column=self._col("Share name")).value, row["sha_name"]
        )
        # 9 ISIN code
        self.assertEqual(ws.cell(row=r, column=self._col("ISIN code")).value, row["isin_cd"])
        # 10 Share status
        self.assertEqual(
            ws.cell(row=r, column=self._col("Share status")).value, row["sha_stat_lbl"]
        )

        # Fees blocks — Management (Max)
        mgmt_max_rate_col = next(
            idx for idx in EDITABLE_COLUMNS if KEYS[idx - 1] == "Max Management fees Rate"
        )
        self.assertEqual(
            ws.cell(row=r, column=mgmt_max_rate_col).value, row["Max Management fees Rate"]
        )

        # Specific & External — Other Costs (avec Paid To)
        other_costs_paid_to_col = next(
            idx for idx in EDITABLE_COLUMNS if KEYS[idx - 1] == "Max Other Costs Paid To"
        )
        self.assertEqual(
            ws.cell(row=r, column=other_costs_paid_to_col).value, row["Max Other Costs Paid To"]
        )

        # Editable columns formatting (numériques uniquement)
        self.assertEqual(ws.cell(row=r, column=mgmt_max_rate_col).number_format, "0.00")

        # Colonnes techniques cachées
        self.assertTrue(ws.column_dimensions["A"].hidden)  # Cosmos ID
        self.assertTrue(ws.column_dimensions["B"].hidden)  # Product Cd

        # Freeze panes
        self.assertEqual(ws.freeze_panes, f"A{DATA_START_ROW}")

        # Data validation exists
        self.assertGreaterEqual(len(ws.data_validations.dataValidation), 1)
        dv = ws.data_validations.dataValidation[0]
        self.assertEqual(dv.type, "custom")
        self.assertTrue(dv.allowBlank)
        self.assertTrue(dv.showErrorMessage)
        self.assertIsNotNone(dv.formula1)
        self.assertIn("SUBSTITUTE", dv.formula1)

        # Protection : feuille protégée, colonnes de base verrouillées, colonnes
        # éditables déverrouillées
        self.assertTrue(ws.protection.sheet)
        base_cell = ws.cell(row=r, column=self._col("Umbrella name"))
        self.assertTrue(base_cell.protection.locked)
        editable_cell = ws.cell(row=r, column=mgmt_max_rate_col)
        self.assertFalse(editable_cell.protection.locked)

        wb.close()

    def test_create_fees_template_workbook_empty_data(self):
        wb = create_fees_template_workbook([])
        ws: Worksheet = wb[SHEET_NAME]

        # Headers always present
        for col_idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
            self.assertEqual(ws.cell(row=3, column=col_idx).value, HEADERS[col_idx - 1])

        # No data rows
        self.assertLess(ws.max_row, DATA_START_ROW)

        wb.close()

        # Make sure the numeric validation formula path is exercised with
        # exactly one data row
        one_row = [
            {
                "sha_cd": "SHA_1",
                "prod_cd": "TECH_123",
                "umb_name_lbl": "Umbrella 1",
                "sbf_name": "Product 1",
                "prod_cd_valu": "P1",
                "prod_cd_mffa": None,
                "sbf_stat_lbl": "Active",
                "sha_name": "Share 1",
                "isin_cd": "ISIN1",
                "sha_stat_lbl": "Active",
                "Max Management fees Rate": "0.40",
            }
        ]

        wb2 = create_fees_template_workbook(one_row)
        ws2: Worksheet = wb2[SHEET_NAME]

        dvs = ws2.data_validations.dataValidation
        self.assertIsNotNone(dvs)
        self.assertGreaterEqual(len(dvs), 1)

        mgmt_col = next(
            idx for idx in EDITABLE_COLUMNS if KEYS[idx - 1] == "Max Management fees Rate"
        )
        from openpyxl.utils import get_column_letter

        col_letter = get_column_letter(mgmt_col)
        sqrefs = [str(dv.sqref) for dv in dvs]
        self.assertTrue(any(col_letter in s for s in sqrefs))

        for dv in dvs[:2]:
            self.assertEqual(dv.type, "custom")
            self.assertTrue(dv.allowBlank)

        wb2.close()

    def test_no_nav_valuation_date_column(self):
        """Non-régression bug du 10/08 : cette colonne ne doit jamais réapparaître."""
        self.assertNotIn("Nav valuation date", HEADERS)

    def test_section_order_matches_reference_template(self):
        """Non-régression : ordre exact confirmé le 10/08."""
        titles = [title for _, _, title, _ in SECTION_GROUPS]
        self.assertEqual(
            titles,
            [
                "Subscription/Redemption/Conversion fees",
                "Management fees",
                "Specific & External fees",
                "Distribution fees",
                "Charity fees",
                "Advisory fees",
            ],
        )

    def test_all_numeric_editable_columns_have_number_format(self):
        wb, ws = self._build(self.fees_data)
        r = DATA_START_ROW
        for idx in NUMERIC_EDITABLE_COLUMNS:
            self.assertEqual(ws.cell(row=r, column=idx).number_format, "0.00")
        wb.close()


if __name__ == "__main__":
    unittest.main()
