import unittest

from entities import CreData
from services.fee_cre_builder import build_cre_data_for_all_fees


class _FakeTask:
    id = "TASK123"


class TestFeeCreBuilder(unittest.TestCase):
    def setUp(self):
        self.user = {"fullname": "Abdou Test"}
        self.task = _FakeTask()

    def test_builds_cre_data_grouped_by_product(self):
        diffs = [
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Rate",
                "old_value": "0.4", "new_value": "0.5",
                "fee_id": "FEE1", "fee_value_id": "VAL1",
            },
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Basis of Calculation",
                "old_value": "Net assets", "new_value": "Net income",
                "fee_id": "FEE2", "fee_value_id": "VAL2",
            },
            {
                "sha_cd": "sha_2", "prod_cd": "prod_B",
                "field": "Real Charity fees Rate",
                "old_value": "0.1", "new_value": "0.2",
                "fee_id": "FEE3", "fee_value_id": "VAL3",
            },
        ]

        cre_data_by_product, mapping, skipped = build_cre_data_for_all_fees(
            self.user, self.task, diffs
        )

        self.assertEqual(set(cre_data_by_product.keys()), {"prod_A", "prod_B"})
        self.assertEqual(len(cre_data_by_product["prod_A"]), 2)
        self.assertEqual(len(cre_data_by_product["prod_B"]), 1)
        self.assertEqual(skipped, [])

    def test_cre_data_has_correct_fields(self):
        diffs = [
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Rate",
                "old_value": "0.4", "new_value": "0.5",
                "fee_id": "FEE1", "fee_value_id": "VAL1",
            }
        ]
        cre_data_by_product, _, _ = build_cre_data_for_all_fees(self.user, self.task, diffs)
        cd = cre_data_by_product["prod_A"][0]

        self.assertIsInstance(cd, CreData)
        self.assertEqual(cd.parent_entity_type, "Fees")
        self.assertEqual(cd.parent_entity_id, "FEE1")
        self.assertEqual(cd.entity_type, "ProductFee")
        self.assertEqual(cd.entity_id, "VAL1")
        self.assertEqual(cd.old_value, "0.4")
        self.assertEqual(cd.new_value, "0.5")
        self.assertEqual(cd.pivot_field_name, "FeesPctg")
        self.assertEqual(cd.pivot_name, "ProductFee")
        self.assertEqual(cd.identification_fields, {"FeesTypCd": "2", "FeesSubtypeCd": "1"})
        self.assertEqual(cd.author, "Abdou Test")
        self.assertEqual(cd.task_id, "TASK123")

    def test_old_value_none_becomes_none_not_string_none(self):
        diffs = [
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Rate",
                "old_value": None, "new_value": "0.5",
                "fee_id": "FEE1", "fee_value_id": "VAL1",
            }
        ]
        cre_data_by_product, _, _ = build_cre_data_for_all_fees(self.user, self.task, diffs)
        cd = cre_data_by_product["prod_A"][0]
        self.assertIsNone(cd.old_value)
        self.assertEqual(cd.new_value, "0.5")

    def test_missing_fee_id_is_skipped_not_guessed(self):
        diffs = [
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Rate",
                "old_value": None, "new_value": "0.5",
                "fee_id": None, "fee_value_id": None,
            }
        ]
        cre_data_by_product, _, skipped = build_cre_data_for_all_fees(
            self.user, self.task, diffs
        )
        self.assertEqual(cre_data_by_product, {})
        self.assertEqual(len(skipped), 1)
        self.assertEqual(skipped[0]["field"], "Max Management fees Rate")

    def test_missing_fee_value_id_only_is_also_skipped(self):
        diffs = [
            {
                "sha_cd": "sha_1", "prod_cd": "prod_A",
                "field": "Max Management fees Rate",
                "old_value": "0.4", "new_value": "0.5",
                "fee_id": "FEE1", "fee_value_id": None,
            }
        ]
        cre_data_by_product, _, skipped = build_cre_data_for_all_fees(
            self.user, self.task, diffs
        )
        self.assertEqual(cre_data_by_product, {})
        self.assertEqual(len(skipped), 1)

    def test_empty_diffs_returns_empty_results(self):
        cre_data_by_product, mapping, skipped = build_cre_data_for_all_fees(
            self.user, self.task, []
        )
        self.assertEqual(cre_data_by_product, {})
        self.assertEqual(skipped, [])


if __name__ == "__main__":
    unittest.main()
