import unittest

import openpyxl

from constants.fees_template import (
    HEADERS,
    N_BASE_COLUMNS,
    SECTION_GROUPS,
)
from util.mass_update.fees_detection import is_all_fees_mass_update


class TestFeesDetection(unittest.TestCase):
    def _build_all_fees_like_workbook(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"

        base_labels = HEADERS[:N_BASE_COLUMNS]
        for col_idx, label in enumerate(base_labels, start=1):
            ws.cell(row=1, column=col_idx, value=label)

        for start, end, title, _color in SECTION_GROUPS:
            ws.cell(row=1, column=start, value=title)
            for c in range(start, end + 1):
                ws.cell(row=3, column=c, value=HEADERS[c - 1])

        return wb

    def test_detects_true_positive_all_fees_workbook(self):
        wb = self._build_all_fees_like_workbook()
        self.assertTrue(is_all_fees_mass_update(wb))
        wb.close()

    def test_does_not_detect_adl_like_workbook(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"
        adl_headers = [
            "Prod Cd", "Share Cd", "Umbrella name", "Sub-fund name",
            "Max ADL In Fee", "ADL In Fee", "Max ADL Out Fee", "ADL Out Fee",
        ]
        for col_idx, h in enumerate(adl_headers, start=1):
            ws.cell(row=1, column=col_idx, value=h)

        self.assertFalse(is_all_fees_mass_update(wb))
        wb.close()

    def test_does_not_detect_empty_workbook(self):
        wb = openpyxl.Workbook()
        self.assertFalse(is_all_fees_mass_update(wb))
        wb.close()

    def test_does_not_falsely_detect_partial_headers(self):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Fees Review"
        ws.cell(row=1, column=1, value="Rate")
        ws.cell(row=1, column=2, value="Some other column")

        self.assertFalse(is_all_fees_mass_update(wb))
        wb.close()

    def test_detects_when_any_worksheet_matches(self):
        wb = self._build_all_fees_like_workbook()
        wb.create_sheet("Unrelated sheet")
        self.assertTrue(is_all_fees_mass_update(wb))
        wb.close()

    def test_does_not_expect_nav_valuation_date(self):
        self.assertNotIn("Nav valuation date", HEADERS)


if __name__ == "__main__":
    unittest.main()
