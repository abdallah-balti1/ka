import unittest

import openpyxl

from constants.fees_template import DATA_START_ROW, KEYS
from util.mass_update.fees_template import create_fees_template_workbook
from util.mass_update.fees_upload import parse_fees_template_workbook


class TestFeesUpload(unittest.TestCase):
    def _build_fake_row(self, sha_cd, prod_cd):
        row = {k: None for k in KEYS}
        row["sha_cd"] = sha_cd
        row["prod_cd"] = prod_cd
        row["umb_name_lbl"] = "Umbrella 1"
        row["Max Management fees Rate"] = "0.40"
        row["Max Management fees Basis of Calculation"] = "Net assets"
        return row

    def test_parses_sha_cd_and_prod_cd(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])

        parsed = parse_fees_template_workbook(wb)

        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]["sha_cd"], "sha_1")
        self.assertEqual(parsed[0]["prod_cd"], "prod_1")
        wb.close()

    def test_parses_editable_columns_values(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])

        parsed = parse_fees_template_workbook(wb)

        self.assertEqual(parsed[0]["Max Management fees Rate"], "0.40")
        self.assertEqual(
            parsed[0]["Max Management fees Basis of Calculation"], "Net assets"
        )
        wb.close()

    def test_ignores_rows_without_cosmos_id(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])
        ws = wb["Fees Review"]

        ws.cell(row=DATA_START_ROW + 1, column=1, value=None)

        parsed = parse_fees_template_workbook(wb)
        self.assertEqual(len(parsed), 1)
        wb.close()

    def test_base_columns_not_included_in_parsed_row(self):
        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])

        parsed = parse_fees_template_workbook(wb)
        self.assertNotIn("umb_name_lbl", parsed[0])
        wb.close()

    def test_missing_sheet_raises_value_error(self):
        wb = openpyxl.Workbook()
        wb.active.title = "Wrong Sheet Name"

        with self.assertRaises(ValueError):
            parse_fees_template_workbook(wb)
        wb.close()

    def test_multiple_rows_parsed_independently(self):
        row1 = self._build_fake_row("sha_1", "prod_1")
        row2 = self._build_fake_row("sha_2", "prod_2")
        row2["Max Management fees Rate"] = "0.90"
        wb = create_fees_template_workbook([row1, row2])

        parsed = parse_fees_template_workbook(wb)

        self.assertEqual(len(parsed), 2)
        self.assertEqual(parsed[0]["Max Management fees Rate"], "0.40")
        self.assertEqual(parsed[1]["Max Management fees Rate"], "0.90")
        wb.close()

    def test_parse_fees_template_file_from_bytes(self):
        """Couvre le point d'entrée alternatif (bytes -> parse), utilisé
        pour un usage isolé/tests, en plus du chemin principal via wb."""
        from io import BytesIO

        from util.mass_update.fees_upload import parse_fees_template_file

        row = self._build_fake_row("sha_1", "prod_1")
        wb = create_fees_template_workbook([row])
        buffer = BytesIO()
        wb.save(buffer)
        wb.close()
        buffer.seek(0)

        parsed = parse_fees_template_file(buffer.read())
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]["sha_cd"], "sha_1")


if __name__ == "__main__":
    unittest.main()
