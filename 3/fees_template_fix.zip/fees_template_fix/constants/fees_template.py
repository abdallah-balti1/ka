"""
Config du template Excel "Fees" généralisé (flowr_api), calquée
EXACTEMENT sur le design ET L'ORDRE RÉEL du template de référence
("ABDALLAH Template fees Update"), reconstitué colonne par colonne à
partir des captures du 10/08 :

  Base (identification) -> Subscription/Redemption/Conversion fees
  -> Management fees -> Specific & External fees (Other Costs,
  Foreign UCIs Tax, Taxe Abonnement) -> Distribution fees
  -> Charity fees -> Advisory fees

⚠️ CORRECTIONS suite au 10/08 :
  - "Nav valuation date" RETIRÉ de BASE_COLUMNS : cette colonne
    n'existe PAS dans le vrai template (confirmé : is_all_fees_mass_update
    renvoyait False car cette colonne, absente du fichier réel, cassait
    le test de sous-ensemble expected_headers.issubset(found_headers))
  - Ordre des SECTIONS corrigé : Specific & External vient après
    Management et AVANT Distribution/Charity/Advisory (pas en dernier)

PAS de section ADL in/out ici — déjà gérée par /retrieve_adl_fees_data.
PAS de section Hedging fees — pas encore dans le pivot de référence
(zone encadrée en rouge sur le template, à ajouter plus tard une fois
les codes confirmés).
"""

from typing import Dict, List, Tuple

SHEET_NAME = "Fees Review"

# --- Styles ---
FONT_NAME = "Arial"
FONT_SIZE = 8
BORDER_COLOR = "000000"
EDIT_FILL_COLOR = "FFF2CC"

COLOR_BASE = "8496B0"
COLOR_SUBS_RED_CONV = "1F6F43"
COLOR_MANAGEMENT = "1F7A72"
COLOR_SPECIFIC_EXTERNAL = "1F3864"
COLOR_DISTRIB_CHARITY = "1F6F43"
COLOR_ADVISORY = "1F6F43"

SECTION_ROW_HEIGHT = 18
SUBSECTION_ROW_HEIGHT = 18
COLUMN_LABEL_ROW_HEIGHT = 30

DATA_VALIDATION_ERROR_TITLE = "Valeur invalide"
DATA_VALIDATION_ERROR_MESSAGE = (
    "Merci de saisir un nombre réel positif (ou de laisser la cellule vide)."
)

SECTION_TITLE_ROW = 1
SUBSECTION_TITLE_ROW = 2
COLUMN_LABEL_ROW = 3
DATA_START_ROW = 4

# --- Colonnes d'identification (non éditables, fusionnées verticalement) ---
COSMOS_ID_KEY = "sha_cd"
PROD_CD_KEY = "prod_cd"

BASE_COLUMNS: List[Tuple[str, str]] = [
    ("Cosmos ID", COSMOS_ID_KEY),        # technique, cachée
    ("Product Cd", PROD_CD_KEY),         # technique, cachée
    ("Umbrella name", "umb_name_lbl"),
    ("Sub-fund name", "sbf_name"),
    ("Sub-fund ALADDIN code", "prod_cd_valu"),
    ("Sub-fund MFFA code", "prod_cd_mffa"),
    ("Sub-fund status", "sbf_stat_lbl"),
    ("Share name", "sha_name"),
    ("ISIN code", "isin_cd"),
    ("Share status", "sha_stat_lbl"),
    # PAS de "Nav valuation date" — confirmé absent du vrai template
]

# --- Sections de fees, TOUTES éditables — ORDRE RÉEL confirmé le 10/08 ---
SECTIONS: List[Dict] = [
    {
        "title": "Subscription/Redemption/Conversion fees",
        "color": COLOR_SUBS_RED_CONV,
        "subsections": [
            {
                "subtitle": "Subscription fees",
                "columns": [
                    ("Acquired MAX Rate", "Subscription Acquired MAX Rate"),
                    ("Non Acquired MAX Rate", "Subscription Non Acquired MAX Rate"),
                ],
            },
            {
                "subtitle": "Redemption fees",
                "columns": [
                    ("Acquired MAX Rate", "Redemption Acquired MAX Rate"),
                    ("Non Acquired MAX Rate", "Redemption Non Acquired MAX Rate"),
                ],
            },
            {
                "subtitle": "Conversion fees",
                "columns": [("Conversion Rate", "Conversion Rate")],
            },
        ],
    },
    {
        "title": "Management fees",
        "color": COLOR_MANAGEMENT,
        "subsections": [
            {
                "subtitle": "Maximum Management fees",
                "columns": [
                    ("Rate", "Max Management fees Rate"),
                    ("Basis of Calculation", "Max Management fees Basis of Calculation"),
                    ("Calculation Frequency", "Max Management fees Calculation Frequency"),
                    ("Payment Frequency", "Max Management fees Payment Frequency"),
                ],
            },
            {
                "subtitle": "Real Management fees",
                "columns": [
                    ("Rate", "Real Management fees Rate"),
                    ("Basis of Calculation", "Real Management fees Basis of Calculation"),
                    ("Calculation Frequency", "Real Management fees Calculation Frequency"),
                    ("Payment Frequency", "Real Management fees Payment Frequency"),
                ],
            },
        ],
    },
    {
        "title": "Specific & External fees",
        "color": COLOR_SPECIFIC_EXTERNAL,
        "subsections": [
            {
                "subtitle": "Max Other Costs",
                "columns": [
                    ("Rate", "Max Other Costs Rate"),
                    ("Basis of Calculation", "Max Other Costs Basis of Calculation"),
                    ("Calculation Frequency", "Max Other Costs Calculation Frequency"),
                    ("Payment Frequency", "Max Other Costs Payment Frequency"),
                    ("Paid To", "Max Other Costs Paid To"),
                ],
            },
            {
                "subtitle": "Real Other Costs",
                "columns": [
                    ("Rate", "Real Other Costs Rate"),
                    ("Basis of Calculation", "Real Other Costs Basis of Calculation"),
                    ("Calculation Frequency", "Real Other Costs Calculation Frequency"),
                    ("Payment Frequency", "Real Other Costs Payment Frequency"),
                    ("Paid To", "Real Other Costs Paid To"),
                ],
            },
            {
                "subtitle": "Max Foreign UCIs Tax",
                "columns": [
                    ("Rate", "Max Foreign UCIs Tax Rate"),
                    ("Basis of Calculation", "Max Foreign UCIs Tax Basis of Calculation"),
                    ("Calculation Frequency", "Max Foreign UCIs Tax Calculation Frequency"),
                    ("Payment Frequency", "Max Foreign UCIs Tax Payment Frequency"),
                    ("Paid To", "Max Foreign UCIs Tax Paid To"),
                ],
            },
            {
                "subtitle": "Real Foreign UCIs Tax",
                "columns": [
                    ("Rate", "Real Foreign UCIs Tax Rate"),
                    ("Basis of Calculation", "Real Foreign UCIs Tax Basis of Calculation"),
                    ("Calculation Frequency", "Real Foreign UCIs Tax Calculation Frequency"),
                    ("Payment Frequency", "Real Foreign UCIs Tax Payment Frequency"),
                    ("Paid To", "Real Foreign UCIs Tax Paid To"),
                ],
            },
            {
                "subtitle": "Max Taxe Abonnement",
                "columns": [
                    ("Rate", "Max Taxe Abonnement Rate"),
                    ("Basis of Calculation", "Max Taxe Abonnement Basis of Calculation"),
                    ("Calculation Frequency", "Max Taxe Abonnement Calculation Frequency"),
                    ("Payment Frequency", "Max Taxe Abonnement Payment Frequency"),
                    ("Paid To", "Max Taxe Abonnement Paid To"),
                ],
            },
            {
                "subtitle": "Real Taxe Abonnement",
                "columns": [
                    ("Rate", "Real Taxe Abonnement Rate"),
                    ("Basis of Calculation", "Real Taxe Abonnement Basis of Calculation"),
                    ("Calculation Frequency", "Real Taxe Abonnement Calculation Frequency"),
                    ("Payment Frequency", "Real Taxe Abonnement Payment Frequency"),
                    ("Paid To", "Real Taxe Abonnement Paid To"),
                ],
            },
        ],
    },
    {
        "title": "Distribution fees",
        "color": COLOR_DISTRIB_CHARITY,
        "subsections": [
            {
                "subtitle": "Maximum Distribution fees",
                "columns": [
                    ("Rate", "Max Distribution fees Rate"),
                    ("Basis of Calculation", "Max Distribution fees Basis of Calculation"),
                    ("Calculation Frequency", "Max Distribution fees Calculation Frequency"),
                    ("Payment Frequency", "Max Distribution fees Payment Frequency"),
                ],
            },
            {
                "subtitle": "Real Distribution fees",
                "columns": [
                    ("Rate", "Real Distribution fees Rate"),
                    ("Basis of Calculation", "Real Distribution fees Basis of Calculation"),
                    ("Calculation Frequency", "Real Distribution fees Calculation Frequency"),
                    ("Payment Frequency", "Real Distribution fees Payment Frequency"),
                ],
            },
        ],
    },
    {
        "title": "Charity fees",
        "color": COLOR_DISTRIB_CHARITY,
        "subsections": [
            {
                "subtitle": "Maximum Charity fees",
                "columns": [
                    ("Rate", "Max Charity fees Rate"),
                    ("Basis of Calculation", "Max Charity fees Basis of Calculation"),
                    ("Calculation Frequency", "Max Charity fees Calculation Frequency"),
                    ("Payment Frequency", "Max Charity fees Payment Frequency"),
                ],
            },
            {
                "subtitle": "Real Charity fees",
                "columns": [
                    ("Rate", "Real Charity fees Rate"),
                    ("Basis of Calculation", "Real Charity fees Basis of Calculation"),
                    ("Calculation Frequency", "Real Charity fees Calculation Frequency"),
                    ("Payment Frequency", "Real Charity fees Payment Frequency"),
                ],
            },
        ],
    },
    {
        "title": "Advisory fees",
        "color": COLOR_ADVISORY,
        "subsections": [
            {
                "subtitle": "Maximum Advisory fees",
                "columns": [
                    ("Rate", "Max Advisory fees Rate"),
                    ("Basis of Calculation", "Max Advisory fees Basis of Calculation"),
                    ("Calculation Frequency", "Max Advisory fees Calculation Frequency"),
                    ("Payment Frequency", "Max Advisory fees Payment Frequency"),
                ],
            },
            {
                "subtitle": "Real Advisory fees",
                "columns": [
                    ("Rate", "Real Advisory fees Rate"),
                    ("Basis of Calculation", "Real Advisory fees Basis of Calculation"),
                    ("Calculation Frequency", "Real Advisory fees Calculation Frequency"),
                    ("Payment Frequency", "Real Advisory fees Payment Frequency"),
                ],
            },
        ],
    },
    # TODO : Hedging fees — pas encore dans le pivot de référence (zone
    # encadrée en rouge sur le template), codes DB à confirmer avant ajout.
]

# -----------------------------------------------------------------------------
# Génération automatique — ne pas éditer à la main en dessous de cette ligne.
# -----------------------------------------------------------------------------

N_BASE_COLUMNS = len(BASE_COLUMNS)

HEADERS: List[str] = [label for label, _ in BASE_COLUMNS]
KEYS: List[str] = [key for _, key in BASE_COLUMNS]

SECTION_GROUPS: List[Tuple[int, int, str, str]] = []
SUBSECTION_GROUPS: List[Tuple[int, int, str, str]] = []

EDITABLE_COLUMNS: List[int] = []

_current_col = N_BASE_COLUMNS + 1
for section in SECTIONS:
    section_start = _current_col
    for subsection in section["subsections"]:
        subsection_start = _current_col
        for label, key in subsection["columns"]:
            HEADERS.append(label)
            KEYS.append(key)
            EDITABLE_COLUMNS.append(_current_col)
            _current_col += 1
        SUBSECTION_GROUPS.append(
            (subsection_start, _current_col - 1, subsection["subtitle"], section["color"])
        )
    SECTION_GROUPS.append((section_start, _current_col - 1, section["title"], section["color"]))

TOTAL_COLUMNS = len(HEADERS)

NUMERIC_EDITABLE_COLUMNS: List[int] = [
    idx for idx in EDITABLE_COLUMNS if HEADERS[idx - 1].endswith("Rate")
]
TEXT_EDITABLE_COLUMNS: List[int] = [
    idx for idx in EDITABLE_COLUMNS if idx not in NUMERIC_EDITABLE_COLUMNS
]

COSMOS_ID_COLUMN_INDEX = 1
PROD_CD_COLUMN_INDEX = 2

COL_WIDTHS: Dict[int, int] = {}
for idx, (label, _) in enumerate(BASE_COLUMNS, start=1):
    COL_WIDTHS[idx] = 12 if label in ("Cosmos ID", "Product Cd") else 22
for idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
    COL_WIDTHS[idx] = 16
