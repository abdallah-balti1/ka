"""
Test critique : simule un classeur avec la structure EXACTE du vrai
template de référence (headers réels, sans Nav valuation date, dans
le bon ordre), et vérifie que is_all_fees_mass_update le détecte
correctement — c'est le test qui a échoué en prod le 10/08.

Lancer avec :
    python tests/test_detection_against_real_template_shape.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import openpyxl  # noqa: E402

from constants.fees_template import (  # noqa: E402
    COLUMN_LABEL_ROW,
    HEADERS,
    SECTION_TITLE_ROW,
    SECTION_GROUPS,
    N_BASE_COLUMNS,
)


def _get_headers_from_rows(ws, row_indices):
    headers = set()
    for row_index in row_indices:
        headers |= {
            str(cell.value).strip()
            for cell in ws[row_index]
            if cell.value is not None and str(cell.value).strip()
        }
    return headers


def _is_all_fees_worksheet(ws):
    expected_headers = set(HEADERS)
    found_headers = _get_headers_from_rows(ws, (SECTION_TITLE_ROW, COLUMN_LABEL_ROW))
    return expected_headers.issubset(found_headers)


def _build_real_template_like_workbook():
    """Construit un classeur avec exactement la structure du vrai
    template : base columns sur row1 (comme des en-têtes simples,
    pas nécessairement fusionnés pour ce test), section titles sur
    row1, sous-section titles row2, colonnes individuelles row3 —
    et surtout SANS Nav valuation date."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Fees Review"

    col = 1
    for label, _ in [
        ("Cosmos ID", None), ("Product Cd", None), ("Umbrella name", None),
        ("Sub-fund name", None), ("Sub-fund ALADDIN code", None),
        ("Sub-fund MFFA code", None), ("Sub-fund status", None),
        ("Share name", None), ("ISIN code", None), ("Share status", None),
    ]:
        ws.cell(row=1, column=col, value=label)
        col += 1

    for start, end, title, _color in SECTION_GROUPS:
        ws.cell(row=1, column=start, value=title)
        for c in range(start, end + 1):
            ws.cell(row=3, column=c, value=HEADERS[c - 1])

    return wb


def test_detection_matches_real_template_shape():
    wb = _build_real_template_like_workbook()
    ws = wb["Fees Review"]

    result = _is_all_fees_worksheet(ws)
    assert result is True, (
        "La détection échoue sur un fichier qui a EXACTEMENT la forme "
        "du vrai template — c'est le bug du 10/08"
    )
    print("✅ test_detection_matches_real_template_shape OK")


def test_detection_fails_if_nav_valuation_date_still_expected():
    """Test de non-régression : si jamais quelqu'un rajoute
    'Nav valuation date' dans HEADERS sans l'ajouter au fichier réel,
    ce test doit échouer pour qu'on s'en rende compte immédiatement."""
    wb = _build_real_template_like_workbook()
    ws = wb["Fees Review"]

    fake_expected = set(HEADERS) | {"Nav valuation date"}
    found = _get_headers_from_rows(ws, (SECTION_TITLE_ROW, COLUMN_LABEL_ROW))

    assert not fake_expected.issubset(found), (
        "Ce test doit échouer si on ajoute Nav valuation date aux "
        "attendus sans l'ajouter au fichier — confirme que le bug du "
        "10/08 est bien reproduit par ce scénario"
    )
    print("✅ test_detection_fails_if_nav_valuation_date_still_expected OK (bug bien reproduit)")


if __name__ == "__main__":
    test_detection_matches_real_template_shape()
    test_detection_fails_if_nav_valuation_date_still_expected()
    print("\n🎉 Tous les tests passent.")
