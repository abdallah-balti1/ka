"""
Parsing du fichier Excel "Fees" réuploadé.

⚠️ Mise à jour : extrait maintenant aussi "prod_cd" (2e colonne
technique cachée, à côté de "Cosmos ID"/sha_cd) — nécessaire pour
grouper les CreData par product_id avant l'envoi à Cosmos, comme le
fait le flux ADL existant (cre_data_list_by_product_id).

⚠️ Ajoute une colonne à BASE_COLUMNS dans constants/fees_template.py :
    ("Product Cd", "prod_cd"),
juste après ("Cosmos ID", "sha_cd") — et pense à l'ajouter aussi à la
liste des colonnes cachées dans hide_technical_colums() côté générateur
(util/mass_update/fees_template.py).
"""

from io import BytesIO
from typing import Dict, List

from openpyxl import load_workbook
from openpyxl.workbook import Workbook

from constants.fees_template import (
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    EDITABLE_COLUMNS,
    KEYS,
    PROD_CD_COLUMN_INDEX,
    SHEET_NAME,
)


def parse_fees_template_workbook(wb: Workbook) -> List[Dict]:
    """
    Retourne une liste de dicts, un par ligne de données du fichier :
      {"sha_cd": "41455", "prod_cd": "42735", "Max Management fees Rate": "0.4", ...}
    """
    if SHEET_NAME not in wb.sheetnames:
        raise ValueError(
            f"Feuille '{SHEET_NAME}' introuvable dans le fichier uploadé "
            f"(feuilles présentes : {wb.sheetnames})"
        )
    ws = wb[SHEET_NAME]

    rows: List[Dict] = []
    row_idx = DATA_START_ROW
    while row_idx <= ws.max_row:
        sha_cd = ws.cell(row=row_idx, column=COSMOS_ID_COLUMN_INDEX).value
        if sha_cd is None or str(sha_cd).strip() == "":
            row_idx += 1
            continue

        prod_cd = ws.cell(row=row_idx, column=PROD_CD_COLUMN_INDEX).value

        row_data = {
            "sha_cd": str(sha_cd).strip(),
            "prod_cd": str(prod_cd).strip() if prod_cd is not None else None,
        }
        for col_idx in EDITABLE_COLUMNS:
            key = KEYS[col_idx - 1]
            value = ws.cell(row=row_idx, column=col_idx).value
            row_data[key] = value

        rows.append(row_data)
        row_idx += 1

    return rows


def parse_fees_template_file(file_bytes: bytes) -> List[Dict]:
    wb = load_workbook(filename=BytesIO(file_bytes), data_only=True)
    return parse_fees_template_workbook(wb)
