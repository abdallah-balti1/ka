"""
Mapping entre une colonne éditable du template "All Fees" et les
métadonnées attendues par Cosmos pour construire un CreData
(PIVOT_FIELD_NAME, IDENTIFICATION_FIELDS) — sur le modèle du flux ADL
existant (constants/other_constants.py), mais calculé dynamiquement
puisque notre template couvre plusieurs subtypes et plusieurs champs
DB, contrairement à l'ADL qui n'en a qu'un de chaque.

Codes FEES_SUB_TYPE confirmés (export métier du 07/08) :
  1 = Financial management fees   (Management)
  2 = Advisory fees
  3 = Distribution fees
  4 = Charity fees
  5 = Specific fees / External fees (Other Costs, Foreign UCIs Tax, Taxe Abonnement)
  6 = Performance fees   (non couvert par notre template)
  7 = Subscription fees (D)
  8 = Redemption fees (D)
  9 = Conversions fees
"""

FEES_TYP_CD = "2"  # "Direct Fees", identique pour tout le template

SUBTYPE_MANAGEMENT = "1"
SUBTYPE_ADVISORY = "2"
SUBTYPE_DISTRIBUTION = "3"
SUBTYPE_CHARITY = "4"
SUBTYPE_SPECIFIC_EXTERNAL = "5"
SUBTYPE_SUBSCRIPTION = "7"
SUBTYPE_REDEMPTION = "8"
SUBTYPE_CONVERSION = "9"

# Ordre important : on cherche le premier mot-clé qui matche dans le
# libellé de colonne (ex: "Max Management fees Rate" contient
# "Management fees"). Les entrées les plus spécifiques doivent être
# vérifiées avant les plus génériques si jamais il y a un risque de
# chevauchement (aucun connu actuellement).
SUBTYPE_BY_KEYWORD = [
    ("Management fees", SUBTYPE_MANAGEMENT),
    ("Advisory fees", SUBTYPE_ADVISORY),
    ("Distribution fees", SUBTYPE_DISTRIBUTION),
    ("Charity fees", SUBTYPE_CHARITY),
    ("Other Costs", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Foreign UCIs Tax", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Taxe Abonnement", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Subscription", SUBTYPE_SUBSCRIPTION),
    ("Redemption", SUBTYPE_REDEMPTION),
    ("Conversion", SUBTYPE_CONVERSION),
]

# Suffixe du libellé de colonne -> nom de champ PascalCase attendu par
# Cosmos (PIVOT_FIELD_NAME). "Rate" confirmé (FeesPctg, déjà utilisé
# pour l'ADL) ; les autres sont une proposition calquée sur le même
# style de nommage, À CONFIRMER avant le premier envoi réel.
PIVOT_FIELD_NAME_BY_SUFFIX = [
    ("Rate", "FeesPctg"),
    ("Basis of Calculation", "BasisCalcCd"),
    ("Calculation Frequency", "CalcFrqCd"),
    ("Payment Frequency", "PmtFrqCd"),
    ("Paid To", "FeesPaidCd"),
]


def get_identification_fields(column_label: str) -> dict:
    """
    Retourne {"FeesTypCd": "2", "FeesSubtypeCd": "<code>"} pour la
    colonne donnée, en se basant sur le mot-clé de section présent
    dans son libellé.

    Lève ValueError si aucun mot-clé connu n'est trouvé — mieux vaut
    échouer bruyamment que d'envoyer un event à Cosmos avec un
    identification_fields incorrect ou manquant.
    """
    for keyword, subtype in SUBTYPE_BY_KEYWORD:
        if keyword in column_label:
            return {"FeesTypCd": FEES_TYP_CD, "FeesSubtypeCd": subtype}
    raise ValueError(
        f"Impossible de déterminer le FeesSubtypeCd pour la colonne "
        f"'{column_label}' — aucun mot-clé connu trouvé dans son libellé."
    )


def get_pivot_field_name(column_label: str) -> str:
    """
    Retourne le PIVOT_FIELD_NAME (nom de champ PascalCase côté Cosmos)
    pour la colonne donnée, en se basant sur son suffixe.

    Lève ValueError si aucun suffixe connu n'est trouvé.
    """
    for suffix, field_name in PIVOT_FIELD_NAME_BY_SUFFIX:
        if column_label.endswith(suffix):
            return field_name
    raise ValueError(
        f"Impossible de déterminer le PIVOT_FIELD_NAME pour la colonne "
        f"'{column_label}' — aucun suffixe connu trouvé."
    )
