# -----------------------------------------------------------------------------
# À AJOUTER dans src/constants/other_constants.py (ou un nouveau fichier
# constants/fees_cre_constants.py si tu préfères séparer) — valeurs
# CONFIRMÉES par toi (captures du 07/08) :
#   PARENT_ENTITY_TYPE = "Fees"
#   ENTITY_TYPE = "ProductFee"
#   PIVOT_NAME = "ProductFee"
# déjà présentes dans other_constants.py — pas besoin de les redéfinir,
# on les réutilise directement dans fee_cre_builder.py.
# -----------------------------------------------------------------------------
