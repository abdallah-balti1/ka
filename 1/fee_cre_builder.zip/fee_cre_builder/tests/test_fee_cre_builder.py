"""
Test de build_cre_data_for_all_fees, avec un stub CreData (simple objet
qui capture ses kwargs) pour ne pas dépendre du vrai module entities.

Lancer avec :
    python tests/test_fee_cre_builder.py
"""

import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# --- Stubs pour les dépendances non disponibles dans cet environnement isolé ---


class _CreDataStub:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __repr__(self):
        return f"CreData({self.__dict__})"


entities_stub = types.ModuleType("entities")
entities_stub.CreData = _CreDataStub
sys.modules["entities"] = entities_stub

import constants  # package réel (déjà présent avec __init__.py)
constants.MODIFY_ACTION = "MODIFY"

other_constants_stub = types.ModuleType("constants.other_constants")
other_constants_stub.PARENT_ENTITY_TYPE = "Fees"
other_constants_stub.ENTITY_TYPE = "ProductFee"
other_constants_stub.PIVOT_NAME = "ProductFee"
sys.modules["constants.other_constants"] = other_constants_stub


from services.fee_cre_builder import build_cre_data_for_all_fees  # noqa: E402


class _FakeTask:
    id = "TASK123"


def test_builds_cre_data_grouped_by_product():
    diffs = [
        {
            "sha_cd": "41455",
            "prod_cd": "42735",
            "field": "Max Management fees Rate",
            "old_value": "0.4",
            "new_value": "0.5",
            "fee_id": "FEE1",
            "fee_value_id": "VAL1",
        },
        {
            "sha_cd": "41455",
            "prod_cd": "42735",
            "field": "Max Management fees Basis of Calculation",
            "old_value": "Net assets",
            "new_value": "Net income",
            "fee_id": "FEE2",
            "fee_value_id": "VAL2",
        },
        {
            "sha_cd": "99999",
            "prod_cd": "88888",  # produit différent
            "field": "Real Charity fees Rate",
            "old_value": "0.1",
            "new_value": "0.2",
            "fee_id": "FEE3",
            "fee_value_id": "VAL3",
        },
    ]
    user = {"fullname": "Abdou Test"}
    task = _FakeTask()

    cre_data_by_product, mapping, skipped = build_cre_data_for_all_fees(user, task, diffs)

    assert set(cre_data_by_product.keys()) == {"42735", "88888"}
    assert len(cre_data_by_product["42735"]) == 2
    assert len(cre_data_by_product["88888"]) == 1
    assert skipped == []
    print("✅ test_builds_cre_data_grouped_by_product OK")


def test_cre_data_has_correct_fields():
    diffs = [
        {
            "sha_cd": "41455",
            "prod_cd": "42735",
            "field": "Max Management fees Rate",
            "old_value": "0.4",
            "new_value": "0.5",
            "fee_id": "FEE1",
            "fee_value_id": "VAL1",
        }
    ]
    user = {"fullname": "Abdou Test"}
    task = _FakeTask()

    cre_data_by_product, _, _ = build_cre_data_for_all_fees(user, task, diffs)
    cd = cre_data_by_product["42735"][0]

    assert cd.parent_entity_type == "Fees"
    assert cd.parent_entity_id == "FEE1"
    assert cd.entity_type == "ProductFee"
    assert cd.entity_id == "VAL1"
    assert cd.old_value == "0.4"
    assert cd.new_value == "0.5"
    assert cd.pivot_field_name == "FeesPctg"
    assert cd.pivot_name == "ProductFee"
    assert cd.identification_fields == {"FeesTypCd": "2", "FeesSubtypeCd": "1"}
    assert cd.author == "Abdou Test"
    assert cd.task_id == "TASK123"
    print("✅ test_cre_data_has_correct_fields OK")


def test_missing_fee_id_is_skipped_not_guessed():
    diffs = [
        {
            "sha_cd": "41455",
            "prod_cd": "42735",
            "field": "Max Management fees Rate",
            "old_value": None,
            "new_value": "0.5",
            "fee_id": None,  # fee jamais créée en base
            "fee_value_id": None,
        }
    ]
    user = {"fullname": "Abdou Test"}
    task = _FakeTask()

    cre_data_by_product, _, skipped = build_cre_data_for_all_fees(user, task, diffs)

    assert cre_data_by_product == {}
    assert len(skipped) == 1
    assert skipped[0]["field"] == "Max Management fees Rate"
    print("✅ test_missing_fee_id_is_skipped_not_guessed OK")


if __name__ == "__main__":
    test_builds_cre_data_grouped_by_product()
    test_cre_data_has_correct_fields()
    test_missing_fee_id_is_skipped_not_guessed()
    print("\n🎉 Tous les tests passent.")
