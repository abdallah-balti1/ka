"""
Test CRITIQUE : vérifie que get_pivot_field_name / get_identification_fields
résolvent SANS ERREUR pour CHACUNE des colonnes éditables réelles du
template (KEYS[EDITABLE_COLUMNS]). Si une seule colonne échoue ici, le
mass update plantera en prod dès qu'un utilisateur modifiera cette
colonne — donc ce test doit couvrir 100% des colonnes éditables.

Lancer avec :
    python tests/test_fees_cre_mapping_coverage.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from constants.fees_cre_mapping import (  # noqa: E402
    get_identification_fields,
    get_pivot_field_name,
)
from constants.fees_template import EDITABLE_COLUMNS, KEYS  # noqa: E402


def test_every_editable_column_resolves_identification_fields():
    failures = []
    for idx in EDITABLE_COLUMNS:
        column_label = KEYS[idx - 1]
        try:
            result = get_identification_fields(column_label)
            assert "FeesTypCd" in result and "FeesSubtypeCd" in result
        except ValueError as e:
            failures.append((column_label, str(e)))

    assert not failures, (
        f"{len(failures)} colonne(s) sans identification_fields résolu :\n"
        + "\n".join(f"  - {label}" for label, _ in failures)
    )
    print(
        f"✅ test_every_editable_column_resolves_identification_fields OK "
        f"({len(EDITABLE_COLUMNS)} colonnes couvertes)"
    )


def test_every_editable_column_resolves_pivot_field_name():
    failures = []
    for idx in EDITABLE_COLUMNS:
        column_label = KEYS[idx - 1]
        try:
            get_pivot_field_name(column_label)
        except ValueError as e:
            failures.append((column_label, str(e)))

    assert not failures, (
        f"{len(failures)} colonne(s) sans pivot_field_name résolu :\n"
        + "\n".join(f"  - {label}" for label, _ in failures)
    )
    print(
        f"✅ test_every_editable_column_resolves_pivot_field_name OK "
        f"({len(EDITABLE_COLUMNS)} colonnes couvertes)"
    )


def test_spot_check_known_values():
    """Vérifie quelques valeurs précises, pas juste l'absence d'erreur."""
    assert get_identification_fields("Max Management fees Rate") == {
        "FeesTypCd": "2",
        "FeesSubtypeCd": "1",
    }
    assert get_identification_fields("Real Taxe Abonnement Paid To") == {
        "FeesTypCd": "2",
        "FeesSubtypeCd": "5",
    }
    assert get_identification_fields("Redemption Acquired MAX Rate") == {
        "FeesTypCd": "2",
        "FeesSubtypeCd": "8",
    }
    assert get_pivot_field_name("Max Management fees Rate") == "FeesPctg"
    assert get_pivot_field_name("Real Charity fees Basis of Calculation") == "BasisCalcCd"
    assert get_pivot_field_name("Max Other Costs Paid To") == "FeesPaidCd"
    print("✅ test_spot_check_known_values OK")


def test_unknown_column_raises_value_error():
    try:
        get_identification_fields("Some Totally Unknown Column")
        assert False, "aurait dû lever ValueError"
    except ValueError:
        pass
    print("✅ test_unknown_column_raises_value_error OK")


if __name__ == "__main__":
    test_every_editable_column_resolves_identification_fields()
    test_every_editable_column_resolves_pivot_field_name()
    test_spot_check_known_values()
    test_unknown_column_raises_value_error()
    print("\n🎉 Tous les tests passent.")
