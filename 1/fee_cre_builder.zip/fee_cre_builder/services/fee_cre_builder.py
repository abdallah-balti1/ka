"""
Transforme la liste de diffs (FeeDiffService.build_diff) en CreData
groupés par product_id, prêts à être envoyés à Cosmos via send_cre,
exactement comme create_cre_data_for_mass_update_fees_to_send_to_cosmos
pour l'ADL.

Réutilise les constantes fixes déjà confirmées dans
constants/other_constants.py :
    PARENT_ENTITY_TYPE = "Fees"
    ENTITY_TYPE = "ProductFee"
    PIVOT_NAME = "ProductFee"
et calcule pivot_field_name / identification_fields dynamiquement par
champ via constants/fees_cre_mapping.py (contrairement à l'ADL où ces
deux valeurs sont fixes, notre template couvre plusieurs subtypes et
plusieurs champs DB).

⚠️ CAS NON GÉRÉ POUR L'INSTANT : une ligne où fee_id/fee_value_id sont
None (l'utilisateur a rempli une valeur pour un fee qui n'existait pas
du tout en base pour ce share) correspondrait à une CREATE_ACTION,
pas une MODIFY_ACTION — ce cas est actuellement exclu et retourné à
part (skipped_new_fees) plutôt que d'être envoyé avec des valeurs
devinées. À traiter explicitement avant la mise en prod si ce cas est
possible côté métier (probablement rare : ça suppose qu'un utilisateur
ajoute un TOUT nouveau type de fee à un produit qui n'en avait aucun).
"""

from collections import defaultdict
from typing import Dict, List, Tuple

from constants.fees_cre_mapping import get_identification_fields, get_pivot_field_name
from constants.other_constants import ENTITY_TYPE, PARENT_ENTITY_TYPE, PIVOT_NAME
from constants import MODIFY_ACTION
from entities import CreData


def build_cre_data_for_all_fees(
    user: dict, task, diffs: List[Dict]
) -> Tuple[Dict[str, List], Dict, List[Dict]]:
    """
    diffs : sortie de FeeDiffService.build_diff

    Retourne :
      - cre_data_list_by_product_id : {prod_cd: [CreData, ...]}
      - mapping_entity_line_dict : {} pour l'instant (pas de cas CREATE
        géré, donc rien à mapper pour le reporting d'erreurs ligne par
        ligne — cf. docstring du module)
      - skipped_new_fees : diffs ignorés car fee_id/fee_value_id
        manquants (cas CREATE non géré) — à logger / signaler à
        l'utilisateur plutôt qu'à silencieusement perdre
    """
    cre_data_list_by_product_id: Dict[str, List] = defaultdict(list)
    mapping_entity_line_dict: Dict = {}
    skipped_new_fees: List[Dict] = []

    for diff in diffs:
        if diff.get("fee_id") is None or diff.get("fee_value_id") is None:
            skipped_new_fees.append(diff)
            continue

        cre_data = CreData(
            parent_entity_type=PARENT_ENTITY_TYPE,
            parent_entity_id=diff["fee_id"],
            entity_type=ENTITY_TYPE,
            entity_id=diff["fee_value_id"],
            old_value=str(diff["old_value"]) if diff["old_value"] is not None else None,
            new_value=str(diff["new_value"]) if diff["new_value"] is not None else None,
            entity_action=MODIFY_ACTION,
            task_id=task.id,
            is_parent_entity_from_plm=True,
            is_entity_from_plm=MODIFY_ACTION,
            pivot_field_name=get_pivot_field_name(diff["field"]),
            pivot_name=PIVOT_NAME,
            identification_fields=get_identification_fields(diff["field"]),
            author=user["fullname"],
        )
        cre_data_list_by_product_id[diff["prod_cd"]].append(cre_data)

    return cre_data_list_by_product_id, mapping_entity_line_dict, skipped_new_fees
