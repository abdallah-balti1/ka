"""
Test de la logique métier de RefetchFeesDataResource.post — la partie
qui garantit une entrée par sha_cd demandé, même sans fee trouvée.
Sans DB, sans Flask : on isole juste cette logique.

Lancer avec :
    python tests/test_refetch_completion_logic.py
"""


def complete_result(sha_cd_list, fee_columns):
    """Reproduit la ligne clé de la resource, isolée pour test."""
    return {sha_cd: fee_columns.get(sha_cd, {}) for sha_cd in sha_cd_list}


def test_all_requested_sha_cds_present_even_without_fees():
    sha_cd_list = ["A", "B", "C"]
    fee_columns = {"A": {"Rate": "0.4"}}  # B et C n'ont aucune fee en base

    result = complete_result(sha_cd_list, fee_columns)

    assert set(result.keys()) == {"A", "B", "C"}, (
        "Tous les sha_cd demandés doivent apparaître dans le résultat, "
        "même sans fee associée"
    )
    assert result["B"] == {}
    assert result["C"] == {}
    assert result["A"] == {"Rate": "0.4"}
    print("✅ test_all_requested_sha_cds_present_even_without_fees OK")


def test_empty_sha_cd_list_returns_empty_dict():
    assert complete_result([], {"A": {"Rate": "0.4"}}) == {}
    print("✅ test_empty_sha_cd_list_returns_empty_dict OK")


def test_duplicate_sha_cd_in_list_deduplicated_by_dict():
    result = complete_result(["A", "A"], {"A": {"Rate": "0.4"}})
    assert result == {"A": {"Rate": "0.4"}}
    print("✅ test_duplicate_sha_cd_in_list_deduplicated_by_dict OK")


if __name__ == "__main__":
    test_all_requested_sha_cds_present_even_without_fees()
    test_empty_sha_cd_list_returns_empty_dict()
    test_duplicate_sha_cd_in_list_deduplicated_by_dict()
    print("\n🎉 Tous les tests passent.")
