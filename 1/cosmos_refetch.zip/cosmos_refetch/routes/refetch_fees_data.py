from flask import Blueprint
from flask_restful import Api

from resources.refetch_fees_data import RefetchFeesDataResource

REFETCH_FEES_DATA_BLUEPRINT = Blueprint("refetch_fees_data", __name__)

Api(REFETCH_FEES_DATA_BLUEPRINT).add_resource(
    RefetchFeesDataResource, "/refetch_fees_data", endpoint="refetch_fees_data"
)

# À enregistrer dans app.py comme les autres blueprints fees :
#   from routes.refetch_fees_data import REFETCH_FEES_DATA_BLUEPRINT
#   app.register_blueprint(REFETCH_FEES_DATA_BLUEPRINT)
