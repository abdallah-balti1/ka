from context_managers.session_critical_action_manager import SessionCriticalActionManager
from flasgger.utils import swag_from
from flask import request
from flask_restful import Resource

from config import DEV_TEAM_EMAILS
from db import db
from repositories.export_query_repository import ExportQueryRepository
from services.fee_export_service import FeeExportService
from utils.required_authentication import required_authentication


class RefetchFeesDataResource(Resource):
    """Renvoie l'état FRAIS des fees pour une liste de sha_cd donnée,
    labels déjà traduits. Utilisé par flowr_api au moment de l'upload
    pour comparer les valeurs du fichier réuploadé à l'état actuel en
    base (stratégie de diff par re-fetch, pas de colonnes dupliquées
    dans l'Excel).

    Différence avec /retrieve_fees_data : ici on part directement de
    sha_cd (pas de codes produits SIN/SUB à résoudre), donc pas de
    single_export/subfund_export — juste product_fee + field_value.
    Plus léger et plus rapide, adapté à un appel synchrone au moment
    de l'upload."""

    @staticmethod
    @required_authentication()
    @swag_from("../../swagger/refetch_fees_data/POST.yml")
    def post(user):
        data = request.get_json(silent=True) or {}

        sha_cd_list = data.get("sha_cd_list", [])
        if not isinstance(sha_cd_list, list) or not sha_cd_list:
            return {"error": "sha_cd_list is required and must be a non-empty list"}, 400

        sha_cd_list = [str(x).strip() for x in sha_cd_list if str(x).strip()]
        if not sha_cd_list:
            return {"error": "sha_cd_list is empty"}, 400

        with SessionCriticalActionManager("last_file_version", db.session, DEV_TEAM_EMAILS):
            raw_fees = ExportQueryRepository.get_raw_fees(sha_cd_list)
            fee_columns = FeeExportService.build_fee_columns(raw_fees)

        # Toujours renvoyer une entrée pour chaque sha_cd demandé, même
        # si aucune fee n'existe pour lui (toutes les colonnes à None) —
        # important pour que flowr_api sache différencier "pas de fee
        # en base" de "sha_cd inconnu/erreur".
        result = {
            sha_cd: fee_columns.get(sha_cd, {}) for sha_cd in sha_cd_list
        }

        return result, 200
