"""
Test de bout en bout de la partie upload/diff :
  1. Génère un fichier Excel avec create_fees_template_workbook
  2. Simule une modification utilisateur (change une cellule éditable)
  3. Parse le fichier modifié avec parse_fees_template_file
  4. Compare à un "état frais" simulé (ce que cosmos_api renverrait)
  5. Vérifie que FeeDiffService détecte exactement les bons changements

Sans DB, sans Flask, sans réseau — tout en mémoire.

Lancer avec :
    python tests/test_upload_diff_pipeline.py
"""

import sys
from io import BytesIO
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from constants.fees_template import KEYS  # noqa: E402
from services.fee_diff_service import FeeDiffService  # noqa: E402
from util.mass_update.fees_upload import parse_fees_template_file  # noqa: E402


def _build_fake_row(sha_cd: str) -> dict:
    row = {k: None for k in KEYS}
    row["sha_cd"] = sha_cd
    row["umb_name_lbl"] = "BNP PARIBAS EASY"
    row["sbf_name"] = "JPM ESG EMBI"
    row["isin_cd"] = "LU1291091814"
    row["Max Management fees Rate"] = "0.4"
    row["Max Management fees Basis of Calculation"] = "Net assets"
    row["Max Management fees Calculation Frequency"] = "Daily"
    row["Subscription Acquired MAX Rate"] = "0"
    row["Conversion Rate"] = "1.5"
    return row


def test_no_diff_when_nothing_changed():
    """Génère un fichier, le reparse tel quel, compare à un état frais
    identique aux données d'origine : aucune diff attendue."""
    from util.mass_update.fees_template import create_fees_template_workbook

    row = _build_fake_row("41455")
    wb = create_fees_template_workbook([row])
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    parsed_rows = parse_fees_template_file(buffer.read())
    fresh_data = {
        "41455": {k: v for k, v in row.items() if k != "sha_cd"}
    }

    diffs = FeeDiffService.build_diff(parsed_rows, fresh_data)
    assert diffs == [], f"Aucune diff attendue, obtenu : {diffs}"
    print("✅ test_no_diff_when_nothing_changed OK")


def test_detects_single_numeric_change():
    """Simule un utilisateur qui change le Rate de Management fees,
    vérifie qu'un seul diff est détecté sur le bon champ."""
    from openpyxl import load_workbook
    from constants.fees_template import DATA_START_ROW
    from util.mass_update.fees_template import create_fees_template_workbook

    row = _build_fake_row("41455")
    wb = create_fees_template_workbook([row])
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    # Simule la modification utilisateur : Max Management fees Rate 0.4 -> 0.5
    wb2 = load_workbook(buffer)
    ws = wb2["Fees Review"]
    # retrouve la colonne "Max Management fees Rate" par son header (ligne 3)
    target_col = None
    for c in range(1, ws.max_column + 1):
        if ws.cell(row=3, column=c).value == "Rate":
            # première colonne "Rate" rencontrée après les colonnes de base
            # correspond à Management (ordre défini dans SECTIONS)
            target_col = c
            break
    assert target_col is not None
    ws.cell(row=DATA_START_ROW, column=target_col, value="0.5")

    buffer2 = BytesIO()
    wb2.save(buffer2)
    buffer2.seek(0)

    parsed_rows = parse_fees_template_file(buffer2.read())
    fresh_data = {"41455": {k: v for k, v in row.items() if k != "sha_cd"}}

    diffs = FeeDiffService.build_diff(parsed_rows, fresh_data)

    assert len(diffs) == 1, f"Attendu 1 diff, obtenu {len(diffs)} : {diffs}"
    d = diffs[0]
    assert d["sha_cd"] == "41455"
    assert d["field"] == "Max Management fees Rate"
    assert d["old_value"] == "0.4"
    assert d["new_value"] == "0.5"
    print("✅ test_detects_single_numeric_change OK")


def test_comma_vs_dot_not_flagged_as_diff():
    """0.4 (fresh) vs '0,4' (utilisateur français) ne doit PAS être
    considéré comme une différence."""
    from services.fee_diff_service import _values_differ

    assert not _values_differ("Max Management fees Rate", "0,4", "0.4")
    assert not _values_differ("Max Management fees Rate", "0.40", "0.4")
    assert _values_differ("Max Management fees Rate", "0.5", "0.4")
    print("✅ test_comma_vs_dot_not_flagged_as_diff OK")


def test_empty_and_none_treated_as_equivalent():
    from services.fee_diff_service import _values_differ

    assert not _values_differ("Max Management fees Basis of Calculation", "", None)
    assert not _values_differ("Max Management fees Basis of Calculation", "  ", None)
    assert _values_differ("Max Management fees Basis of Calculation", "Net assets", None)
    print("✅ test_empty_and_none_treated_as_equivalent OK")


def test_text_field_change_detected():
    from services.fee_diff_service import _values_differ

    assert _values_differ(
        "Max Management fees Basis of Calculation", "Net income", "Net assets"
    )
    assert not _values_differ(
        "Max Management fees Basis of Calculation", " Net assets ", "Net assets"
    )
    print("✅ test_text_field_change_detected OK")


def test_ignores_rows_without_cosmos_id():
    """Une ligne avec Cosmos ID vide (ligne blanche en fin de tableau)
    ne doit pas apparaître dans le résultat parsé."""
    from constants.fees_template import DATA_START_ROW
    from util.mass_update.fees_template import create_fees_template_workbook
    from openpyxl import load_workbook

    row = _build_fake_row("41455")
    wb = create_fees_template_workbook([row])
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    wb2 = load_workbook(buffer)
    ws = wb2["Fees Review"]
    # ajoute une ligne vide juste après la ligne de données
    empty_row_idx = DATA_START_ROW + 1
    ws.cell(row=empty_row_idx, column=1, value=None)

    buffer2 = BytesIO()
    wb2.save(buffer2)
    buffer2.seek(0)

    parsed_rows = parse_fees_template_file(buffer2.read())
    assert len(parsed_rows) == 1, f"Attendu 1 ligne valide, obtenu {len(parsed_rows)}"
    print("✅ test_ignores_rows_without_cosmos_id OK")


if __name__ == "__main__":
    test_no_diff_when_nothing_changed()
    test_detects_single_numeric_change()
    test_comma_vs_dot_not_flagged_as_diff()
    test_empty_and_none_treated_as_equivalent()
    test_text_field_change_detected()
    test_ignores_rows_without_cosmos_id()
    print("\n🎉 Tous les tests passent.")
