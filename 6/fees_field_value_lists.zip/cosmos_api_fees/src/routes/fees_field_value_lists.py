from flask import Blueprint
from flask_restful import Api

from resources.retrieve_fees_data.fees_field_value_lists import (
    FeesFieldValueListsResource,
)

FEES_FIELD_VALUE_LISTS_BLUEPRINT = Blueprint("fees_field_value_lists", __name__)

Api(FEES_FIELD_VALUE_LISTS_BLUEPRINT).add_resource(
    FeesFieldValueListsResource,
    "/fees_field_value_lists",
    endpoint="fees_field_value_lists",
)
