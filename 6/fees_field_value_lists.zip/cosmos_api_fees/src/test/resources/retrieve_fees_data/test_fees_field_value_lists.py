import unittest
from unittest.mock import patch

from models.field_value import FieldValue
from server import server
from tests.utils import init_database


class TestFeesFieldValueListsResource(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        init_database()

        # One row per type is enough to check the grouping and the
        # is_active filter - no need to replicate the full referential.
        FieldValue(code="1", type="BASIS_OF_CALCULATION",
                   label_fr="Actif net", label_en="Net assets",
                   is_active=True).save()
        FieldValue(code="999", type="BASIS_OF_CALCULATION",
                   label_fr="Ancien code", label_en="Old code",
                   is_active=False).save()

        FieldValue(code="M", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Mensuelle", label_en="Monthly",
                   is_active=True).save()

        FieldValue(code="1", type="FEES_PAID_TO",
                   label_fr="Conservateur", label_en="Custodian",
                   is_active=True).save()

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_returns_values_grouped_by_product_fee_field(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        self.assertEqual(response.status_code, 200)
        data = response.get_json()

        self.assertEqual(data["basis_calc_cd"], {"1": "Net assets"})
        self.assertEqual(data["fees_paid_cd"], {"1": "Custodian"})

        # calc_frq_cd and pmt_frq_cd both resolve to
        # FEE_CALCULATION_FREQUENCY, so they should carry the same values.
        self.assertEqual(data["calc_frq_cd"], {"M": "Monthly"})
        self.assertEqual(data["pmt_frq_cd"], {"M": "Monthly"})

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_inactive_values_are_excluded(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertNotIn("999", data["basis_calc_cd"])


if __name__ == "__main__":
    unittest.main()
