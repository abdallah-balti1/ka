"""
Resource for Fees Field Value Lists

Exposes the field_value referentials backing the free-text fee fields of
the All Fees template (basis_calc_cd, calc_frq_cd, pmt_frq_cd,
fees_paid_cd), so flowr_api can turn those Excel cells into dropdowns
instead of leaving them free-text.

Reuses FIELD_TO_FIELD_VALUE_TYPE from field_value_types_config.py as-is -
that mapping already carries the one non-obvious decision here (pmt_frq_cd
riding on FEE_CALCULATION_FREQUENCY rather than PAYMENT_FREQUENCY), so
there's nothing to re-decide in this file.
"""

from flasgger.utils import swag_from
from flask_restful import Resource

from constants.field_value_types_config import FIELD_TO_FIELD_VALUE_TYPE
from services.field_value_cache import get_field_values
from utils.required_authentication import required_authentication


class FeesFieldValueListsResource(Resource):
    """
    Endpoint that returns the allowed values for each fee field listed in
    FIELD_TO_FIELD_VALUE_TYPE.

    calc_frq_cd and pmt_frq_cd both resolve to FEE_CALCULATION_FREQUENCY,
    so they end up with identical lists below - each still gets its own
    key, callers shouldn't need to know the two fields share a referential.

    Response Format:
        {
            "basis_calc_cd": {"1": "Net assets", ...},
            "calc_frq_cd": {"M": "Monthly", "3M": "Quarterly", ...},
            "pmt_frq_cd": {"M": "Monthly", "3M": "Quarterly", ...},
            "fees_paid_cd": {"1": "Custodian", ...}
        }
    """

    @staticmethod
    @required_authentication()
    @swag_from("../../swagger/fees_field_value_lists/GET.yml")
    def get(user):
        result = {}
        for field_name, field_value_type in FIELD_TO_FIELD_VALUE_TYPE.items():
            field_values = get_field_values(field_value_type)
            result[field_name] = {
                fv.code: fv.label_en
                for fv in field_values
                if fv.is_active
            }
        return result, 200
