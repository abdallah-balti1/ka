# --- Add to app.py ---
#
# 1. Import, next to the other resources imports:
from resources.fees_field_value_lists import FeesFieldValueLists

# 2. Route registration, next to the other api.add_resource(...) calls:
api.add_resource(FeesFieldValueLists, "/fees_field_value_lists")
