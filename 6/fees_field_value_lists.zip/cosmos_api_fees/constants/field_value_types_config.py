# Maps each free-text column of the All Fees template to its field_value type.
# CALCULATION_FREQUENCY is shared between the Calculation Frequency and
# Payment Frequency columns on the Excel side - there's only one real
# referential for both.
#
# Do not use PAYMENT_FREQUENECY (yes, that's the actual name in DB, typo and
# all). It looks like the right fit for the Payment Frequency column but its
# codes are a different, incompatible referential.

FEES_FIELD_VALUE_TYPES = {
    "BASIS_OF_CALCULATION": "BASIS_OF_CALCULATION",
    "CALCULATION_FREQUENCY": "CALCULATION_FREQUENCY",
    "FEES_PAID_TO": "FEES_PAID_TO",
}
