# Maps each free-text column of the All Fees template to the field_value
# type that feeds its dropdown. Keys are what the API response groups values
# under, values are the actual `type` column in field_value.
#
# Payment Frequency has no referential of its own - it reuses
# CALCULATION_FREQUENCY under the hood, but still gets its own key here so
# the response is explicit about it rather than making flowr_api guess which
# column borrows from which.
#
# Do not use PAYMENT_FREQUENECY (yes, that's the actual name in DB, typo and
# all) for that. It looks like the right fit for the Payment Frequency
# column but its codes are a different, incompatible referential.

FEES_FIELD_VALUE_TYPES = {
    "BASIS_OF_CALCULATION": "BASIS_OF_CALCULATION",
    "CALCULATION_FREQUENCY": "CALCULATION_FREQUENCY",
    "PAYMENT_FREQUENCY": "CALCULATION_FREQUENCY",
    "FEES_PAID_TO": "FEES_PAID_TO",
}
