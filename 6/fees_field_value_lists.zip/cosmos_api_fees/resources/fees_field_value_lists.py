from flask import jsonify
from flask_restful import Resource

from constants.field_value_types_config import FEES_FIELD_VALUE_TYPES
from services.field_value_cache import get_field_values
from utils.required_authentication import required_authentication


class FeesFieldValueLists(Resource):
    """
    Returns the allowed values for the free-text fee columns (Basis of
    Calculation, Calculation Frequency, Payment Frequency, Paid To) so the
    Excel generation on the flowr_api side can build its dropdown lists.

    Not tied to a product, so no params needed here - same list for
    everyone. Backed by the existing field_value_cache, so no extra DB hit
    when the cache is warm.

    Response shape: { "<type>": { "<code>": "<label_en>", ... }, ... }
    Only active values (is_active=True) are included.
    """

    method_decorators = [required_authentication]

    def get(self):
        response = {}
        for group_name, fv_type in FEES_FIELD_VALUE_TYPES.items():
            field_values = get_field_values(fv_type)
            response[group_name] = {
                fv.code: fv.label_en
                for fv in field_values
                if fv.is_active
            }
        return jsonify(response)
