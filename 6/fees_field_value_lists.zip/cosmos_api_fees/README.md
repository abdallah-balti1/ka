# fees_field_value_lists — v2, aligned on the real project layout

Where each file goes (paths are relative to `src/`, matching what's in the
screenshots):

- `resources/retrieve_fees_data/fees_field_value_lists.py` -> same path
- `routes/fees_field_value_lists.py` -> same path
- `swagger/fees_field_value_lists/GET.yml` -> same path
- `test/resources/retrieve_fees_data/test_fees_field_value_lists.py` -> same path

Nothing to change in `constants/field_value_types_config.py` - it already
has `FIELD_TO_FIELD_VALUE_TYPE` with the right mapping, this endpoint just
consumes it.

Still needs manual wiring: registering `FEES_FIELD_VALUE_LISTS_BLUEPRINT`
wherever `REFETCH_FEES_DATA_BLUEPRINT` (or the other existing blueprints)
get registered - didn't have visibility into that file, so no snippet for
it here. Same spot, same pattern as the other blueprints.

One thing assumed rather than confirmed: `get_field_values()`'s signature
in `services/field_value_cache.py`, and that `FieldValue` has `code`,
`label_en`, `is_active`. The `label_en`/`is_active` part is already
confirmed from the DB screenshots, `code` too - the only unconfirmed bit
is the cache function's exact name/signature.
