# fees_field_value_lists — files to drop into cosmos_api

Where each file goes:

- `constants/field_value_types_config.py` -> `constants/field_value_types_config.py`
- `resources/fees_field_value_lists.py` -> `resources/fees_field_value_lists.py`
- `test/resources/test_fees_field_value_lists.py` -> `test/resources/test_fees_field_value_lists.py`

Not auto-applied, need manual wiring:

- `app_py_route_snippet.py` -> import + `api.add_resource(...)` lines to add
  into `app.py`
- `swagger_snippet.yaml` -> block to add into the swagger spec

Two things to double check against the actual codebase before running the
tests, since they were assumed rather than confirmed:

- signature of `get_field_values()` in `services/field_value_cache.py`
- attribute names on the `FieldValue` model (`code`, `type`, `label_en`,
  `is_active`)
