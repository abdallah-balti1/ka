"""
Mapping colonne éditable -> métadonnées Cosmos (PIVOT_FIELD_NAME,
IDENTIFICATION_FIELDS) + FIELD_VALUE_TYPE_BY_SUFFIX pour le chantier
listes déroulantes.

⚠️ CORRECTIF identification_fields (événements Cosmos réels) :
Seul le champ Rate (FeesPctg) porte AcqOrNotAcqFeesCd et/ou FeesLvlCd en
plus de FeesTypCd/FeesSubtypeCd. Les 4 autres champs texte (Basis of
Calculation, Calculation Frequency, Payment Frequency, Paid To) n'en
portent jamais, même sur une colonne "Max ..."/"Real ..." - confirmé sur
deux événements réels (CalcFrqCd, BasisCalcCd) : un seul basis/frequency
vaut pour les deux niveaux de taux.

Sur un champ Rate :
- Colonnes Subscription/Redemption ("... Acquired MAX Rate" /
  "... Non Acquired MAX Rate") : toujours FeesLvlCd="MAX" (pas de variante
  Real pour ces deux sections) + AcqOrNotAcqFeesCd (1=Acquired,
  2=Non Acquired - les deux codes sont confirmés).
- Colonnes "Max ..."/"Real ..." des autres sections (Management,
  Distribution, Charity, Advisory, Specific & External) : FeesLvlCd
  déduit du préfixe, pas d'AcqOrNotAcqFeesCd (non applicable).
- Conversion Rate : ni l'un ni l'autre (pas de split Max/Real ni
  Acquired/Non Acquired pour cette colonne).
"""

FEES_TYP_CD = "2"

SUBTYPE_MANAGEMENT = "1"
SUBTYPE_ADVISORY = "2"
SUBTYPE_DISTRIBUTION = "3"
SUBTYPE_CHARITY = "4"
SUBTYPE_SPECIFIC_EXTERNAL = "5"
SUBTYPE_SUBSCRIPTION = "7"
SUBTYPE_REDEMPTION = "8"
SUBTYPE_CONVERSION = "9"

SUBTYPE_BY_KEYWORD = [
    ("Management fees", SUBTYPE_MANAGEMENT),
    ("Advisory fees", SUBTYPE_ADVISORY),
    ("Distribution fees", SUBTYPE_DISTRIBUTION),
    ("Charity fees", SUBTYPE_CHARITY),
    ("Other Costs", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Foreign UCIs Tax", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Taxe Abonnement", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Subscription", SUBTYPE_SUBSCRIPTION),
    ("Redemption", SUBTYPE_REDEMPTION),
    ("Conversion", SUBTYPE_CONVERSION),
]

PIVOT_FIELD_NAME_BY_SUFFIX = [
    ("Rate", "FeesPctg"),
    ("Basis of Calculation", "BasisCalcCd"),
    ("Calculation Frequency", "CalcFrqCd"),
    ("Payment Frequency", "PmtFrqCd"),
    ("Paid To", "FeesPaidCd"),
]

# field_value type behind each free-text column (dropdown lists and
# label -> code translation both read this). Must stay in sync with
# FIELD_TO_FIELD_VALUE_TYPE in cosmos_api's field_value_types_config.py:
# the endpoint only returns the types listed there.
# Payment Frequency has its own type (CALCULATION_PERIOD), it does not
# share the Calculation Frequency list.
FIELD_VALUE_TYPE_BY_SUFFIX = [
    ("Basis of Calculation", "BASIS_OF_CALCULATION"),
    ("Calculation Frequency", "FEE_CALCULATION_FREQUENCY"),
    ("Payment Frequency", "CALCULATION_PERIOD"),
    ("Paid To", "FEES_PAID_TO"),
]

FEES_LVL_MAX = "MAX"
FEES_LVL_REEL = "REEL"

ACQUIRED_CODE = "1"
NON_ACQUIRED_CODE = "2"


def is_acquired_field(column_label: str) -> bool:
    """True for the Subscription/Redemption Acquired or Non Acquired Rate
    columns specifically - the only place AcqOrNotAcqFeesCd applies, and
    also the fields exempted from the fee_id/fee_value_id skip check in
    fee_cre_builder.py (see build_cre_data_for_all_fees)."""
    return "Acquired" in column_label


def get_identification_fields(column_label: str) -> dict:
    for keyword, subtype in SUBTYPE_BY_KEYWORD:
        if keyword in column_label:
            fields = {"FeesTypCd": FEES_TYP_CD, "FeesSubtypeCd": subtype}
            break
    else:
        raise ValueError(
            f"Impossible de déterminer le FeesSubtypeCd pour la colonne '{column_label}'"
        )

    if not column_label.endswith("Rate"):
        # Basis of Calculation / Calculation Frequency / Payment Frequency /
        # Paid To : jamais de AcqOrNotAcqFeesCd ni de FeesLvlCd, confirmé
        # par événements réels.
        return fields

    if is_acquired_field(column_label):
        # "Non Acquired" contains "Acquired" as a substring, so check it
        # first rather than relying on the generic match alone.
        fields["AcqOrNotAcqFeesCd"] = (
            NON_ACQUIRED_CODE if "Non Acquired" in column_label else ACQUIRED_CODE
        )
        fields["FeesLvlCd"] = FEES_LVL_MAX
        return fields

    if column_label.startswith("Max "):
        fields["FeesLvlCd"] = FEES_LVL_MAX
    elif column_label.startswith("Real "):
        fields["FeesLvlCd"] = FEES_LVL_REEL
    # Conversion Rate: no Max/Real split, no Acquired split - fields stays
    # at just FeesTypCd/FeesSubtypeCd.

    return fields


def get_pivot_field_name(column_label: str) -> str:
    for suffix, field_name in PIVOT_FIELD_NAME_BY_SUFFIX:
        if column_label.endswith(suffix):
            return field_name
    raise ValueError(
        f"Impossible de déterminer le PIVOT_FIELD_NAME pour la colonne '{column_label}'"
    )


def get_field_value_type(column_label: str):
    """Retourne le type field_value (BASIS_OF_CALCULATION, etc.) pour une
    colonne texte, ou None si la colonne est numérique (Rate) — auquel cas
    aucune traduction label -> code n'est nécessaire."""
    for suffix, type_name in FIELD_VALUE_TYPE_BY_SUFFIX:
        if column_label.endswith(suffix):
            return type_name
    return None
