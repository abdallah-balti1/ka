import unittest

from constants.fees_cre_mapping import (
    get_field_value_type,
    get_identification_fields,
    get_pivot_field_name,
    is_acquired_field,
)
from constants.fees_template import (
    EDITABLE_COLUMNS,
    KEYS,
    NUMERIC_EDITABLE_COLUMNS,
    TEXT_EDITABLE_COLUMNS,
)


class TestFeesCreMapping(unittest.TestCase):
    def test_every_editable_column_resolves_identification_fields(self):
        failures = []
        for idx in EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            try:
                result = get_identification_fields(column_label)
                self.assertIn("FeesTypCd", result)
                self.assertIn("FeesSubtypeCd", result)
            except ValueError as e:
                failures.append((column_label, str(e)))

        self.assertEqual(
            failures, [], f"{len(failures)} column(s) without identification_fields"
        )

    def test_every_editable_column_resolves_pivot_field_name(self):
        failures = []
        for idx in EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            try:
                get_pivot_field_name(column_label)
            except ValueError as e:
                failures.append((column_label, str(e)))

        self.assertEqual(
            failures, [], f"{len(failures)} column(s) without pivot_field_name"
        )

    def test_every_text_column_has_a_field_value_type(self):
        for idx in TEXT_EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            self.assertIsNotNone(
                get_field_value_type(column_label),
                f"{column_label} has no field_value type",
            )

    def test_numeric_columns_have_no_field_value_type(self):
        for idx in NUMERIC_EDITABLE_COLUMNS:
            column_label = KEYS[idx - 1]
            self.assertIsNone(get_field_value_type(column_label))

    # --- identification_fields: Rate columns ---

    def test_management_rate_carries_the_level(self):
        self.assertEqual(
            get_identification_fields("Max Management fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "1", "FeesLvlCd": "MAX"},
        )
        self.assertEqual(
            get_identification_fields("Real Management fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "1", "FeesLvlCd": "REEL"},
        )
        self.assertEqual(get_pivot_field_name("Max Management fees Rate"), "FeesPctg")

    def test_advisory_distribution_charity_rate_carry_the_level(self):
        self.assertEqual(
            get_identification_fields("Real Advisory fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "2", "FeesLvlCd": "REEL"},
        )
        self.assertEqual(
            get_identification_fields("Max Distribution fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "3", "FeesLvlCd": "MAX"},
        )
        self.assertEqual(
            get_identification_fields("Real Charity fees Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "4", "FeesLvlCd": "REEL"},
        )

    def test_specific_and_external_rate_share_subtype_5(self):
        for key, level in (
            ("Max Other Costs Rate", "MAX"),
            ("Real Foreign UCIs Tax Rate", "REEL"),
            ("Max Taxe Abonnement Rate", "MAX"),
        ):
            fields = get_identification_fields(key)
            self.assertEqual(fields["FeesSubtypeCd"], "5")
            self.assertEqual(fields["FeesLvlCd"], level)

    def test_subscription_acquired_matches_the_real_cosmos_event(self):
        self.assertEqual(
            get_identification_fields("Subscription Acquired MAX Rate"),
            {
                "FeesTypCd": "2",
                "FeesSubtypeCd": "7",
                "AcqOrNotAcqFeesCd": "1",
                "FeesLvlCd": "MAX",
            },
        )

    def test_non_acquired_uses_code_2(self):
        self.assertEqual(
            get_identification_fields("Subscription Non Acquired MAX Rate"),
            {
                "FeesTypCd": "2",
                "FeesSubtypeCd": "7",
                "AcqOrNotAcqFeesCd": "2",
                "FeesLvlCd": "MAX",
            },
        )

    def test_redemption_acquired_and_non_acquired(self):
        acquired = get_identification_fields("Redemption Acquired MAX Rate")
        non_acquired = get_identification_fields("Redemption Non Acquired MAX Rate")
        self.assertEqual(acquired["FeesSubtypeCd"], "8")
        self.assertEqual(acquired["AcqOrNotAcqFeesCd"], "1")
        self.assertEqual(non_acquired["FeesSubtypeCd"], "8")
        self.assertEqual(non_acquired["AcqOrNotAcqFeesCd"], "2")

    def test_conversion_rate_has_no_level_and_no_acquired_split(self):
        self.assertEqual(
            get_identification_fields("Conversion Rate"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "9"},
        )

    # --- identification_fields: text columns never carry level/acquired ---

    def test_text_columns_only_carry_type_and_subtype(self):
        self.assertEqual(
            get_identification_fields("Max Management fees Basis of Calculation"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "1"},
        )
        self.assertEqual(
            get_identification_fields("Real Management fees Calculation Frequency"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "1"},
        )
        self.assertEqual(
            get_identification_fields("Max Distribution fees Payment Frequency"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "3"},
        )
        self.assertEqual(
            get_identification_fields("Real Taxe Abonnement Paid To"),
            {"FeesTypCd": "2", "FeesSubtypeCd": "5"},
        )

    # --- pivot field names ---

    def test_pivot_field_name_suffixes(self):
        self.assertEqual(
            get_pivot_field_name("Real Charity fees Basis of Calculation"), "BasisCalcCd"
        )
        self.assertEqual(
            get_pivot_field_name("Max Management fees Calculation Frequency"), "CalcFrqCd"
        )
        self.assertEqual(
            get_pivot_field_name("Max Management fees Payment Frequency"), "PmtFrqCd"
        )
        self.assertEqual(get_pivot_field_name("Real Taxe Abonnement Paid To"), "FeesPaidCd")

    # --- field_value types ---

    def test_field_value_type_per_text_column(self):
        self.assertEqual(
            get_field_value_type("Max Management fees Basis of Calculation"),
            "BASIS_OF_CALCULATION",
        )
        self.assertEqual(
            get_field_value_type("Max Management fees Calculation Frequency"),
            "FEE_CALCULATION_FREQUENCY",
        )
        self.assertEqual(
            get_field_value_type("Max Management fees Payment Frequency"),
            "CALCULATION_PERIOD",
        )
        self.assertEqual(
            get_field_value_type("Real Taxe Abonnement Paid To"), "FEES_PAID_TO"
        )

    def test_payment_frequency_does_not_share_the_calculation_frequency_type(self):
        self.assertNotEqual(
            get_field_value_type("Real Charity fees Payment Frequency"),
            get_field_value_type("Real Charity fees Calculation Frequency"),
        )

    # --- helpers / errors ---

    def test_is_acquired_field(self):
        self.assertTrue(is_acquired_field("Subscription Acquired MAX Rate"))
        self.assertTrue(is_acquired_field("Redemption Non Acquired MAX Rate"))
        self.assertFalse(is_acquired_field("Max Management fees Rate"))
        self.assertFalse(is_acquired_field("Conversion Rate"))

    def test_unknown_column_raises_value_error(self):
        with self.assertRaises(ValueError):
            get_identification_fields("Some Totally Unknown Column")
        with self.assertRaises(ValueError):
            get_pivot_field_name("Some Totally Unknown Column")


if __name__ == "__main__":
    unittest.main()
