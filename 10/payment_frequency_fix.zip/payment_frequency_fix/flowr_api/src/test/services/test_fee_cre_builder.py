import unittest
from unittest.mock import patch

from entities import CreData
from services.fee_cre_builder import build_cre_data_for_all_fees

FIELD_VALUE_LISTS = {
    "BASIS_OF_CALCULATION": {"1": "Net assets", "2": "Net income"},
    "FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly"},
    "CALCULATION_PERIOD": {"Q": "Quarterly", "A": "Annual"},
    "FEES_PAID_TO": {"1": "Custodian"},
}


class _FakeTask:
    id = "TASK123"


class TestFeeCreBuilder(unittest.TestCase):
    def setUp(self):
        self.user = {"fullname": "Abdou Test"}
        self.task = _FakeTask()

        # Never hit the real cosmos_api from a unit test.
        patcher = patch(
            "services.fee_cre_builder.get_fees_field_value_lists",
            return_value=FIELD_VALUE_LISTS,
        )
        patcher.start()
        self.addCleanup(patcher.stop)

    @staticmethod
    def _diff(field, old, new, fee_id="FEE1", fee_value_id="VAL1",
              sha_cd="sha_1", prod_cd="prod_A"):
        return {
            "sha_cd": sha_cd, "prod_cd": prod_cd, "field": field,
            "old_value": old, "new_value": new,
            "fee_id": fee_id, "fee_value_id": fee_value_id,
        }

    def _build_one(self, diff):
        cre_data_by_product, _, skipped = build_cre_data_for_all_fees(
            self.user, self.task, [diff]
        )
        return cre_data_by_product, skipped

    def test_builds_cre_data_grouped_by_product(self):
        diffs = [
            self._diff("Max Management fees Rate", "0.4", "0.5"),
            self._diff("Max Management fees Basis of Calculation",
                       "Net assets", "Net income", "FEE2", "VAL2"),
            self._diff("Real Charity fees Rate", "0.1", "0.2",
                       "FEE3", "VAL3", "sha_2", "prod_B"),
        ]

        cre_data_by_product, _, skipped = build_cre_data_for_all_fees(
            self.user, self.task, diffs
        )

        self.assertEqual(set(cre_data_by_product.keys()), {"prod_A", "prod_B"})
        self.assertEqual(len(cre_data_by_product["prod_A"]), 2)
        self.assertEqual(len(cre_data_by_product["prod_B"]), 1)
        self.assertEqual(skipped, [])

    def test_parent_is_the_share_identified_by_its_code(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Rate", "0.4", "0.5")
        )
        cd = by_product["prod_A"][0]

        self.assertIsInstance(cd, CreData)
        self.assertEqual(cd.parent_entity_type, "Share")
        self.assertIsNone(cd.parent_entity_id)
        self.assertEqual(cd.parent_entity_code, "sha_1")

    def test_cre_data_has_correct_fields_for_a_rate(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Rate", "0.4", "0.5")
        )
        cd = by_product["prod_A"][0]

        self.assertEqual(cd.entity_type, "ProductFee")
        self.assertEqual(cd.entity_id, "VAL1")
        self.assertEqual(cd.old_value, "0.4")
        self.assertEqual(cd.new_value, "0.5")
        self.assertEqual(cd.pivot_field_name, "FeesPctg")
        self.assertEqual(cd.pivot_name, "ProductFee")
        self.assertEqual(
            cd.identification_fields,
            {"FeesTypCd": "2", "FeesSubtypeCd": "1", "FeesLvlCd": "MAX"},
        )
        self.assertEqual(cd.author, "Abdou Test")
        self.assertEqual(cd.task_id, "TASK123")

    def test_text_field_identification_fields_have_no_level(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Basis of Calculation",
                       "Net assets", "Net income")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(
            cd.identification_fields, {"FeesTypCd": "2", "FeesSubtypeCd": "1"}
        )

    # --- label -> code translation ---

    def test_basis_of_calculation_labels_are_translated_to_codes(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Basis of Calculation",
                       "Net assets", "Net income")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(cd.old_value, "1")
        self.assertEqual(cd.new_value, "2")
        self.assertEqual(cd.pivot_field_name, "BasisCalcCd")

    def test_calculation_frequency_uses_its_own_list(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Calculation Frequency",
                       "Daily", "Monthly")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(cd.old_value, "D")
        self.assertEqual(cd.new_value, "M")
        self.assertEqual(cd.pivot_field_name, "CalcFrqCd")

    def test_payment_frequency_is_translated_with_calculation_period(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Payment Frequency",
                       "Quarterly", "Annual")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(cd.old_value, "Q")
        self.assertEqual(cd.new_value, "A")
        self.assertEqual(cd.pivot_field_name, "PmtFrqCd")

    def test_payment_frequency_label_from_calculation_frequency_is_not_translated(self):
        # "Monthly" only exists in FEE_CALCULATION_FREQUENCY, so it must
        # not be resolved through the payment frequency list.
        by_product, _ = self._build_one(
            self._diff("Max Management fees Payment Frequency",
                       "Quarterly", "Monthly")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(cd.new_value, "Monthly")

    def test_unknown_label_is_kept_as_is(self):
        by_product, _ = self._build_one(
            self._diff("Real Charity fees Basis of Calculation",
                       "Net assets", "Something new")
        )
        cd = by_product["prod_A"][0]
        self.assertEqual(cd.old_value, "1")
        self.assertEqual(cd.new_value, "Something new")

    def test_old_value_none_becomes_none_not_string_none(self):
        by_product, _ = self._build_one(
            self._diff("Max Management fees Rate", None, "0.5")
        )
        cd = by_product["prod_A"][0]
        self.assertIsNone(cd.old_value)
        self.assertEqual(cd.new_value, "0.5")

    # --- skip logic ---

    def test_missing_ids_are_skipped_for_regular_columns(self):
        by_product, skipped = self._build_one(
            self._diff("Max Management fees Rate", None, "0.5", None, None)
        )
        self.assertEqual(by_product, {})
        self.assertEqual(len(skipped), 1)
        self.assertEqual(skipped[0]["field"], "Max Management fees Rate")

    def test_missing_fee_value_id_only_is_also_skipped(self):
        by_product, skipped = self._build_one(
            self._diff("Max Management fees Rate", "0.4", "0.5", "FEE1", None)
        )
        self.assertEqual(by_product, {})
        self.assertEqual(len(skipped), 1)

    def test_acquired_and_non_acquired_columns_are_never_skipped(self):
        for field, acq_code in (
            ("Subscription Acquired MAX Rate", "1"),
            ("Subscription Non Acquired MAX Rate", "2"),
            ("Redemption Acquired MAX Rate", "1"),
            ("Redemption Non Acquired MAX Rate", "2"),
        ):
            with self.subTest(field=field):
                by_product, skipped = self._build_one(
                    self._diff(field, None, "98777", None, None)
                )
                self.assertEqual(skipped, [])
                cd = by_product["prod_A"][0]
                self.assertEqual(cd.new_value, "98777")
                self.assertEqual(cd.parent_entity_type, "Share")
                self.assertEqual(cd.parent_entity_code, "sha_1")
                self.assertIsNone(cd.entity_id)
                self.assertEqual(
                    cd.identification_fields["AcqOrNotAcqFeesCd"], acq_code
                )
                self.assertEqual(cd.identification_fields["FeesLvlCd"], "MAX")

    def test_conversion_rate_is_still_skipped_without_ids(self):
        by_product, skipped = self._build_one(
            self._diff("Conversion Rate", None, "1.5", None, None)
        )
        self.assertEqual(by_product, {})
        self.assertEqual(len(skipped), 1)

    def test_empty_diffs_returns_empty_results(self):
        cre_data_by_product, mapping, skipped = build_cre_data_for_all_fees(
            self.user, self.task, []
        )
        self.assertEqual(cre_data_by_product, {})
        self.assertEqual(skipped, [])

    def test_lists_endpoint_failure_does_not_break_the_build(self):
        with patch(
            "services.fee_cre_builder.get_fees_field_value_lists",
            side_effect=Exception("cosmos_api down"),
        ):
            by_product, skipped = self._build_one(
                self._diff("Max Management fees Basis of Calculation",
                           "Net assets", "Net income")
            )
        cd = by_product["prod_A"][0]
        # No lists available: labels go through untouched.
        self.assertEqual(cd.old_value, "Net assets")
        self.assertEqual(cd.new_value, "Net income")


if __name__ == "__main__":
    unittest.main()
