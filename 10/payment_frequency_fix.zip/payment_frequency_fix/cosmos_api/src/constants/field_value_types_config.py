"""
Mapping between raw fields from product_fee and the "types" from the table
own_26967_plmsmartgps.field_value.

Confirmed types in database:
    - BASIS_OF_CALCULATION
    - FEE_CALCULATION_FREQUENCY (codes like "D", "M", "3M", "6M", "Y"...)
    - CALCULATION_PERIOD (source of the payment frequency values)
    - FEES_PAID_TO
    - PAYMENT_FREQUENCY (numeric codes "1".."5" - different reference table,
      not used by pmt_frq_cd)

Confirmed fields in ProductFee model:
    - calc_frq_cd   -> uses FEE_CALCULATION_FREQUENCY_TYPE
    - pmt_frq_cd    -> uses CALCULATION_PERIOD_TYPE (NOT PAYMENT_FREQUENCY_TYPE,
                       and NOT FEE_CALCULATION_FREQUENCY_TYPE either)
    - basis_calc_cd
    - fees_paid_cd
"""


# Field names from ProductFee model
FIELD_CALC_FRQ = "calc_frq_cd"
FIELD_PMT_FRQ = "pmt_frq_cd"
FIELD_BASIS_CALC = "basis_calc_cd"
FIELD_PAID_TO = "fees_paid_cd"

# Corresponding field_value types
FEE_CALCULATION_FREQUENCY_TYPE = "FEE_CALCULATION_FREQUENCY"
CALCULATION_PERIOD_TYPE = "CALCULATION_PERIOD"
BASIS_OF_CALCULATION_TYPE = "BASIS_OF_CALCULATION"
FEES_PAID_TO_TYPE = "FEES_PAID_TO"

# NOTE: PAYMENT_FREQUENCY exists in database but is NOT used here -
# its numeric codes (1-5) don't match the actual pmt_frq_cd values.
# Kept as comment for reference in case another field needs it later:
# PAYMENT_FREQUENCY_TYPE = "PAYMENT_FREQUENCY"

# Mapping {raw ProductFee field name: corresponding field_value type}
# Fields not in this dict are not translated (kept as-is).
FIELD_TO_FIELD_VALUE_TYPE = {
    FIELD_CALC_FRQ: FEE_CALCULATION_FREQUENCY_TYPE,
    FIELD_PMT_FRQ: CALCULATION_PERIOD_TYPE,
    FIELD_BASIS_CALC: BASIS_OF_CALCULATION_TYPE,
    FIELD_PAID_TO: FEES_PAID_TO_TYPE,
}
