import unittest
from unittest.mock import patch

from models.field_value import FieldValue
from server import server
from tests.utils import init_database


class TestFeesFieldValueListsResource(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        init_database()

        FieldValue(code="1", type="BASIS_OF_CALCULATION",
                   label_fr="Actif net", label_en="Net assets",
                   is_active=True).save()
        FieldValue(code="999", type="BASIS_OF_CALCULATION",
                   label_fr="Ancien code", label_en="Old code",
                   is_active=False).save()

        FieldValue(code="M", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Mensuelle", label_en="Monthly",
                   is_active=True).save()

        # Deliberately different from the calculation frequency row above,
        # to prove the two fields don't share a list anymore.
        FieldValue(code="Q", type="CALCULATION_PERIOD",
                   label_fr="Trimestrielle", label_en="Quarterly",
                   is_active=True).save()

        FieldValue(code="1", type="FEES_PAID_TO",
                   label_fr="Conservateur", label_en="Custodian",
                   is_active=True).save()

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_returns_values_grouped_by_type(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        self.assertEqual(response.status_code, 200)
        data = response.get_json()

        self.assertEqual(data["BASIS_OF_CALCULATION"], {"1": "Net assets"})
        self.assertEqual(data["FEE_CALCULATION_FREQUENCY"], {"M": "Monthly"})
        self.assertEqual(data["CALCULATION_PERIOD"], {"Q": "Quarterly"})
        self.assertEqual(data["FEES_PAID_TO"], {"1": "Custodian"})

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_exposes_exactly_the_four_expected_types(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertEqual(
            set(data.keys()),
            {
                "BASIS_OF_CALCULATION",
                "CALCULATION_PERIOD",
                "FEE_CALCULATION_FREQUENCY",
                "FEES_PAID_TO",
            },
        )

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_payment_frequency_type_is_not_the_calculation_frequency_one(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertNotEqual(
            data["CALCULATION_PERIOD"], data["FEE_CALCULATION_FREQUENCY"]
        )

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_inactive_values_are_excluded(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertNotIn("999", data["BASIS_OF_CALCULATION"])


if __name__ == "__main__":
    unittest.main()
