# Payment Frequency fix - CALCULATION_PERIOD

## What changed

Payment Frequency (`pmt_frq_cd`) now reads its values from the
`CALCULATION_PERIOD` field_value type. It used to be mapped to
`FEE_CALCULATION_FREQUENCY`, the same list as Calculation Frequency.

    SELECT * FROM field_value WHERE type = 'CALCULATION_PERIOD';

Calculation Frequency (`calc_frq_cd`) is unchanged and keeps
`FEE_CALCULATION_FREQUENCY`. The endpoint now returns four types instead
of three:

    BASIS_OF_CALCULATION, CALCULATION_PERIOD,
    FEE_CALCULATION_FREQUENCY, FEES_PAID_TO

One mapping drives everything on the cosmos_api side
(`FIELD_TO_FIELD_VALUE_TYPE`), so the endpoint follows automatically.
On the flowr_api side the same decision lives in
`FIELD_VALUE_TYPE_BY_SUFFIX`, which feeds both the Excel dropdown and the
label -> code translation.

## Files (paths relative to each project's `src/`)

cosmos_api
- constants/field_value_types_config.py          (replaces the existing file)
- resources/retrieve_fees_data/fees_field_value_lists.py
- swagger/fees_field_value_lists/GET.yml
- test/resources/retrieve_fees_data/test_fees_field_value_lists.py

flowr_api
- constants/fees_cre_mapping.py
- test/constants/test_fees_cre_mapping.py
- test/services/test_fee_cre_builder.py
- test/api/mass_update_template/test_fees_template.py

Nothing else needs to change: the Lists sheet builds one column per type
it receives, so CALCULATION_PERIOD gets its own column and dropdown
without touching util/mass_update/fees_template.py.

## Deployment order

Deploy cosmos_api first. If flowr_api goes out alone, the endpoint does
not return CALCULATION_PERIOD yet: the Payment Frequency dropdown falls
back to free text and labels are sent to Cosmos untranslated. Nothing
crashes, which also means nothing tells you it is broken.

## Tests

The four flowr_api / cosmos_api test files above are complete
replacements. Some of the previously delivered tests were out of date
with the earlier CreData fix and failed against it:

- identification_fields assertions (Rate columns now carry FeesLvlCd,
  Acquired/Non Acquired also carry AcqOrNotAcqFeesCd)
- parent_entity_type "Fees" / parent_entity_id "FEE1" (now "Share" /
  None, with parent_entity_code = sha_cd)
- template column guard 77 -> 65 (12 columns removed from Specific &
  External fees) and base column labels (Product name, ...)

Run in a sandbox with stubs for client.smartgps and entities.CreData:
40 tests, all passing (mapping, cre builder, template). The cosmos_api
tests need the real database and were only syntax-checked.

## Two things to verify on your side

1. Existing data vs the new type. An earlier comment in
   field_value_types_config.py stated that real pmt_frq_cd values such as
   "M" / "3M" only exist in FEE_CALCULATION_FREQUENCY. If that is still
   true, they will not resolve through CALCULATION_PERIOD. Check with
   (adjust schema and table name if needed):

       SELECT DISTINCT pf.pmt_frq_cd
       FROM own_26967_plmsmartgps.product_fee pf
       LEFT JOIN own_26967_plmsmartgps.field_value fv
              ON fv.type = 'CALCULATION_PERIOD' AND fv.code = pf.pmt_frq_cd
       WHERE pf.pmt_frq_cd IS NOT NULL AND fv.id IS NULL;

   An empty result means every stored code is covered.

2. CreData.parent_entity_code. The builder test asserts this attribute.
   It was tested against a stub, not the real entities.CreData: if the
   real attribute has another name, that test is the first place it
   will show.
