# Payment Frequency merged into a single column per fee type

## What changed

For Management, Distribution, Charity and Advisory fees, Payment
Frequency is now one column shared between the "Maximum" and "Real"
levels of that fee type, instead of one column per level.

It's modeled as its own pseudo-subsection (subtitle "Payment Frequency",
same text as the column label), placed after the Maximum/Real
subsections in each section:

    Management fees
      -> Maximum Management fees (Rate, Basis of Calculation, Calculation Frequency)
      -> Real Management fees    (Rate, Basis of Calculation, Calculation Frequency)
      -> Payment Frequency       (Payment Frequency)   <- single column

Same for Distribution, Charity, Advisory. Rate stays level-specific -
only Payment Frequency is merged. Specific & External fees and
Subscription/Redemption/Conversion are untouched (they no longer had
Payment Frequency, or never had it).

Key naming: the merged key drops the "Max "/"Real " prefix -
"Management fees Payment Frequency" instead of "Max Management fees
Payment Frequency" / "Real Management fees Payment Frequency".

## Files (paths relative to flowr_api's `src/`)

- constants/fees_template.py           (full replacement)
- test/constants/test_fees_cre_mapping.py
- test/services/test_fee_cre_builder.py
- test/api/mass_update_template/test_fees_template.py

fees_cre_mapping.py itself needs NO change - get_pivot_field_name,
get_identification_fields and get_field_value_type all match by suffix
("Payment Frequency"), so they resolve the new merged key exactly the
same way. Verified directly (see Tests below), not just by inspection.

## Tests

44 tests, all passing, run in a sandbox with stubs for client.smartgps
and entities.CreData. New tests added specifically for this change:

- the merged key exists exactly once per fee type, the old "Max "/"Real "
  prefixed keys don't exist anymore
- the subsection-title-row and column-label-row text both read "Payment
  Frequency" for the merged column
- a value written to the merged key lands in its own column
- all four merged columns resolve through fees_cre_mapping.py with no
  FeesLvlCd (confirming the existing text-column rule extends correctly
  to the merged case)

## Open question - not resolved by this change

This only changes the Excel layout. It does not touch cosmos_api or
fee_diff_service.py / fee_cre_builder.py, and there's a real question
underneath: does Cosmos still store pmt_frq_cd once per level (one
product_fee row for MAX, one for REEL), or is it already a single value
shared by both?

If it's still per-row, merging the Excel cell creates an ambiguity when
writing back: editing that one cell either
  (a) updates only one of the two rows (via whichever fee_id/
      fee_value_id the cosmos_api export attaches to this merged column),
      leaving the other row's pmt_frq_cd out of sync, or
  (b) needs to fan out into two CreData events from that single diff -
      not something fee_diff_service.py / fee_cre_builder.py do today.

I don't have visibility into the cosmos_api service that builds
fee_columns/fee_ids (FeeExportService, referenced but never shown) to
resolve this. If you want the full pipeline wired end to end, that file
is the next thing needed.
