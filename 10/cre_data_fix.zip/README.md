# Correctif CreData mal formés - solution complète

## Fichiers modifiés (copier-coller intégral)

### src/constants/fees_template.py
Calculation Frequency / Payment Frequency retirés des 6 sous-sections
"Specific & External fees" (Max/Real Other Costs, Max/Real Foreign UCIs
Tax, Max/Real Taxe Abonnement). Tout le reste recalcule automatiquement
(TOTAL_COLUMNS, EDITABLE_COLUMNS, etc.), rien d'autre à toucher.

### src/constants/fees_cre_mapping.py
- get_identification_fields() : AcqOrNotAcqFeesCd (1=Acquired,
  2=Non Acquired) et FeesLvlCd désormais ajoutés uniquement pour le champ
  Rate, jamais pour Basis of Calculation / Calculation Frequency /
  Payment Frequency / Paid To.
- Nouvelle fonction exportée is_acquired_field(column_label), réutilisée
  à la fois ici et dans fee_cre_builder.py.

### src/services/fee_cre_builder.py
- PARENT_ENTITY_TYPE passe de "Fees" à "Share".
- parent_entity_id passe à None (toujours).
- parent_entity_code=diff["sha_cd"] ajouté (nom confirmé - déjà utilisé
  ailleurs dans le générateur CreData existant, cf. get_extra_events).
- Le skip fee_id/fee_value_id ne s'applique plus aux colonnes
  Acquired/Non Acquired Rate (Subscription et Redemption) : ces diffs
  partent toujours, même sans fee_id ni fee_value_id. Toutes les autres
  colonnes gardent le comportement précédent.

## Résumé des 3 corrections demandées

1. parentEntityType="Share" / parentEntityId=null / parentEntityCode=sha_cd
   pour TOUS les champs (Rate, Basis of Calculation, Calculation
   Frequency, Payment Frequency, Paid To).
2. identification_fields différenciés : AcqOrNotAcqFeesCd/FeesLvlCd
   seulement sur Rate, jamais sur les 4 autres champs texte.
3. Calculation Frequency et Payment Frequency retirés de Specific &
   External fees.
4. Skip fee_id/fee_value_id désactivé pour les colonnes Acquired/Non
   Acquired Rate (Subscription/Redemption).

## Point encore ouvert

Quand une colonne Acquired/Non Acquired part sans fee_value_id (skip
désactivé), entity_id est envoyé à None dans le CreData - pas testé sur
un événement réel à ce jour. Si Cosmos rejette un entityId null pour ce
cas, il faudra revoir comment cette entité est identifiée côté Cosmos
(probablement via identification_fields seul, sans UUID explicite).
