"""
Construction des CreData Cosmos à partir des diffs détectées.

⚠️ CORRECTIF (événements CreData mal formés) :
Le parent d'un ProductFee n'est pas une entité "Fees", c'est la Share
elle-même, identifiée par son CODE (sha_cd) et pas par un id interne :
  parent_entity_type = "Share"
  parent_entity_id = None (toujours, confirmé sur événements réels)
  parent_entity_code = sha_cd

parent_entity_code : nom confirmé - "parentEntityCode" est déjà un champ
reconnu ailleurs dans le générateur CreData existant (cre.py /
get_extra_events), donc pas une invention de ce correctif.

identification_fields varie selon le champ modifié - voir
constants/fees_cre_mapping.get_identification_fields pour le détail.

⚠️ Exception au skip fee_id/fee_value_id : les colonnes Acquired/Non
Acquired Rate (Subscription et Redemption) sont TOUJOURS envoyées, même
sans fee_id/fee_value_id - ces deux champs ne sont pas exigés pour ces
colonnes spécifiquement (décision produit). Toutes les autres colonnes
gardent le comportement précédent : sans fee_id ET fee_value_id, la diff
part dans skipped_new_fees plutôt que d'être envoyée avec des valeurs
devinées.

Traduction label -> code pour les 4 champs texte (Basis of Calculation,
Calculation Frequency, Payment Frequency, Paid To), inchangée : si un
label n'est pas retrouvé dans le référentiel, la valeur est gardée telle
quelle plutôt que de faire planter tout le mass update.
"""

from collections import defaultdict

from client.smartgps import get_fees_field_value_lists
from constants.fees_cre_mapping import (
    get_field_value_type,
    get_identification_fields,
    get_pivot_field_name,
    is_acquired_field,
)
from entities import CreData

PARENT_ENTITY_TYPE = "Share"
ENTITY_TYPE = "ProductFee"
PIVOT_NAME = "ProductFee"
MODIFY_ACTION = "MODIFY"


def _build_reverse_maps(field_value_lists):
    """{type: {code: label}} -> {type: {label: code}}"""
    return {
        type_name: {label: code for code, label in codes_to_labels.items()}
        for type_name, codes_to_labels in (field_value_lists or {}).items()
    }


def _translate_value(value, field_value_type, reverse_maps, untranslated_values):
    """Traduit un label en code pour un champ texte donné. Retourne la
    valeur telle quelle si pas de traduction applicable (champ numérique)
    ou si le label est introuvable dans le référentiel."""
    if value is None or not field_value_type:
        return value

    reverse_map = reverse_maps.get(field_value_type, {})
    if value in reverse_map:
        return reverse_map[value]

    untranslated_values.append({"field_value_type": field_value_type, "label": value})
    return value


def build_cre_data_for_all_fees(user, task, diffs):
    cre_data_list_by_product_id = defaultdict(list)
    mapping_entity_line_dict = {}
    skipped_new_fees = []
    untranslated_values = []

    try:
        field_value_lists = get_fees_field_value_lists()
    except Exception:
        field_value_lists = {}
    reverse_maps = _build_reverse_maps(field_value_lists)

    for diff in diffs:
        # Subscription/Redemption Acquired & Non Acquired Rate: always
        # sent, fee_id/fee_value_id not required for these two columns.
        exempt_from_skip = is_acquired_field(diff["field"])
        if not exempt_from_skip and (
            diff.get("fee_id") is None or diff.get("fee_value_id") is None
        ):
            skipped_new_fees.append(diff)
            continue

        field_value_type = get_field_value_type(diff["field"])
        old_value = _translate_value(
            diff["old_value"], field_value_type, reverse_maps, untranslated_values
        )
        new_value = _translate_value(
            diff["new_value"], field_value_type, reverse_maps, untranslated_values
        )

        cre_data = CreData(
            parent_entity_type=PARENT_ENTITY_TYPE,
            parent_entity_id=None,
            parent_entity_code=diff["sha_cd"],
            entity_type=ENTITY_TYPE,
            entity_id=diff["fee_value_id"],
            old_value=str(old_value) if old_value is not None else None,
            new_value=str(new_value) if new_value is not None else None,
            entity_action=MODIFY_ACTION,
            task_id=task.id,
            is_parent_entity_from_plm=True,
            is_entity_from_plm=MODIFY_ACTION,
            pivot_field_name=get_pivot_field_name(diff["field"]),
            pivot_name=PIVOT_NAME,
            identification_fields=get_identification_fields(diff["field"]),
            author=user["fullname"],
        )
        cre_data_list_by_product_id[diff["prod_cd"]].append(cre_data)

    return cre_data_list_by_product_id, mapping_entity_line_dict, skipped_new_fees
