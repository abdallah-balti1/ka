"""
Service de diff : compare les valeurs du fichier réuploadé à l'état
FRAIS récupéré via cosmos_api (/refetch_fees_data), et retourne la
liste des champs réellement modifiés.
"""

from typing import Dict, List

from constants.fees_template import EDITABLE_COLUMNS, KEYS, NUMERIC_EDITABLE_COLUMNS

_NUMERIC_KEYS = {KEYS[idx - 1] for idx in NUMERIC_EDITABLE_COLUMNS}
_EDITABLE_KEYS = {KEYS[idx - 1] for idx in EDITABLE_COLUMNS}


def _normalize_empty(value):
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _normalize_numeric(value):
    value = _normalize_empty(value)
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return round(float(value), 6)
    try:
        cleaned = str(value).strip().replace(",", ".")
        return round(float(cleaned), 6)
    except (ValueError, TypeError):
        return str(value).strip()


def _normalize_text(value):
    value = _normalize_empty(value)
    if value is None:
        return None
    return str(value).strip()


def _values_differ(key: str, file_value, fresh_value) -> bool:
    if key in _NUMERIC_KEYS:
        return _normalize_numeric(file_value) != _normalize_numeric(fresh_value)
    return _normalize_text(file_value) != _normalize_text(fresh_value)


class FeeDiffService:

    @staticmethod
    def build_diff(
        file_rows: List[Dict], fresh_data_by_sha_cd: Dict[str, Dict]
    ) -> List[Dict]:
        """
        Retourne une liste de diffs :
            [{"sha_cd": ..., "field": ..., "old_value": ..., "new_value": ...}, ...]
        """
        diffs: List[Dict] = []

        for row in file_rows:
            sha_cd = row["sha_cd"]
            fresh_row = fresh_data_by_sha_cd.get(sha_cd, {})

            for key in _EDITABLE_KEYS:
                file_value = row.get(key)
                fresh_value = fresh_row.get(key)

                if _values_differ(key, file_value, fresh_value):
                    diffs.append(
                        {
                            "sha_cd": sha_cd,
                            "field": key,
                            "old_value": fresh_value,
                            "new_value": file_value,
                        }
                    )

        return diffs
