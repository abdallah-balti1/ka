"""
Parsing du fichier Excel "Fees" réuploadé par l'utilisateur.

Deux points d'entrée :
  - parse_fees_template_workbook(wb) : à utiliser dans le job qui a
    déjà chargé le Workbook (évite de re-parser les bytes une 2e fois
    après is_all_fees_mass_update, qui a déjà besoin du wb chargé)
  - parse_fees_template_file(file_bytes) : pratique pour les tests /
    un usage isolé, charge le workbook puis délègue à la fonction
    ci-dessus

Ne lit QUE ce qui est nécessaire pour la diff : la colonne technique
"Cosmos ID" (cachée) et les colonnes éditables.
"""

from io import BytesIO
from typing import Dict, List

from openpyxl import load_workbook
from openpyxl.workbook import Workbook

from constants.fees_template import (
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    EDITABLE_COLUMNS,
    KEYS,
    SHEET_NAME,
)


def parse_fees_template_workbook(wb: Workbook) -> List[Dict]:
    """
    Retourne une liste de dicts, un par ligne de données du fichier :
      {"sha_cd": "41455", "Max Management fees Rate": "0.4", ...}

    Seules les clés des colonnes éditables (+ sha_cd) sont incluses.
    Une ligne dont la colonne "Cosmos ID" est vide est ignorée.
    """
    if SHEET_NAME not in wb.sheetnames:
        raise ValueError(
            f"Feuille '{SHEET_NAME}' introuvable dans le fichier uploadé "
            f"(feuilles présentes : {wb.sheetnames})"
        )
    ws = wb[SHEET_NAME]

    rows: List[Dict] = []
    row_idx = DATA_START_ROW
    while row_idx <= ws.max_row:
        sha_cd = ws.cell(row=row_idx, column=COSMOS_ID_COLUMN_INDEX).value
        if sha_cd is None or str(sha_cd).strip() == "":
            row_idx += 1
            continue

        row_data = {"sha_cd": str(sha_cd).strip()}
        for col_idx in EDITABLE_COLUMNS:
            key = KEYS[col_idx - 1]
            value = ws.cell(row=row_idx, column=col_idx).value
            row_data[key] = value

        rows.append(row_data)
        row_idx += 1

    return rows


def parse_fees_template_file(file_bytes: bytes) -> List[Dict]:
    """Charge le workbook depuis des bytes puis délègue à
    parse_fees_template_workbook. Pratique pour tests/usage isolé."""
    wb = load_workbook(filename=BytesIO(file_bytes), data_only=True)
    return parse_fees_template_workbook(wb)
