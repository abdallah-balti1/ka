"""
Détection du template "All Fees" dans un classeur uploadé, sur le même
principe que _is_mu_v3_worksheet / get_mu_version : on inspecte le
CONTENU réel du fichier (les headers présents), pas une métadonnée
externe (nom de tâche, etc.) qui pourrait être désynchronisée d'un
fichier modifié à la main entre le download et l'upload.

Fonction indépendante de get_mu_version — répond à une question
différente ("quel template métier est-ce ?" vs "quelle version du
moteur MU utiliser ?"). Ne modifie pas get_mu_version ni son
comportement existant.

⚠️ Notre template a 3 lignes d'en-tête (section / sous-section /
colonne), contrairement au pattern MU v3 a priori sur une seule ligne
— d'où la vérification combinée sur SECTION_TITLE_ROW ET
COLUMN_LABEL_ROW : les colonnes d'identification (fusionnées
verticalement) n'ont leur valeur que sur la ligne 1 (l'ancre de la
fusion), les colonnes de fees individuelles n'ont leur valeur que sur
la ligne 3.
"""

from typing import Iterable, Set

from openpyxl.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet

from constants.fees_template import COLUMN_LABEL_ROW, HEADERS, SECTION_TITLE_ROW


def _get_headers_from_rows(ws: Worksheet, row_indices: Iterable[int]) -> Set[str]:
    """Récupère l'ensemble des valeurs non vides sur les lignes données.
    Généralisation de _get_headers_from_row (existant, une seule ligne)
    pour couvrir plusieurs lignes d'en-tête."""
    headers: Set[str] = set()
    for row_index in row_indices:
        headers |= {
            str(cell.value).strip()
            for cell in ws[row_index]
            if cell.value is not None and str(cell.value).strip()
        }
    return headers


def _is_all_fees_worksheet(ws: Worksheet) -> bool:
    """Returns True if the worksheet matches the 'All Fees' mass update
    template structure (sur-ensemble attendu : tous les HEADERS définis
    dans constants/fees_template.py doivent apparaître quelque part
    dans les lignes 1 et 3 de la feuille)."""
    expected_headers = set(HEADERS)
    found_headers = _get_headers_from_rows(ws, (SECTION_TITLE_ROW, COLUMN_LABEL_ROW))
    return expected_headers.issubset(found_headers)


def is_all_fees_mass_update(wb: Workbook) -> bool:
    """Parcourt les worksheets du classeur, comme get_mu_version, et
    retourne True si l'une d'elles matche la structure 'All Fees'.

    À appeler AVANT get_mu_version dans le flux du job (aiguillage de
    plus haut niveau, pas une nouvelle "version" MU au même niveau que
    v1/v2/v3) :

        if is_all_fees_mass_update(wb):
            # nouveau chemin : parse_fees_template_file + FeeDiffService
            ...
        else:
            # chemin existant, inchangé (ADL, MU v1/v2/v3)
            mu_version = get_mu_version(wb)
            ...
    """
    for ws in wb.worksheets:
        if _is_all_fees_worksheet(ws):
            return True
    return False
