"""
Orchestration du traitement d'un mass update "All Fees" une fois
détecté par is_all_fees_mass_update(wb).

À appeler dans le job du soir (mass_update_process.py ou équivalent),
là où get_mass_update_reader / get_mu_version sont utilisés pour les
autres types de mass update :

    from util.mass_update.fees_detection import is_all_fees_mass_update
    from util.mass_update.process_all_fees_mass_update import (
        process_all_fees_mass_update,
    )

    if is_all_fees_mass_update(wb):
        diffs = process_all_fees_mass_update(wb)
        # TODO : émission des events — en attente du pattern exact
        # utilisé par send_mass_update_data.py pour l'ADL, à brancher
        # ici une fois confirmé (cf. commentaire en bas de ce fichier)
    else:
        mu_version = get_mu_version(wb)
        ...
"""

from typing import Dict, List

from client.smartgps import get_refetch_fees_data
from services.fee_diff_service import FeeDiffService
from util.mass_update.fees_upload import parse_fees_template_workbook


def process_all_fees_mass_update(wb) -> List[Dict]:
    """
    1. Parse le classeur uploadé (colonnes éditables + Cosmos ID)
    2. Rappelle cosmos_api pour l'état FRAIS de ces sha_cd
    3. Calcule la diff entre le fichier et l'état frais

    Retourne la liste des diffs :
        [{"sha_cd": ..., "field": ..., "old_value": ..., "new_value": ...}, ...]

    Ne fait PAS l'émission des events — c'est la responsabilité de
    l'appelant (le job), une fois le pattern d'event confirmé.
    """
    file_rows = parse_fees_template_workbook(wb)

    if not file_rows:
        return []

    sha_cd_list = [row["sha_cd"] for row in file_rows]
    fresh_data_by_sha_cd: Dict[str, Dict] = get_refetch_fees_data(sha_cd_list)

    diffs = FeeDiffService.build_diff(file_rows, fresh_data_by_sha_cd)

    return diffs
