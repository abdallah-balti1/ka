"""
Test de process_all_fees_mass_update : génère un fichier, simule une
modification, mocke get_refetch_fees_data (pas de vrai réseau), vérifie
que la diff finale est correcte.

Lancer avec :
    python tests/test_process_all_fees_mass_update.py
"""

import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from constants.fees_template import DATA_START_ROW, KEYS  # noqa: E402
from util.mass_update.fees_template import create_fees_template_workbook  # noqa: E402


def _build_fake_row(sha_cd: str) -> dict:
    row = {k: None for k in KEYS}
    row["sha_cd"] = sha_cd
    row["umb_name_lbl"] = "BNP PARIBAS EASY"
    row["Max Management fees Rate"] = "0.4"
    row["Max Management fees Basis of Calculation"] = "Net assets"
    return row


def test_orchestration_detects_change_via_mocked_refetch():
    from util.mass_update.process_all_fees_mass_update import (
        process_all_fees_mass_update,
    )

    row = _build_fake_row("41455")
    wb = create_fees_template_workbook([row])

    # Simule une modification utilisateur directement sur le wb en mémoire
    ws = wb["Fees Review"]
    target_col = None
    for c in range(1, ws.max_column + 1):
        if ws.cell(row=3, column=c).value == "Rate":
            target_col = c
            break
    assert target_col is not None
    ws.cell(row=DATA_START_ROW, column=target_col, value="0.5")

    # État "frais" simulé : identique aux données d'origine (donc le seul
    # écart détecté doit être le changement qu'on vient de faire)
    fresh_state = {
        "41455": {k: v for k, v in row.items() if k != "sha_cd"}
    }

    with patch(
        "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data",
        return_value=fresh_state,
    ) as mock_refetch:
        diffs = process_all_fees_mass_update(wb)

    mock_refetch.assert_called_once_with(["41455"])
    assert len(diffs) == 1, f"Attendu 1 diff, obtenu {len(diffs)} : {diffs}"
    assert diffs[0]["sha_cd"] == "41455"
    assert diffs[0]["field"] == "Max Management fees Rate"
    assert diffs[0]["old_value"] == "0.4"
    assert diffs[0]["new_value"] == "0.5"
    print("✅ test_orchestration_detects_change_via_mocked_refetch OK")


def test_orchestration_no_rows_skips_refetch_call():
    """Si le fichier n'a aucune ligne de données, on ne doit même pas
    appeler cosmos_api — évite un appel réseau inutile."""
    from util.mass_update.process_all_fees_mass_update import (
        process_all_fees_mass_update,
    )

    wb = create_fees_template_workbook([])  # aucune ligne

    with patch(
        "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data"
    ) as mock_refetch:
        diffs = process_all_fees_mass_update(wb)

    mock_refetch.assert_not_called()
    assert diffs == []
    print("✅ test_orchestration_no_rows_skips_refetch_call OK")


def test_orchestration_no_diff_when_nothing_changed():
    from util.mass_update.process_all_fees_mass_update import (
        process_all_fees_mass_update,
    )

    row = _build_fake_row("41455")
    wb = create_fees_template_workbook([row])
    fresh_state = {"41455": {k: v for k, v in row.items() if k != "sha_cd"}}

    with patch(
        "util.mass_update.process_all_fees_mass_update.get_refetch_fees_data",
        return_value=fresh_state,
    ):
        diffs = process_all_fees_mass_update(wb)

    assert diffs == []
    print("✅ test_orchestration_no_diff_when_nothing_changed OK")


if __name__ == "__main__":
    test_orchestration_detects_change_via_mocked_refetch()
    test_orchestration_no_rows_skips_refetch_call()
    test_orchestration_no_diff_when_nothing_changed()
    print("\n🎉 Tous les tests passent.")
