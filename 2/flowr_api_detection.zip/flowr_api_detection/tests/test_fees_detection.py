"""
Test de is_all_fees_mass_update / _is_all_fees_worksheet :
  - vrai positif : un classeur généré par create_fees_template_workbook
  - vrai négatif : un classeur simple type ADL (headers différents,
    une seule ligne d'en-tête) — ne doit PAS être détecté comme "All Fees"
  - faux fichier quelconque (feuille vide) — ne doit pas planter, doit
    renvoyer False

Sans DB, sans Flask, sans réseau.

Lancer avec :
    python tests/test_fees_detection.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import openpyxl  # noqa: E402

from util.mass_update.fees_detection import is_all_fees_mass_update  # noqa: E402
from util.mass_update.fees_template import create_fees_template_workbook  # noqa: E402
from constants.fees_template import KEYS  # noqa: E402


def _build_fake_row(sha_cd: str) -> dict:
    row = {k: None for k in KEYS}
    row["sha_cd"] = sha_cd
    row["umb_name_lbl"] = "BNP PARIBAS EASY"
    return row


def test_true_positive_all_fees_workbook_detected():
    wb = create_fees_template_workbook([_build_fake_row("41455")])
    assert is_all_fees_mass_update(wb) is True
    print("✅ test_true_positive_all_fees_workbook_detected OK")


def test_true_negative_adl_like_workbook_not_detected():
    """Simule un classeur ADL : une seule ligne d'en-tête, headers
    complètement différents de notre template — ne doit PAS matcher."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Fees Review"
    adl_headers = [
        "Prod Cd", "Share Cd", "Umbrella name", "Sub-fund name",
        "Max ADL In Fee", "ADL In Fee", "Max ADL Out Fee", "ADL Out Fee",
    ]
    for col_idx, h in enumerate(adl_headers, start=1):
        ws.cell(row=1, column=col_idx, value=h)

    assert is_all_fees_mass_update(wb) is False
    print("✅ test_true_negative_adl_like_workbook_not_detected OK")


def test_empty_workbook_returns_false_without_crashing():
    wb = openpyxl.Workbook()  # feuille vide par défaut
    assert is_all_fees_mass_update(wb) is False
    print("✅ test_empty_workbook_returns_false_without_crashing OK")


def test_partial_headers_not_falsely_detected():
    """Un fichier qui contient QUELQUES headers en commun (ex: 'Rate')
    mais pas tous ne doit pas être détecté comme All Fees — évite les
    faux positifs sur des fichiers qui ont juste une colonne 'Rate'
    par coïncidence."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Fees Review"
    ws.cell(row=1, column=1, value="Rate")
    ws.cell(row=1, column=2, value="Some other column")

    assert is_all_fees_mass_update(wb) is False
    print("✅ test_partial_headers_not_falsely_detected OK")


def test_multiple_worksheets_detects_if_any_matches():
    """Si le classeur a plusieurs feuilles, il suffit qu'UNE seule
    matche pour que la détection soit positive (comme get_mu_version
    qui boucle sur wb.worksheets)."""
    wb = create_fees_template_workbook([_build_fake_row("41455")])
    wb.create_sheet("Autre feuille sans rapport")
    assert is_all_fees_mass_update(wb) is True
    print("✅ test_multiple_worksheets_detects_if_any_matches OK")


if __name__ == "__main__":
    test_true_positive_all_fees_workbook_detected()
    test_true_negative_adl_like_workbook_not_detected()
    test_empty_workbook_returns_false_without_crashing()
    test_partial_headers_not_falsely_detected()
    test_multiple_worksheets_detects_if_any_matches()
    print("\n🎉 Tous les tests passent.")
