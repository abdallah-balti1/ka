"""
Service de diff : compare les valeurs du fichier réuploadé à l'état
FRAIS récupéré via cosmos_api (/refetch_fees_data).

⚠️ Format de fresh_data_by_sha_cd mis à jour : chaque colonne est
maintenant un dict {"value": ..., "fee_id": ..., "fee_value_id": ...}
au lieu d'une valeur brute — nécessaire pour construire les CreData
envoyés à Cosmos (parent_entity_id=fee_id, entity_id=fee_value_id),
sur le même principe que le flux ADL existant
(ADL_IN_FEE_ID_LABEL/ADL_IN_FEE_VALUE_ID_LABEL).

Chaque diff détecté inclut maintenant fee_id/fee_value_id, prêts à
être utilisés directement pour construire un CreData.
"""

from typing import Dict, List

from constants.fees_template import EDITABLE_COLUMNS, KEYS, NUMERIC_EDITABLE_COLUMNS

_NUMERIC_KEYS = {KEYS[idx - 1] for idx in NUMERIC_EDITABLE_COLUMNS}
_EDITABLE_KEYS = {KEYS[idx - 1] for idx in EDITABLE_COLUMNS}


def _normalize_empty(value):
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _normalize_numeric(value):
    value = _normalize_empty(value)
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return round(float(value), 6)
    try:
        cleaned = str(value).strip().replace(",", ".")
        return round(float(cleaned), 6)
    except (ValueError, TypeError):
        return str(value).strip()


def _normalize_text(value):
    value = _normalize_empty(value)
    if value is None:
        return None
    return str(value).strip()


def _values_differ(key: str, file_value, fresh_value) -> bool:
    if key in _NUMERIC_KEYS:
        return _normalize_numeric(file_value) != _normalize_numeric(fresh_value)
    return _normalize_text(file_value) != _normalize_text(fresh_value)


class FeeDiffService:

    @staticmethod
    def build_diff(
        file_rows: List[Dict], fresh_data_by_sha_cd: Dict[str, Dict]
    ) -> List[Dict]:
        """
        file_rows : sortie de parse_fees_template_workbook — liste de
                    {"sha_cd": ..., <colonne éditable>: valeur, ...}
        fresh_data_by_sha_cd : sortie de /refetch_fees_data — dict
                    {sha_cd: {colonne: {"value":..., "fee_id":..., "fee_value_id":...}}}

        Retourne une liste de diffs, prêts à devenir des CreData :
            [{
                "sha_cd": ...,
                "field": ...,
                "old_value": ...,
                "new_value": ...,
                "fee_id": ...,          # parent_entity_id côté CreData
                "fee_value_id": ...,    # entity_id côté CreData
            }, ...]
        """
        diffs: List[Dict] = []

        for row in file_rows:
            sha_cd = row["sha_cd"]
            fresh_row = fresh_data_by_sha_cd.get(sha_cd, {})

            for key in _EDITABLE_KEYS:
                file_value = row.get(key)
                fresh_entry = fresh_row.get(key) or {}
                fresh_value = fresh_entry.get("value")

                if _values_differ(key, file_value, fresh_value):
                    diffs.append(
                        {
                            "sha_cd": sha_cd,
                            "field": key,
                            "old_value": fresh_value,
                            "new_value": file_value,
                            "fee_id": fresh_entry.get("fee_id"),
                            "fee_value_id": fresh_entry.get("fee_value_id"),
                        }
                    )

        return diffs
