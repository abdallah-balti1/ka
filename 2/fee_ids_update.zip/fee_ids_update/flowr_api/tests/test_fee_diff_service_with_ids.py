"""
Test de FeeDiffService.build_diff avec le nouveau format imbriqué
{"value":..., "fee_id":..., "fee_value_id":...} renvoyé par
/refetch_fees_data.

Lancer avec :
    python tests/test_fee_diff_service_with_ids.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from services.fee_diff_service import FeeDiffService  # noqa: E402


def test_diff_includes_fee_id_and_fee_value_id():
    file_rows = [
        {
            "sha_cd": "41455",
            "Max Management fees Rate": "0.5",  # modifié : était 0.4
            "Max Management fees Basis of Calculation": "Net assets",  # inchangé
        }
    ]
    fresh_data = {
        "41455": {
            "Max Management fees Rate": {
                "value": "0.4",
                "fee_id": "FEE123",
                "fee_value_id": "VAL456",
            },
            "Max Management fees Basis of Calculation": {
                "value": "Net assets",
                "fee_id": "FEE123",
                "fee_value_id": "VAL789",
            },
        }
    }

    diffs = FeeDiffService.build_diff(file_rows, fresh_data)

    assert len(diffs) == 1, f"Attendu 1 diff, obtenu {len(diffs)} : {diffs}"
    d = diffs[0]
    assert d["field"] == "Max Management fees Rate"
    assert d["old_value"] == "0.4"
    assert d["new_value"] == "0.5"
    assert d["fee_id"] == "FEE123"
    assert d["fee_value_id"] == "VAL456"
    print("✅ test_diff_includes_fee_id_and_fee_value_id OK")


def test_no_fresh_entry_gives_none_ids_but_still_detects_diff():
    """Si aucune ligne fraîche n'existe pour ce champ (nouveau fee créé
    par l'utilisateur, jamais en base), la diff doit quand même être
    détectée, avec fee_id/fee_value_id à None."""
    file_rows = [{"sha_cd": "99999", "Max Management fees Rate": "0.3"}]
    fresh_data = {"99999": {}}  # aucune fee en base pour ce sha_cd

    diffs = FeeDiffService.build_diff(file_rows, fresh_data)

    assert len(diffs) == 1
    assert diffs[0]["old_value"] is None
    assert diffs[0]["new_value"] == "0.3"
    assert diffs[0]["fee_id"] is None
    assert diffs[0]["fee_value_id"] is None
    print("✅ test_no_fresh_entry_gives_none_ids_but_still_detects_diff OK")


def test_no_diff_when_value_unchanged_ids_still_not_needed():
    file_rows = [{"sha_cd": "41455", "Max Management fees Rate": "0.4"}]
    fresh_data = {
        "41455": {
            "Max Management fees Rate": {
                "value": "0.4",
                "fee_id": "FEE123",
                "fee_value_id": "VAL456",
            }
        }
    }

    diffs = FeeDiffService.build_diff(file_rows, fresh_data)
    assert diffs == []
    print("✅ test_no_diff_when_value_unchanged_ids_still_not_needed OK")


if __name__ == "__main__":
    test_diff_includes_fee_id_and_fee_value_id()
    test_no_fresh_entry_gives_none_ids_but_still_detects_diff()
    test_no_diff_when_value_unchanged_ids_still_not_needed()
    print("\n🎉 Tous les tests passent.")
