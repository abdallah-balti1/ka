# -----------------------------------------------------------------------------
# REMPLACE la méthode get_raw_fees existante dans ExportQueryRepository
# (src/repositories/export_query_repository.py) par CETTE version.
#
# Différence : chaque ligne brute contient maintenant fee_id et
# fee_value_id (colonnes déjà présentes sur le modèle ProductFee,
# confirmées : fee_id = db.Column(db.String(100)),
# fee_value_id = db.Column(db.String(100)) — exactement ce qu'utilise
# déjà le flux ADL via ADL_IN_FEE_ID_LABEL/ADL_IN_FEE_VALUE_ID_LABEL).
#
# Ces IDs sont nécessaires côté flowr_api pour construire les CreData
# envoyés à Cosmos (parent_entity_id / entity_id), pas pour l'affichage
# Excel — mais on les récupère dans la même requête, aucun coût
# supplémentaire.
# -----------------------------------------------------------------------------

    @staticmethod
    def get_raw_fees(sha_cds: list[str]) -> list[dict]:
        """
        Fetch brut : UNE SEULE requête product_fee, filtrée sur sha_cd.
        Chaque ligne inclut fee_id/fee_value_id (identifiants réels de
        la ligne en base, nécessaires pour les events Cosmos) en plus
        des valeurs déjà traduites.
        """
        if not sha_cds:
            return []

        rows = (
            db.session.query(ProductFee)
            .filter(ProductFee.sha_cd.in_(sha_cds))
            .all()
        )

        types_needed = list(set(FIELD_TO_FIELD_VALUE_TYPE.values()))
        labels_map = get_cached_labels_map(types_needed)

        def _translate(field_name: str, code):
            if code is None:
                return None
            type_name = FIELD_TO_FIELD_VALUE_TYPE.get(field_name)
            if not type_name:
                return code
            return labels_map.get(type_name, {}).get(code, code)

        return [
            {
                "sha_cd": r.sha_cd,
                "fee_id": r.fee_id,
                "fee_value_id": r.fee_value_id,
                "fees_typ_cd": r.fees_typ_cd,
                "fees_subtype_cd": r.fees_subtype_cd,
                "fees_lvl_cd": r.fees_lvl_cd,
                "acq_or_not_acq_fees_cd": r.acq_or_not_acq_fees_cd,
                "specific_fees_cgy_cd": r.specific_fees_cgy_cd,
                "fees_pctg": r.fees_pctg,
                "basis_calc_cd": _translate("basis_calc_cd", r.basis_calc_cd),
                "calc_frq_cd": _translate("calc_frq_cd", r.calc_frq_cd),
                "pmt_frq_cd": _translate("pmt_frq_cd", r.pmt_frq_cd),
                "fees_paid_cd": _translate("fees_paid_cd", r.fees_paid_cd),
            }
            for r in rows
        ]
