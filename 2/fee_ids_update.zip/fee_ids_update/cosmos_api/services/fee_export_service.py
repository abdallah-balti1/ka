"""
Pivot : transforme les lignes brutes product_fee en dicts indexés par
sha_cd, piloté par la config déclarative FEE_GROUPS.

build_fee_columns(raw_fees)  -> {sha_cd: {colonne: valeur}}
    Inchangé — utilisé par /retrieve_fees_data pour remplir l'Excel.

build_fee_ids(raw_fees)      -> {sha_cd: {colonne: {"fee_id":..., "fee_value_id":...}}}
    NOUVEAU — utilisé par /refetch_fees_data pour que flowr_api puisse
    construire les CreData (parent_entity_id / entity_id) envoyés à
    Cosmos. Réutilise EXACTEMENT la même logique de matching que
    build_fee_columns (les deux DOIVENT rester cohérents entre eux —
    une ligne qui matche un groupe pour l'une doit matcher le même
    groupe pour l'autre, d'où le code partagé via _match_rows).
"""

from typing import Dict, List, Tuple

from constants.fee_groups_config import FEE_GROUPS


class FeeExportService:

    @staticmethod
    def _match_rows(raw_fees: List[Dict]) -> Dict[Tuple[str, str], Dict]:
        """
        Indexe chaque ligne brute par (sha_cd, group_key) — factorisé
        pour être réutilisé par build_fee_columns ET build_fee_ids, afin
        que les deux ne puissent jamais diverger sur quelle ligne
        matche quel groupe.
        """
        indexed: Dict[Tuple[str, str], Dict] = {}
        for row in raw_fees:
            for group in FEE_GROUPS:
                if FeeExportService._matches(row, group["match"]):
                    indexed[(row["sha_cd"], group["key"])] = row
                    break
        return indexed

    @staticmethod
    def build_fee_columns(raw_fees: List[Dict]) -> Dict[str, Dict]:
        if not raw_fees:
            return {}

        indexed = FeeExportService._match_rows(raw_fees)
        result: Dict[str, Dict] = {}
        sha_cds = {row["sha_cd"] for row in raw_fees}

        for sha_cd in sha_cds:
            result[sha_cd] = {}
            for group in FEE_GROUPS:
                matched_row = indexed.get((sha_cd, group["key"]))
                for excel_col, field in group["columns"].items():
                    result[sha_cd][excel_col] = (
                        matched_row.get(field) if matched_row else None
                    )

        return result

    @staticmethod
    def build_fee_ids(raw_fees: List[Dict]) -> Dict[str, Dict]:
        """
        Retourne {sha_cd: {colonne: {"fee_id": ..., "fee_value_id": ...}}}
        Une entrée par colonne éditable (même structure que
        build_fee_columns), mais avec les IDs de la ligne product_fee
        matchée au lieu de la valeur — None des deux si aucune ligne
        n'a matché ce groupe pour ce sha_cd.
        """
        if not raw_fees:
            return {}

        indexed = FeeExportService._match_rows(raw_fees)
        result: Dict[str, Dict] = {}
        sha_cds = {row["sha_cd"] for row in raw_fees}

        for sha_cd in sha_cds:
            result[sha_cd] = {}
            for group in FEE_GROUPS:
                matched_row = indexed.get((sha_cd, group["key"]))
                ids = {
                    "fee_id": matched_row.get("fee_id") if matched_row else None,
                    "fee_value_id": matched_row.get("fee_value_id") if matched_row else None,
                }
                for excel_col in group["columns"]:
                    result[sha_cd][excel_col] = ids

        return result

    @staticmethod
    def _matches(row: Dict, criteria: Dict) -> bool:
        return all(row.get(k) == v for k, v in criteria.items())
