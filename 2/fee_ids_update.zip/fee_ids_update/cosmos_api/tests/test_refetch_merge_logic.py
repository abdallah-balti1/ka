"""
Test de la logique de merge (values + ids -> réponse finale) de
RefetchFeesDataResource.post, isolée sans Flask/DB.

Lancer avec :
    python tests/test_refetch_merge_logic.py
"""


def merge_values_and_ids(sha_cd_list, fee_values, fee_ids):
    """Reproduit la logique de merge de la resource, isolée pour test."""
    result = {}
    for sha_cd in sha_cd_list:
        values_for_sha = fee_values.get(sha_cd, {})
        ids_for_sha = fee_ids.get(sha_cd, {})

        columns = set(values_for_sha) | set(ids_for_sha)
        result[sha_cd] = {
            col: {
                "value": values_for_sha.get(col),
                "fee_id": ids_for_sha.get(col, {}).get("fee_id"),
                "fee_value_id": ids_for_sha.get(col, {}).get("fee_value_id"),
            }
            for col in columns
        }
    return result


def test_merge_combines_value_and_ids():
    fee_values = {"41455": {"Rate": "0.4"}}
    fee_ids = {"41455": {"Rate": {"fee_id": "F1", "fee_value_id": "V1"}}}

    result = merge_values_and_ids(["41455"], fee_values, fee_ids)

    assert result == {
        "41455": {"Rate": {"value": "0.4", "fee_id": "F1", "fee_value_id": "V1"}}
    }
    print("✅ test_merge_combines_value_and_ids OK")


def test_sha_cd_without_any_fee_gets_empty_dict():
    result = merge_values_and_ids(["99999"], {}, {})
    assert result == {"99999": {}}
    print("✅ test_sha_cd_without_any_fee_gets_empty_dict OK")


def test_all_requested_sha_cds_present():
    fee_values = {"A": {"Rate": "0.1"}}
    fee_ids = {"A": {"Rate": {"fee_id": "F1", "fee_value_id": "V1"}}}

    result = merge_values_and_ids(["A", "B"], fee_values, fee_ids)

    assert set(result.keys()) == {"A", "B"}
    assert result["B"] == {}
    print("✅ test_all_requested_sha_cds_present OK")


if __name__ == "__main__":
    test_merge_combines_value_and_ids()
    test_sha_cd_without_any_fee_gets_empty_dict()
    test_all_requested_sha_cds_present()
    print("\n🎉 Tous les tests passent.")
