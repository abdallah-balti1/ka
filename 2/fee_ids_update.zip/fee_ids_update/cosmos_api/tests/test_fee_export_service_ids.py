"""
Test de FeeExportService.build_fee_ids : vérifie qu'il produit EXACTEMENT
les mêmes clés (sha_cd, colonne) que build_fee_columns (même matching,
factorisé via _match_rows), et que les IDs correspondent bien à la
ligne brute qui a matché.

Lancer avec :
    python tests/test_fee_export_service_ids.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))  # pour le stub constants

# Fait pointer "constants.fee_groups_config" vers notre stub de test
import types
import fee_groups_config_stub

constants_pkg = types.ModuleType("constants")
constants_pkg.fee_groups_config = fee_groups_config_stub
sys.modules["constants"] = constants_pkg
sys.modules["constants.fee_groups_config"] = fee_groups_config_stub

from services.fee_export_service import FeeExportService  # noqa: E402


def _raw_row(sha_cd, fee_id, fee_value_id, **overrides):
    row = {
        "sha_cd": sha_cd,
        "fee_id": fee_id,
        "fee_value_id": fee_value_id,
        "fees_typ_cd": "2",
        "fees_subtype_cd": "1",
        "fees_lvl_cd": "MAX",
        "acq_or_not_acq_fees_cd": None,
        "specific_fees_cgy_cd": None,
        "fees_pctg": "0.4",
        "basis_calc_cd": "Net assets",
        "calc_frq_cd": None,
        "pmt_frq_cd": None,
        "fees_paid_cd": None,
    }
    row.update(overrides)
    return row


def test_ids_and_values_have_same_keys():
    raw_fees = [_raw_row("41455", "FEE1", "VAL1")]

    values = FeeExportService.build_fee_columns(raw_fees)
    ids = FeeExportService.build_fee_ids(raw_fees)

    assert set(values.keys()) == set(ids.keys())
    assert set(values["41455"].keys()) == set(ids["41455"].keys())
    print("✅ test_ids_and_values_have_same_keys OK")


def test_ids_match_the_correct_row():
    raw_fees = [_raw_row("41455", "FEE1", "VAL1")]

    ids = FeeExportService.build_fee_ids(raw_fees)

    assert ids["41455"]["Max Management fees Rate"] == {
        "fee_id": "FEE1",
        "fee_value_id": "VAL1",
    }
    print("✅ test_ids_match_the_correct_row OK")


def test_no_matching_row_gives_none_ids():
    """Un sha_cd sans fee Management ne doit pas avoir d'IDs pour cette colonne."""
    raw_fees = [_raw_row("41455", "FEE1", "VAL1", fees_subtype_cd="3")]  # Distribution, pas Management

    ids = FeeExportService.build_fee_ids(raw_fees)

    assert ids["41455"]["Max Management fees Rate"] == {
        "fee_id": None,
        "fee_value_id": None,
    }
    print("✅ test_no_matching_row_gives_none_ids OK")


def test_two_shares_get_their_own_ids():
    raw_fees = [
        _raw_row("41455", "FEE1", "VAL1"),
        _raw_row("42184", "FEE2", "VAL2"),
    ]

    ids = FeeExportService.build_fee_ids(raw_fees)

    assert ids["41455"]["Max Management fees Rate"]["fee_id"] == "FEE1"
    assert ids["42184"]["Max Management fees Rate"]["fee_id"] == "FEE2"
    print("✅ test_two_shares_get_their_own_ids OK")


if __name__ == "__main__":
    test_ids_and_values_have_same_keys()
    test_ids_match_the_correct_row()
    test_no_matching_row_gives_none_ids()
    test_two_shares_get_their_own_ids()
    print("\n🎉 Tous les tests passent.")
