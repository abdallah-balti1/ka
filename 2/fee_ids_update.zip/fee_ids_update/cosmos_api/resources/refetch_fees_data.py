from context_managers.session_critical_action_manager import SessionCriticalActionManager
from flasgger.utils import swag_from
from flask import request
from flask_restful import Resource

from config import DEV_TEAM_EMAILS
from db import db
from repositories.export_query_repository import ExportQueryRepository
from services.fee_export_service import FeeExportService
from utils.required_authentication import required_authentication


class RefetchFeesDataResource(Resource):
    """Renvoie l'état FRAIS des fees pour une liste de sha_cd, chaque
    colonne accompagnée de son fee_id/fee_value_id (nécessaires côté
    flowr_api pour construire les CreData envoyés à Cosmos).

    Format de réponse :
        {
          "41455": {
            "Max Management fees Rate": {
              "value": "0.4",
              "fee_id": "...",
              "fee_value_id": "..."
            },
            ...
          },
          ...
        }
    """

    @staticmethod
    @required_authentication()
    @swag_from("../../swagger/refetch_fees_data/POST.yml")
    def post(user):
        data = request.get_json(silent=True) or {}

        sha_cd_list = data.get("sha_cd_list", [])
        if not isinstance(sha_cd_list, list) or not sha_cd_list:
            return {"error": "sha_cd_list is required and must be a non-empty list"}, 400

        sha_cd_list = [str(x).strip() for x in sha_cd_list if str(x).strip()]
        if not sha_cd_list:
            return {"error": "sha_cd_list is empty"}, 400

        with SessionCriticalActionManager("last_file_version", db.session, DEV_TEAM_EMAILS):
            raw_fees = ExportQueryRepository.get_raw_fees(sha_cd_list)
            fee_values = FeeExportService.build_fee_columns(raw_fees)
            fee_ids = FeeExportService.build_fee_ids(raw_fees)

        result = {}
        for sha_cd in sha_cd_list:
            values_for_sha = fee_values.get(sha_cd, {})
            ids_for_sha = fee_ids.get(sha_cd, {})

            columns = set(values_for_sha) | set(ids_for_sha)
            result[sha_cd] = {
                col: {
                    "value": values_for_sha.get(col),
                    "fee_id": ids_for_sha.get(col, {}).get("fee_id"),
                    "fee_value_id": ids_for_sha.get(col, {}).get("fee_value_id"),
                }
                for col in columns
            }

        return result, 200
