""" Defines the FieldValue repository """

from sqlalchemy.orm import joinedload
from typing import List

from db import db
from models import FieldValue, FieldValueDependency, FileVersionTypeEnum


class FieldValueRepository:
    """The repository for the FieldValue model"""

    @staticmethod
    def get_by_types(types):
        """List FieldValues by types"""
        if not types:
            return []

        query = FieldValue.query.filter(FieldValue.type.in_(types)).options(
            joinedload(FieldValue.dependencies).joinedload(FieldValueDependency.parent_value)
        )
        return query.all()

    @staticmethod
    def add_field_value_dependency(
        parent_field_value: FieldValue, child_field_value: FieldValue, source: str = FileVersionTypeEnum.TOP_ALL.value
    ) -> bool:
        """add dependency between parent and child field_values
        return true if dependency was added
        """

        # search for existing dependency
        for dependency in child_field_value.dependencies:
            if dependency.parent_value == parent_field_value:
                return False
        # if not found, then create a new dependency
        field_value_dependency = FieldValueDependency(source=source)
        field_value_dependency.parent_value = parent_field_value
        child_field_value.dependencies.append(field_value_dependency)
        return True

    @staticmethod
    def update_field_values_dependencies(
        parent_child_relationships: List[tuple[str, str, str, str]], parent_type: str, child_type: str
    ):
        """This function generate dependencies between PRODUCT and SHARES
        arguments:
            parent_child_relationships: contains a list of tuples (parent_code, parent_name, child_code, child_name)
            parent_type: is the name of the parent list known in the field_value table
            child_type: is the name of the child list known in the field_value table
        """

        def _get_or_add_field_value(field_values_dict, type, code, label):
            """get or create field_value"""
            field_value = field_values_dict.get(code)
            if not field_value:
                field_value = FieldValue(code=code, type=type, label_fr=label, label_en=label, is_active=True)
                field_values_dict[code] = field_value
            return field_value

        # unload existing field_values over parent and child lists
        field_values = FieldValueRepository.get_by_types([parent_type, child_type])
        parent_field_values_dict = {
            field_value.code: field_value for field_value in field_values if field_value.type == parent_type
        }
        child_field_values_dict = {
            field_value.code: field_value for field_value in field_values if field_value.type == child_type
        }

        # loop over all relationships
        for parent_code, parent_name, child_code, child_name, *_ in parent_child_relationships:
            # find both product and share field_values (or create if don't exist yet)
            parent_field_value = _get_or_add_field_value(
                parent_field_values_dict, parent_type, parent_code, parent_name
            )
            child_field_value = _get_or_add_field_value(child_field_values_dict, child_type, child_code, child_name)
            # add dependency
            FieldValueRepository.add_field_value_dependency(
                parent_field_value, child_field_value, f"{parent_type}-{child_type}"
            )

        # save changes
        db.session.add_all(child_field_values_dict.values())
        db.session.add_all(parent_field_values_dict.values())

    @staticmethod
    def get_labels_map(types: list[str]) -> dict[str, dict[str, str]]:
        """
        Builds a code -> English label map for each requested field_value
        type, in a single query regardless of how many types are asked
        for.

        Only active values are included - a deactivated code shouldn't be
        offered as a choice anywhere it's used to populate a dropdown.

        Args:
            types: field_value types to retrieve, e.g.
                ["BASIS_OF_CALCULATION", "FEE_CALCULATION_FREQUENCY"]

        Returns:
            {
                "FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly"},
                "BASIS_OF_CALCULATION": {"1": "Net assets"},
            }
        """
        if not types:
            return {}

        rows = (
            db.session.query(FieldValue.type, FieldValue.code, FieldValue.label_en)
            .filter(FieldValue.type.in_(types), FieldValue.is_active.is_(True))
            .all()
        )

        result: dict[str, dict[str, str]] = {}
        for type_, code, label_en in rows:
            result.setdefault(type_, {})[code] = label_en
        return result
