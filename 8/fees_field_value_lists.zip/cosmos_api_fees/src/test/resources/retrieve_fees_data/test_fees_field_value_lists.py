import unittest
from unittest.mock import patch

from models.field_value import FieldValue
from server import server
from tests.utils import init_database


class TestFeesFieldValueListsResource(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        init_database()

        FieldValue(code="1", type="BASIS_OF_CALCULATION",
                   label_fr="Actif net", label_en="Net assets",
                   is_active=True).save()
        FieldValue(code="999", type="BASIS_OF_CALCULATION",
                   label_fr="Ancien code", label_en="Old code",
                   is_active=False).save()

        FieldValue(code="M", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Mensuelle", label_en="Monthly",
                   is_active=True).save()

        FieldValue(code="1", type="FEES_PAID_TO",
                   label_fr="Conservateur", label_en="Custodian",
                   is_active=True).save()

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_returns_values_grouped_by_type(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        self.assertEqual(response.status_code, 200)
        data = response.get_json()

        self.assertEqual(data["BASIS_OF_CALCULATION"], {"1": "Net assets"})
        self.assertEqual(data["FEE_CALCULATION_FREQUENCY"], {"M": "Monthly"})
        self.assertEqual(data["FEES_PAID_TO"], {"1": "Custodian"})

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_inactive_values_are_excluded(self, _):
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertNotIn("999", data["BASIS_OF_CALCULATION"])

    @patch("utils.required_authentication.required_authentication",
           return_value=lambda f: f)
    def test_type_with_no_active_values_returns_empty_dict_not_missing_key(self, _):
        # A type with zero matching rows must still appear as a key with
        # an empty dict - flowr_api's list_ranges.get(type) / reverse_maps
        # would otherwise silently fall back to free text for a type that
        # legitimately has no values yet, same as a typo would.
        client = server.test_client()
        response = client.get("/fees_field_value_lists")

        data = response.get_json()
        self.assertIn("BASIS_OF_CALCULATION", data)
        self.assertIn("FEE_CALCULATION_FREQUENCY", data)
        self.assertIn("FEES_PAID_TO", data)


if __name__ == "__main__":
    unittest.main()
