import unittest

from models.field_value import FieldValue
from repositories.field_value import FieldValueRepository
from tests.utils import init_database


class TestGetLabelsMap(unittest.TestCase):
    """
    Covers the new get_labels_map static method added to the existing
    FieldValueRepository - kept in its own file so it doesn't get lost
    among the dependency-related tests already covering the rest of that
    class.
    """

    @classmethod
    def setUpClass(cls):
        init_database()

        FieldValue(code="D", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Journalière", label_en="Daily",
                   is_active=True).save()
        FieldValue(code="M", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Mensuelle", label_en="Monthly",
                   is_active=True).save()
        FieldValue(code="OLD", type="FEE_CALCULATION_FREQUENCY",
                   label_fr="Ancien", label_en="Deprecated",
                   is_active=False).save()

        FieldValue(code="1", type="BASIS_OF_CALCULATION",
                   label_fr="Actif net", label_en="Net assets",
                   is_active=True).save()

    def test_groups_labels_by_type_in_a_single_query(self):
        result = FieldValueRepository.get_labels_map(
            ["FEE_CALCULATION_FREQUENCY", "BASIS_OF_CALCULATION"]
        )

        self.assertEqual(
            result["FEE_CALCULATION_FREQUENCY"],
            {"D": "Daily", "M": "Monthly"},
        )
        self.assertEqual(result["BASIS_OF_CALCULATION"], {"1": "Net assets"})

    def test_excludes_inactive_values(self):
        result = FieldValueRepository.get_labels_map(["FEE_CALCULATION_FREQUENCY"])
        self.assertNotIn("OLD", result["FEE_CALCULATION_FREQUENCY"])

    def test_empty_types_returns_empty_dict(self):
        self.assertEqual(FieldValueRepository.get_labels_map([]), {})


if __name__ == "__main__":
    unittest.main()
