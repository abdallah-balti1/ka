"""
Resource for Fees Field Value Lists

Exposes the field_value referentials backing the free-text fee fields of
the All Fees template (Basis of Calculation, Calculation Frequency,
Payment Frequency, Paid To), so flowr_api can turn those Excel cells into
dropdowns instead of leaving them free-text.

Response is keyed by field_value TYPE, not by ProductFee field name -
that's the contract flowr_api's fees_template.py and fee_cre_builder.py
are already built against (both go through
constants.fees_cre_mapping.get_field_value_type(), which returns the
type). Payment Frequency and Calculation Frequency map to the same type
(FEE_CALCULATION_FREQUENCY), so they naturally end up sharing one entry
here - nothing extra to do on either side for that.
"""

from flasgger.utils import swag_from
from flask_restful import Resource

from constants.field_value_types_config import FIELD_TO_FIELD_VALUE_TYPE
from repositories.field_value import FieldValueRepository
from utils.required_authentication import required_authentication

# Derived from FIELD_TO_FIELD_VALUE_TYPE rather than hardcoded again here -
# one list of "which types the fees template cares about" to keep in sync,
# not two.
FEES_TEXT_FIELD_VALUE_TYPES = sorted(set(FIELD_TO_FIELD_VALUE_TYPE.values()))


class FeesFieldValueListsResource(Resource):
    """
    Endpoint that returns the allowed values for each field_value type
    used by the fees template's free-text columns.

    Response Format:
        {
            "BASIS_OF_CALCULATION": {"1": "Net assets", ...},
            "FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly", ...},
            "FEES_PAID_TO": {"1": "Custodian", ...}
        }
    """

    @staticmethod
    @required_authentication()
    @swag_from("../../swagger/fees_field_value_lists/GET.yml")
    def get(user):
        labels_by_type = FieldValueRepository.get_labels_map(FEES_TEXT_FIELD_VALUE_TYPES)
        result = {
            field_value_type: labels_by_type.get(field_value_type, {})
            for field_value_type in FEES_TEXT_FIELD_VALUE_TYPES
        }
        return result, 200
