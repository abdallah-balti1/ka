# fees_field_value_lists — v5, response shape fixed to match flowr_api's contract

## Why this changed again

flowr_api's `util/mass_update/fees_template.py` and
`services/fee_cre_builder.py` both look values up through
`constants.fees_cre_mapping.get_field_value_type(column_label)`, which
returns a field_value TYPE (BASIS_OF_CALCULATION,
FEE_CALCULATION_FREQUENCY, FEES_PAID_TO - 3 keys, Payment Frequency and
Calculation Frequency share one). The previous version of this endpoint
returned a dict keyed by ProductFee field name instead (4 keys). Same
data, wrong shape - flowr_api's lookups would have silently returned
nothing and every column would have quietly stayed free-text, no error
anywhere.

Fixed by changing the resource's output shape back to type-keyed.
`FieldValueRepository.get_labels_map()` itself is unchanged - it already
returns type-keyed data, the previous resource was just re-grouping it by
field name on top for no reason once we found the actual consumer's
requirements.

## Where each file goes (paths relative to `src/`)

- `resources/retrieve_fees_data/fees_field_value_lists.py` -> same path
- `test/resources/retrieve_fees_data/test_fees_field_value_lists.py` -> same path

Unchanged from before, still to apply:

- `repositories_field_value_MERGED.py` -> full replacement for
  `repositories/field_value.py` (adds `get_labels_map`, drops the
  duplicate `field_value_repository.py` class - see that file's own
  instructions for the grep-and-fix-imports step)
- `routes/fees_field_value_lists.py` -> same path
- `swagger/fees_field_value_lists/GET.yml` -> same path
- `test/repositories/test_field_value_get_labels_map.py` -> same path

## Still open

- Registering `FEES_FIELD_VALUE_LISTS_BLUEPRINT` wherever
  `REFETCH_FEES_DATA_BLUEPRINT` is registered.
