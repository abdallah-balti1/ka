"""
Mapping colonne éditable -> métadonnées Cosmos (PIVOT_FIELD_NAME,
IDENTIFICATION_FIELDS) — INCHANGÉ par rapport à la version précédente.

⚠️ AJOUT pour le chantier "listes déroulantes" : FIELD_VALUE_TYPE_BY_SUFFIX
+ get_field_value_type(column_label). Sert à deux endroits :
  1. Génération Excel (util/mass_update/fees_template.py) : savoir quelle
     liste de valeurs autorisées (feuille "Lists") associer à quelle colonne
  2. Construction des CreData (services/fee_cre_builder.py) : savoir quel
     champ texte doit être traduit label -> code avant envoi à Cosmos

Codes FEES_SUB_TYPE confirmés (export métier du 07/08) — INCHANGÉ.
"""

FEES_TYP_CD = "2"

SUBTYPE_MANAGEMENT = "1"
SUBTYPE_ADVISORY = "2"
SUBTYPE_DISTRIBUTION = "3"
SUBTYPE_CHARITY = "4"
SUBTYPE_SPECIFIC_EXTERNAL = "5"
SUBTYPE_SUBSCRIPTION = "7"
SUBTYPE_REDEMPTION = "8"
SUBTYPE_CONVERSION = "9"

SUBTYPE_BY_KEYWORD = [
    ("Management fees", SUBTYPE_MANAGEMENT),
    ("Advisory fees", SUBTYPE_ADVISORY),
    ("Distribution fees", SUBTYPE_DISTRIBUTION),
    ("Charity fees", SUBTYPE_CHARITY),
    ("Other Costs", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Foreign UCIs Tax", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Taxe Abonnement", SUBTYPE_SPECIFIC_EXTERNAL),
    ("Subscription", SUBTYPE_SUBSCRIPTION),
    ("Redemption", SUBTYPE_REDEMPTION),
    ("Conversion", SUBTYPE_CONVERSION),
]

PIVOT_FIELD_NAME_BY_SUFFIX = [
    ("Rate", "FeesPctg"),
    ("Basis of Calculation", "BasisCalcCd"),
    ("Calculation Frequency", "CalcFrqCd"),
    ("Payment Frequency", "PmtFrqCd"),
    ("Paid To", "FeesPaidCd"),
]

# NOUVEAU : suffixe de colonne -> type field_value (None = pas de traduction,
# colonne numérique). Doit rester synchronisé avec
# FEES_TEXT_FIELD_VALUE_TYPES côté cosmos_api (resources/fees_field_value_lists.py).
FIELD_VALUE_TYPE_BY_SUFFIX = [
    ("Basis of Calculation", "BASIS_OF_CALCULATION"),
    ("Calculation Frequency", "FEE_CALCULATION_FREQUENCY"),
    ("Payment Frequency", "FEE_CALCULATION_FREQUENCY"),  # même type que Calculation Frequency
    ("Paid To", "FEES_PAID_TO"),
]


def get_identification_fields(column_label: str) -> dict:
    for keyword, subtype in SUBTYPE_BY_KEYWORD:
        if keyword in column_label:
            return {"FeesTypCd": FEES_TYP_CD, "FeesSubtypeCd": subtype}
    raise ValueError(
        f"Impossible de déterminer le FeesSubtypeCd pour la colonne '{column_label}'"
    )


def get_pivot_field_name(column_label: str) -> str:
    for suffix, field_name in PIVOT_FIELD_NAME_BY_SUFFIX:
        if column_label.endswith(suffix):
            return field_name
    raise ValueError(
        f"Impossible de déterminer le PIVOT_FIELD_NAME pour la colonne '{column_label}'"
    )


def get_field_value_type(column_label: str):
    """Retourne le type field_value (BASIS_OF_CALCULATION, etc.) pour une
    colonne texte, ou None si la colonne est numérique (Rate) — auquel cas
    aucune traduction label -> code n'est nécessaire."""
    for suffix, type_name in FIELD_VALUE_TYPE_BY_SUFFIX:
        if column_label.endswith(suffix):
            return type_name
    return None
