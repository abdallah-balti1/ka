"""
Génération du template Excel "Fees" — structure 3 niveaux d'en-tête,
INCHANGÉE par rapport à la version précédente.

⚠️ AJOUT pour le chantier "listes déroulantes" :
  - create_lists_sheet(wb, field_value_lists) : nouvelle feuille cachée
    "Lists", une colonne par type field_value, contenant tous les labels
    autorisés
  - create_data_validation(...) étendue : en plus de la validation
    numérique existante (Rate), ajoute une validation type="list" sur
    chaque colonne texte (Basis of Calculation, Calculation Frequency,
    Payment Frequency, Paid To), pointant vers la plage correspondante
    de la feuille "Lists"
  - create_fees_template_workbook(fees_data) : va chercher les listes
    elle-même via get_fees_field_value_lists() (comme cosmos_api fait
    pour ses propres caches) — AUCUN changement nécessaire côté appelant
    (get_mass_update_template.py reste inchangé)

Si get_fees_field_value_lists() échoue ou renvoie un dict vide (ex: cosmos_api
indisponible), le template se génère quand même SANS les dropdowns plutôt que
de planter — dégradation propre, pas de blocage total pour une fonctionnalité
annexe.
"""

import logging

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.protection import SheetProtection
from openpyxl.worksheet.worksheet import Worksheet
from typing import Dict, List

from client.smartgps import get_fees_field_value_lists
from constants.fees_cre_mapping import get_field_value_type
from constants.fees_template import (
    BASE_COLUMNS,
    BORDER_COLOR,
    COL_WIDTHS,
    COLOR_BASE,
    COLUMN_LABEL_ROW,
    COLUMN_LABEL_ROW_HEIGHT,
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    DATA_VALIDATION_ERROR_MESSAGE,
    DATA_VALIDATION_ERROR_TITLE,
    EDIT_FILL_COLOR,
    EDITABLE_COLUMNS,
    FONT_NAME,
    FONT_SIZE,
    HEADERS,
    KEYS,
    N_BASE_COLUMNS,
    NUMERIC_EDITABLE_COLUMNS,
    PROD_CD_COLUMN_INDEX,
    SECTION_GROUPS,
    SECTION_ROW_HEIGHT,
    SECTION_TITLE_ROW,
    SHEET_NAME,
    SUBSECTION_GROUPS,
    SUBSECTION_ROW_HEIGHT,
    SUBSECTION_TITLE_ROW,
    TEXT_EDITABLE_COLUMNS,
    TOTAL_COLUMNS,
)

LISTS_SHEET_NAME = "Lists"


def create_styles() -> Dict[str, object]:
    edit_fill = PatternFill("solid", fgColor=EDIT_FILL_COLOR)
    base_fill = PatternFill("solid", fgColor=COLOR_BASE)

    font_white_bold = Font(name=FONT_NAME, size=FONT_SIZE, bold=True, color="FFFFFF")
    font_black_bold = Font(name=FONT_NAME, size=FONT_SIZE, bold=True, color="000000")
    font_black = Font(name=FONT_NAME, size=FONT_SIZE, color="000000")

    align_center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    align_left = Alignment(horizontal="left", vertical="center", wrap_text=True)

    thin = Side(style="thin", color=BORDER_COLOR)
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    return {
        "edit_fill": edit_fill,
        "base_fill": base_fill,
        "font_white_bold": font_white_bold,
        "font_black_bold": font_black_bold,
        "font_black": font_black,
        "align_center": align_center,
        "align_left": align_left,
        "border": border,
    }


def create_header_rows(ws: Worksheet, styles: Dict[str, object]) -> None:
    for col_idx, label in enumerate(HEADERS[:N_BASE_COLUMNS], start=1):
        ws.merge_cells(
            start_row=SECTION_TITLE_ROW, start_column=col_idx,
            end_row=COLUMN_LABEL_ROW, end_column=col_idx,
        )
        cell = ws.cell(row=SECTION_TITLE_ROW, column=col_idx, value=label)
        cell.fill = styles["base_fill"]
        cell.font = styles["font_black_bold"]
        cell.alignment = styles["align_center"]
        cell.border = styles["border"]

    for start_col, end_col, title, color in SECTION_GROUPS:
        fill = PatternFill("solid", fgColor=color)
        if end_col > start_col:
            ws.merge_cells(start_row=SECTION_TITLE_ROW, start_column=start_col,
                            end_row=SECTION_TITLE_ROW, end_column=end_col)
        cell = ws.cell(row=SECTION_TITLE_ROW, column=start_col, value=title)
        cell.fill = fill
        cell.font = styles["font_white_bold"]
        cell.alignment = styles["align_center"]
        for col in range(start_col, end_col + 1):
            ws.cell(row=SECTION_TITLE_ROW, column=col).border = styles["border"]

    for start_col, end_col, subtitle, color in SUBSECTION_GROUPS:
        fill = PatternFill("solid", fgColor=color)
        if end_col > start_col:
            ws.merge_cells(start_row=SUBSECTION_TITLE_ROW, start_column=start_col,
                            end_row=SUBSECTION_TITLE_ROW, end_column=end_col)
        cell = ws.cell(row=SUBSECTION_TITLE_ROW, column=start_col, value=subtitle)
        cell.fill = fill
        cell.font = styles["font_white_bold"]
        cell.alignment = styles["align_center"]
        for col in range(start_col, end_col + 1):
            ws.cell(row=SUBSECTION_TITLE_ROW, column=col).border = styles["border"]

    for col_idx in range(N_BASE_COLUMNS + 1, TOTAL_COLUMNS + 1):
        color = next(c for start, end, _, c in SECTION_GROUPS if start <= col_idx <= end)
        cell = ws.cell(row=COLUMN_LABEL_ROW, column=col_idx, value=HEADERS[col_idx - 1])
        cell.fill = PatternFill("solid", fgColor=color)
        cell.font = styles["font_white_bold"]
        cell.alignment = styles["align_center"]
        cell.border = styles["border"]

    ws.row_dimensions[SECTION_TITLE_ROW].height = SECTION_ROW_HEIGHT
    ws.row_dimensions[SUBSECTION_TITLE_ROW].height = SUBSECTION_ROW_HEIGHT
    ws.row_dimensions[COLUMN_LABEL_ROW].height = COLUMN_LABEL_ROW_HEIGHT


def create_data_rows(ws: Worksheet, fees_data: List[Dict], styles: Dict[str, object]) -> None:
    for i, row in enumerate(fees_data):
        r = DATA_START_ROW + i
        for col_idx, key in enumerate(KEYS, start=1):
            value = row.get(key)
            cell = ws.cell(row=r, column=col_idx, value=value)
            cell.font = styles["font_black"]
            cell.border = styles["border"]
            cell.alignment = (
                styles["align_left"] if col_idx <= N_BASE_COLUMNS else styles["align_center"]
            )
            if col_idx in EDITABLE_COLUMNS:
                cell.fill = styles["edit_fill"]
                if col_idx in NUMERIC_EDITABLE_COLUMNS:
                    cell.number_format = "0.00"


def create_lists_sheet(wb, field_value_lists: Dict[str, Dict[str, str]]) -> Dict[str, str]:
    """
    Crée une feuille cachée "Lists", une colonne par type field_value,
    contenant tous les labels autorisés (une valeur par ligne, à partir
    de la ligne 2 — ligne 1 = nom du type, pour lisibilité en debug).

    Retourne {type: "Lists!$A$2:$A$5"} — la plage Excel à référencer dans
    une DataValidation(type="list", formula1=...) pour ce type.

    Si field_value_lists est vide (cosmos_api indisponible ou aucune
    donnée), retourne {} — pas de feuille créée, pas de dropdown, mais
    le reste du template se génère normalement.
    """
    if not field_value_lists:
        return {}

    ws_lists = wb.create_sheet(LISTS_SHEET_NAME)
    range_by_type: Dict[str, str] = {}

    for col_idx, (type_name, codes_to_labels) in enumerate(field_value_lists.items(), start=1):
        labels = sorted(set(codes_to_labels.values()))
        if not labels:
            continue

        col_letter = get_column_letter(col_idx)
        ws_lists.cell(row=1, column=col_idx, value=type_name)
        for i, label in enumerate(labels, start=2):
            ws_lists.cell(row=i, column=col_idx, value=label)

        last_row = 1 + len(labels)
        range_by_type[type_name] = f"{LISTS_SHEET_NAME}!${col_letter}$2:${col_letter}${last_row}"

    # Cachée, mais PAS "veryHidden" : reste modifiable/consultable depuis
    # Excel (Affichage > Afficher) en cas de debug, contrairement à
    # veryHidden qui n'est accessible que par macro/VBA.
    ws_lists.sheet_state = "hidden"

    return range_by_type


def create_data_validation(
    ws: Worksheet, fees_data: List[Dict], list_ranges: Dict[str, str]
) -> None:
    """
    - Colonnes numériques (Rate) : validation "nombre réel >= 0 ou vide",
      INCHANGÉE.
    - Colonnes texte (Basis of Calculation, Calculation Frequency,
      Payment Frequency, Paid To) : NOUVEAU — validation type="list"
      pointant vers la feuille "Lists", si une plage existe pour le type
      de cette colonne. Si list_ranges est vide (cosmos_api indisponible
      à la génération), ces colonnes restent en saisie libre plutôt que
      de bloquer la génération du fichier.
    """
    n_rows = max(len(fees_data or []), 1)
    end_row = DATA_START_ROW + n_rows - 1

    def make_numeric_formula(anchor_cell: str) -> str:
        return (
            "OR("
            f'{anchor_cell}="",'
            f'IFERROR(VALUE(SUBSTITUTE({anchor_cell},".",","))>=0,FALSE),'
            f'IFERROR(VALUE(SUBSTITUTE({anchor_cell},",","."))>=0,FALSE)'
            ")"
        )

    for col_idx in NUMERIC_EDITABLE_COLUMNS:
        col_letter = get_column_letter(col_idx)
        anchor = f"{col_letter}{DATA_START_ROW}"
        dv = DataValidation(
            type="custom",
            formula1=make_numeric_formula(anchor),
            allow_blank=True,
            showErrorMessage=True,
            errorStyle="stop",
            errorTitle=DATA_VALIDATION_ERROR_TITLE,
            error=DATA_VALIDATION_ERROR_MESSAGE,
        )
        ws.add_data_validation(dv)
        dv.add(f"{col_letter}{DATA_START_ROW}:{col_letter}{end_row}")

    for col_idx in TEXT_EDITABLE_COLUMNS:
        column_label = KEYS[col_idx - 1]
        field_value_type = get_field_value_type(column_label)
        if not field_value_type:
            continue
        cell_range = list_ranges.get(field_value_type)
        if not cell_range:
            # Pas de liste disponible pour ce type (cosmos_api indispo,
            # ou aucune valeur en base) — reste en saisie libre.
            logging.warning(
                "Pas de liste de valeurs disponible pour '%s' (type %s) — "
                "colonne laissée en saisie libre.",
                column_label, field_value_type,
            )
            continue

        col_letter = get_column_letter(col_idx)
        dv = DataValidation(
            type="list",
            formula1=f"={cell_range}",
            allow_blank=True,
            showErrorMessage=True,
            errorStyle="stop",
            errorTitle=DATA_VALIDATION_ERROR_TITLE,
            error="Merci de choisir une valeur dans la liste proposée.",
        )
        ws.add_data_validation(dv)
        dv.add(f"{col_letter}{DATA_START_ROW}:{col_letter}{end_row}")


def apply_protection(ws: Worksheet) -> None:
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=TOTAL_COLUMNS):
        for cell in row:
            cell.protection = Protection(locked=False)

    for row_idx in range(1, ws.max_row + 1):
        for col_idx in range(1, TOTAL_COLUMNS + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            if row_idx >= DATA_START_ROW and col_idx in EDITABLE_COLUMNS:
                cell.protection = Protection(locked=False)
            else:
                cell.protection = Protection(locked=True)

    sheet_protection = SheetProtection()
    sheet_protection.sheet = True
    sheet_protection.objects = False
    sheet_protection.scenarios = False
    sheet_protection.formatCells = False
    sheet_protection.formatColumns = False
    sheet_protection.formatRows = False
    sheet_protection.insertColumns = False
    sheet_protection.insertRows = False
    sheet_protection.insertHyperlinks = False
    sheet_protection.deleteColumns = False
    sheet_protection.deleteRows = False
    sheet_protection.selectLockedCells = False
    sheet_protection.selectUnlockedCells = False
    sheet_protection.sort = False
    sheet_protection.autoFilter = False
    sheet_protection.pivotTables = False
    ws.protection = sheet_protection


def hide_technical_colums(ws: Worksheet) -> None:
    col_letter_cosmos_id = get_column_letter(COSMOS_ID_COLUMN_INDEX)
    col_letter_prod_cd = get_column_letter(PROD_CD_COLUMN_INDEX)
    ws.column_dimensions[col_letter_cosmos_id].hidden = True
    ws.column_dimensions[col_letter_prod_cd].hidden = True


def create_fees_template_workbook(fees_data: List[Dict]):
    wb = openpyxl.Workbook()
    ws: Worksheet = wb.active
    ws.title = SHEET_NAME

    styles = create_styles()

    create_header_rows(ws, styles)
    create_data_rows(ws, fees_data, styles)

    try:
        field_value_lists = get_fees_field_value_lists()
    except Exception:
        # Dégradation propre : pas de dropdown plutôt que de bloquer toute
        # la génération du fichier pour une fonctionnalité annexe.
        logging.exception(
            "Échec de récupération des listes de valeurs (get_fees_field_value_lists) "
            "— le template sera généré sans listes déroulantes."
        )
        field_value_lists = {}

    list_ranges = create_lists_sheet(wb, field_value_lists)
    create_data_validation(ws, fees_data, list_ranges)

    apply_protection(ws)
    hide_technical_colums(ws)

    ws.freeze_panes = f"A{DATA_START_ROW}"

    for col_idx, w in COL_WIDTHS.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = w

    return wb
