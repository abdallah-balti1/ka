"""
Parsing du fichier Excel "Fees" reuploade par l'utilisateur.

Deux points d'entree :
  - parse_fees_template_workbook(wb) : a utiliser dans le job qui a
    deja charge le Workbook (evite de re-parser les bytes une 2e fois
    apres is_all_fees_mass_update, qui a deja besoin du wb charge)
  - parse_fees_template_file(file_bytes) : pratique pour les tests /
    un usage isole, charge le workbook puis delegue a la fonction
    ci-dessus

Ne lit QUE ce qui est necessaire pour la diff : les colonnes techniques
"Cosmos ID" + "Product Cd" (cachees) et les colonnes editables.
"""

from io import BytesIO
from typing import Dict, List

from openpyxl import load_workbook
from openpyxl.workbook import Workbook

from constants.fees_template import (
    COSMOS_ID_COLUMN_INDEX,
    DATA_START_ROW,
    EDITABLE_COLUMNS,
    KEYS,
    PROD_CD_COLUMN_INDEX,
    SHEET_NAME,
)


def parse_fees_template_workbook(wb: Workbook) -> List[Dict]:
    """
    Retourne une liste de dicts, un par ligne de donnees du fichier :
      {"sha_cd": "41455", "prod_cd": "prod_1", "Max Management fees Rate": "0.4", ...}

    Seules les cles sha_cd/prod_cd + les colonnes editables sont incluses.
    Une ligne dont la colonne "Cosmos ID" est vide est ignoree.
    """
    if SHEET_NAME not in wb.sheetnames:
        raise ValueError(
            f"Feuille '{SHEET_NAME}' introuvable dans le fichier uploade "
            f"(feuilles presentes : {wb.sheetnames})"
        )
    ws = wb[SHEET_NAME]

    rows: List[Dict] = []
    row_idx = DATA_START_ROW
    while row_idx <= ws.max_row:
        sha_cd = ws.cell(row=row_idx, column=COSMOS_ID_COLUMN_INDEX).value
        if sha_cd is None or str(sha_cd).strip() == "":
            row_idx += 1
            continue

        prod_cd = ws.cell(row=row_idx, column=PROD_CD_COLUMN_INDEX).value
        row_data = {
            "sha_cd": str(sha_cd).strip(),
            "prod_cd": str(prod_cd).strip() if prod_cd is not None else None,
        }
        for col_idx in EDITABLE_COLUMNS:
            key = KEYS[col_idx - 1]
            value = ws.cell(row=row_idx, column=col_idx).value
            row_data[key] = value

        rows.append(row_data)
        row_idx += 1

    return rows


def parse_fees_template_file(file_bytes: bytes) -> List[Dict]:
    """Charge le workbook depuis des bytes puis delegue a
    parse_fees_template_workbook. Pratique pour tests/usage isole."""
    wb = load_workbook(filename=BytesIO(file_bytes), data_only=True)
    return parse_fees_template_workbook(wb)
