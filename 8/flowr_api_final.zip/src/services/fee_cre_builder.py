"""
Construction des CreData Cosmos à partir des diffs détectées — logique de
regroupement/exclusion INCHANGÉE par rapport à la version précédente.

⚠️ AJOUT/CORRECTIF pour le chantier "listes déroulantes" :
Les diffs pour les 4 champs texte (Basis of Calculation, Calculation
Frequency, Payment Frequency, Paid To) contiennent des LABELS
("Net assets") côté old_value/new_value, puisque c'est ce qu'affiche et
renvoie le template Excel. Cosmos attend le CODE ("1") pour ces champs.

AVANT ce correctif : old_value/new_value envoyés tels quels (labels) —
potentiellement rejeté ou mal interprété par Cosmos.
APRÈS : traduction label -> code via le mapping renvoyé par
get_fees_field_value_lists(), juste avant construction du CreData, pour
les champs concernés uniquement (Rate reste numérique, inchangé).

Si un label n'est pas retrouvé dans le mapping (donnée incohérente,
cosmos_api indisponible au moment du diff, ou dropdown non appliqué sur un
vieux fichier généré avant ce chantier) : on GARDE le label tel quel plutôt
que de faire planter tout le mass update, mais on le remonte dans
untranslated_values pour que l'appelant puisse le logger/flaguer. Point à
réévaluer : faut-il plutôt exclure ces diffs comme skipped_new_fees ?
Décision produit à prendre — TODO de la prochaine session.
"""

from collections import defaultdict

from client.smartgps import get_fees_field_value_lists
from constants.fees_cre_mapping import (
    get_field_value_type,
    get_identification_fields,
    get_pivot_field_name,
)
from entities import CreData

PARENT_ENTITY_TYPE = "Fees"
ENTITY_TYPE = "ProductFee"
PIVOT_NAME = "ProductFee"
MODIFY_ACTION = "MODIFY"


def _build_reverse_maps(field_value_lists):
    """{type: {code: label}} -> {type: {label: code}}"""
    return {
        type_name: {label: code for code, label in codes_to_labels.items()}
        for type_name, codes_to_labels in (field_value_lists or {}).items()
    }


def _translate_value(value, field_value_type, reverse_maps, untranslated_values):
    """Traduit un label en code pour un champ texte donné. Retourne la
    valeur telle quelle si pas de traduction applicable (champ numérique)
    ou si le label est introuvable dans le référentiel."""
    if value is None or not field_value_type:
        return value

    reverse_map = reverse_maps.get(field_value_type, {})
    if value in reverse_map:
        return reverse_map[value]

    untranslated_values.append({"field_value_type": field_value_type, "label": value})
    return value


def build_cre_data_for_all_fees(user, task, diffs):
    cre_data_list_by_product_id = defaultdict(list)
    mapping_entity_line_dict = {}
    skipped_new_fees = []
    untranslated_values = []

    try:
        field_value_lists = get_fees_field_value_lists()
    except Exception:
        field_value_lists = {}
    reverse_maps = _build_reverse_maps(field_value_lists)

    for diff in diffs:
        if diff.get("fee_id") is None or diff.get("fee_value_id") is None:
            skipped_new_fees.append(diff)
            continue

        field_value_type = get_field_value_type(diff["field"])
        old_value = _translate_value(
            diff["old_value"], field_value_type, reverse_maps, untranslated_values
        )
        new_value = _translate_value(
            diff["new_value"], field_value_type, reverse_maps, untranslated_values
        )

        cre_data = CreData(
            parent_entity_type=PARENT_ENTITY_TYPE,
            parent_entity_id=diff["fee_id"],
            entity_type=ENTITY_TYPE,
            entity_id=diff["fee_value_id"],
            old_value=str(old_value) if old_value is not None else None,
            new_value=str(new_value) if new_value is not None else None,
            entity_action=MODIFY_ACTION,
            task_id=task.id,
            is_parent_entity_from_plm=True,
            is_entity_from_plm=MODIFY_ACTION,
            pivot_field_name=get_pivot_field_name(diff["field"]),
            pivot_name=PIVOT_NAME,
            identification_fields=get_identification_fields(diff["field"]),
            author=user["fullname"],
        )
        cre_data_list_by_product_id[diff["prod_cd"]].append(cre_data)

    # untranslated_values n'est pas encore remonté à l'appelant (pas de
    # changement de signature pour rester compatible) — à brancher dans
    # le report utilisateur si le produit le demande. Pour l'instant,
    # juste disponible en local pour du logging si besoin.
    return cre_data_list_by_product_id, mapping_entity_line_dict, skipped_new_fees
