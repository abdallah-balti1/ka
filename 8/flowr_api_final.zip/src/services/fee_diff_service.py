from constants.fees_template import EDITABLE_COLUMNS, KEYS, NUMERIC_EDITABLE_COLUMNS

_NUMERIC_KEYS = {KEYS[idx - 1] for idx in NUMERIC_EDITABLE_COLUMNS}
_EDITABLE_KEYS = {KEYS[idx - 1] for idx in EDITABLE_COLUMNS}


def _normalize_empty(value):
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def _normalize_numeric(value):
    value = _normalize_empty(value)
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return round(float(value), 6)
    try:
        return round(float(str(value).strip().replace(",", ".")), 6)
    except (ValueError, TypeError):
        return str(value).strip()


def _normalize_text(value):
    value = _normalize_empty(value)
    return None if value is None else str(value).strip()


def _values_differ(key, file_value, fresh_value):
    if key in _NUMERIC_KEYS:
        return _normalize_numeric(file_value) != _normalize_numeric(fresh_value)
    return _normalize_text(file_value) != _normalize_text(fresh_value)


class FeeDiffService:
    @staticmethod
    def build_diff(file_rows, fresh_data_by_sha_cd):
        """
        file_rows : liste de dicts issus de parse_fees_template_workbook
                    (sha_cd, prod_cd, + une clé par colonne éditable)
        fresh_data_by_sha_cd : {sha_cd: {colonne: {"value":..., "fee_id":...,
                                "fee_value_id":...}}} - retour de
                                get_refetch_fees_data cote client

        Retourne une liste de diffs :
        [{sha_cd, prod_cd, field, old_value, new_value, fee_id, fee_value_id}]
        """
        diffs = []
        for row in file_rows:
            sha_cd = row["sha_cd"]
            prod_cd = row.get("prod_cd")
            fresh_row = fresh_data_by_sha_cd.get(sha_cd, {})

            for key in _EDITABLE_KEYS:
                file_value = row.get(key)
                fresh_entry = fresh_row.get(key) or {}
                fresh_value = fresh_entry.get("value")

                if _values_differ(key, file_value, fresh_value):
                    diffs.append({
                        "sha_cd": sha_cd,
                        "prod_cd": prod_cd,
                        "field": key,
                        "old_value": fresh_value,
                        "new_value": file_value,
                        "fee_id": fresh_entry.get("fee_id"),
                        "fee_value_id": fresh_entry.get("fee_value_id"),
                    })
        return diffs
