# -----------------------------------------------------------------------------
# À AJOUTER dans src/client/smartgps.py, à côté de get_adl_fees_data
# (même fichier, même pattern). Ne remplace rien d'existant.
# -----------------------------------------------------------------------------

def get_fees_data(product_ids):
    """Calls /retrieve_fees_data for given product_ids — renvoie TOUTES
    les fees (Management/Distribution/Charity/Advisory/Subscription/
    Redemption/Conversion/Specific & External), labels déjà traduits.

    Ne concerne PAS l'ADL in/out : reste sur get_adl_fees_data /
    /retrieve_adl_fees_data existant, inchangé.
    """
    logging.debug("[SMARTGPS] Fees data loading...")
    session = get_new_requests_session()
    url = "{}/retrieve_fees_data".format(config.SMARTGPS_URL)

    headers = {"Api-Key": config.API_KEY}
    data = {"prod_cd_list": product_ids}

    response = session.post(url, json=data, headers=headers, verify=False)
    handle_http_error(response)
    logging.debug("[SMARTGPS] Fees data loaded.")

    return response.json()

# -----------------------------------------------------------------------------
# À AJOUTER dans src/client/smartgps.py, à côté de get_adl_fees_data et
# get_fees_data (même fichier, même pattern).
# -----------------------------------------------------------------------------

def get_refetch_fees_data(sha_cd_list):
    """Calls /refetch_fees_data — renvoie l'état FRAIS des fees pour une
    liste de sha_cd (pas de codes produits), utilisé pour la diff au
    moment du traitement du mass update "All Fees".

    Retourne un dict :
        {
          "41455": {
            "Max Management fees Rate": {
              "value": "0.4",
              "fee_id": "...",
              "fee_value_id": "..."
            },
            ...
          },
          ...
        }
    """
    logging.debug("[SMARTGPS] Refetch fees data loading...")
    session = get_new_requests_session()
    url = "{}/refetch_fees_data".format(config.SMARTGPS_URL)

    headers = {"Api-Key": config.API_KEY}
    data = {"sha_cd_list": sha_cd_list}

    response = session.post(url, json=data, headers=headers, verify=False)
    handle_http_error(response)
    logging.debug("[SMARTGPS] Refetch fees data loaded.")

    return response.json()

# -----------------------------------------------------------------------------
# À AJOUTER dans src/client/smartgps.py, à côté de get_fees_data /
# get_refetch_fees_data (même fichier, même pattern).
# -----------------------------------------------------------------------------

def get_fees_field_value_lists():
    """Calls GET /fees_field_value_lists — renvoie les listes complètes
    {type: {code: label_en}} pour les colonnes texte du template "All Fees"
    (Basis of Calculation, Calculation Frequency, Payment Frequency, Paid To).

    Utilisé pour :
      - construire les listes déroulantes Excel à la génération
      - traduire label -> code avant l'envoi des CreData à Cosmos

    Indépendant de tout produit — un seul appel par run, pas par ligne.
    """
    logging.debug("[SMARTGPS] Fees field value lists loading...")
    session = get_new_requests_session()
    url = "{}/fees_field_value_lists".format(config.SMARTGPS_URL)

    headers = {"Api-Key": config.API_KEY}

    response = session.get(url, headers=headers, verify=False)
    handle_http_error(response)
    logging.debug("[SMARTGPS] Fees field value lists loaded.")

    return response.json()
