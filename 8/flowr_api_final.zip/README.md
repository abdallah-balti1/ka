# flowr_api — module "All Fees" mass update + dropdowns, prêt à intégrer

## ⚠️ Prérequis côté cosmos_api

Ces fichiers attendent que GET /fees_field_value_lists réponde avec un
dict indexé par TYPE :

    {
        "BASIS_OF_CALCULATION": {"1": "Net assets", ...},
        "FEE_CALCULATION_FREQUENCY": {"D": "Daily", "M": "Monthly", ...},
        "FEES_PAID_TO": {"1": "Custodian", ...}
    }

C'est la version corrigée livrée dans fees_field_value_lists.zip (v5).
Si l'ancienne version (indexée par nom de champ basis_calc_cd/calc_frq_cd/
pmt_frq_cd/fees_paid_cd) tourne encore côté cosmos_api, tout se génère
sans erreur mais SANS AUCUN dropdown - dégradation silencieuse. Vérifie
ça en premier si les listes n'apparaissent pas dans l'Excel généré.

## 1. Fichiers à copier tels quels (remplacement complet)

Tous les chemins ci-dessous sont sous `src/` dans ce zip, à copier au
même chemin relatif dans ton repo flowr_api :

- constants/fees_template.py
- constants/fees_cre_mapping.py
- util/mass_update/fees_template.py
- util/mass_update/fees_detection.py
- util/mass_update/fees_upload.py
- util/mass_update/process_all_fees_mass_update.py
- services/fee_diff_service.py
- services/fee_cre_builder.py
- test/util/mass_update/test_process_all_fees_mass_update.py
- test/util/mass_update/test_fees_detection_readonly_regression.py
- test/util/mass_update/test_fees_upload.py
- test/util/mass_update/test_get_mass_update_template_fees.py
- test/util/mass_update/test_fees_detection.py
- test/constants/test_fees_cre_mapping.py
- test/services/test_fee_diff_service.py
- test/services/test_fee_cre_builder.py
- test/api/mass_update_template/test_fees_template.py

(les `__init__.py` du dossier test/ sont inclus aussi, vides - ignore-les
si ton repo en a déjà)

## 2. Additions à coller dans 3 fichiers EXISTANTS (dossier PATCHES_to_paste_manually/)

Ces 3 fichiers ne sont PAS à copier tels quels — ce sont des blocs à
coller dans des fichiers de ton repo que je n'ai pas, chacun avec
l'emplacement exact en commentaire en tête de fichier :

1. `1_client_smartgps_ADDITIONS.py` -> dans `src/client/smartgps.py`,
   à côté de `get_adl_fees_data`. Ajoute 3 fonctions
   (`get_fees_data`, `get_refetch_fees_data`,
   `get_fees_field_value_lists`), ne remplace rien.

2. `2_get_mass_update_template_ADDITION.py` -> dans
   `src/util/mass_update/get_mass_update_template.py`, fonction
   `retrieve_mass_update_template`, JUSTE APRÈS le bloc existant
   "Specific Fees template" (ADL), en `elif`.
   ⚠️ Ordre non négociable : "Specific Fees template" contient la
   sous-chaîne "Fees template" — ce bloc doit rester après.

3. `3_send_mass_update_data_ADDITION.py` -> dans
   `send_mass_update_data.py`, fonction
   `send_mass_update_data_to_cosmos`, juste après
   `mu_version = get_mu_version(workbook)`, AVANT le bloc ADL existant
   (le bloc ADL passe en `elif`).

Chaque fichier de patch liste ses imports à ajouter en haut du fichier
cible, en commentaire.

## 3. À vérifier après intégration

- Lancer la suite de tests COMPLÈTE (pas juste les fichiers fees) — un
  premier assemblage manuel avait déjà produit une régression
  silencieuse sur 2 fichiers historiques.
- `test_get_mass_update_template_fees.py` a besoin du vrai
  `get_mass_update_template.py` de ton repo pour tourner (donc après
  l'étape 2 du point 2 ci-dessus).
- Point produit non tranché : dans `fee_cre_builder.py`, un label non
  retrouvé dans le référentiel est envoyé tel quel à Cosmos plutôt que
  d'exclure le diff (`untranslated_values` est calculé mais pas encore
  remonté à l'appelant) — à trancher avant la prod.
- Toujours en attente : liste complète `BASIS_OF_CALCULATION` /
  `FEES_PAID_TO` en base (seul `FEE_CALCULATION_FREQUENCY` est confirmé
  complet) — pas bloquant pour tester avec ce qu'on a.
