# Intégration flowr_api — module fees dropdown

Prérequis : appliquer d'abord la correction cosmos_api (voir
fees_field_value_lists.zip v5) - sans elle, tout ce qui suit se génère
sans planter mais sans aucun dropdown réel.

## 1. Fichiers à copier tels quels (remplacement complet)

- `constants/fees_template.py`
- `constants/fees_cre_mapping.py`
- `util/mass_update/fees_template.py`
- `util/mass_update/fees_detection.py`
- `util/mass_update/fees_upload.py`
- `util/mass_update/process_all_fees_mass_update.py`
- `services/fee_diff_service.py`
- `services/fee_cre_builder.py`
- les 9 fichiers de `test/`

## 2. Additions à coller dans des fichiers existants

### src/client/smartgps.py
Coller les 3 fonctions de `client_smartgps_ADDITIONS.py`
(`get_fees_data`, `get_refetch_fees_data`, `get_fees_field_value_lists`)
à côté de `get_adl_fees_data` - ne remplace rien.

### src/util/mass_update/get_mass_update_template.py
Dans `retrieve_mass_update_template(task, product_ids=[])` : coller le
bloc de `get_mass_update_template_ADDITION.py` JUSTE APRÈS le bloc
existant "Specific Fees template" (ADL), en `elif`. Ne jamais le
mettre avant - "Specific Fees template" contient la sous-chaîne "Fees
template", l'ordre des conditions n'est pas négociable.
Ajouter les 2 imports en haut du fichier (voir commentaire du fichier
ADDITION).

### src/services/send_mass_update_data.py (ou fichier équivalent)
Dans `send_mass_update_data_to_cosmos` : coller le bloc de
`send_mass_update_data_ADDITION.py` juste après
`mu_version = get_mu_version(workbook)`, AVANT le bloc ADL existant
(en `if`, le bloc ADL passe en `elif`). Ajouter les 3 imports en haut
du fichier.

## 3. À vérifier après intégration

- Lancer la suite de tests COMPLÈTE (pas juste les fichiers fees) :
  le contexte fourni signale que 2 fichiers (`fee_diff_service.py`,
  `fees_upload.py`) avaient déjà eu une régression silencieuse une
  fois lors d'un premier assemblage manuel similaire.
- `test_get_mass_update_template_fees.py` a besoin du vrai
  `get_mass_update_template.py` du repo pour tourner (dépend du
  point 2 ci-dessus déjà fait).
- Point produit non tranché : dans `fee_cre_builder.py`, un label
  non retrouvé dans le référentiel est envoyé tel quel à Cosmos
  plutôt que d'exclure le diff (`untranslated_values` est calculé
  mais pas encore remonté à l'appelant) - à décider avant la prod.
- Toujours en attente : la liste complète `BASIS_OF_CALCULATION` /
  `FEES_PAID_TO` en base (seul `FEE_CALCULATION_FREQUENCY` est
  confirmé complet) - pas bloquant pour tester avec ce qu'on a.
